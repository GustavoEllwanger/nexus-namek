import test from 'node:test';
import assert from 'node:assert/strict';
import {advance,buyUpgrade,challenge,equip,fighter,fresh,levelAt,makeBattle,maxLevel,rollRecruit,startExploration,upgradeLevel,waitFor,xpProgress} from './public/game.js';
import {affinity} from './public/engine.js';

test('tempo AFK resolve as mesmas lutas e recompensas da exploração aberta',()=>{
  const begin=1000, end=begin+1200000;
  const online=fresh(begin,565789), offline=fresh(begin,565789);
  startExploration(online,begin);startExploration(offline,begin);
  const live=[];
  for(let t=begin;t<=end;t+=1000)live.push(...advance(online,t));
  const away=advance(offline,end);
  assert(away.length>20);
  assert.deepEqual(away,live);
  assert.deepEqual(offline,online);
  const reopened=JSON.parse(JSON.stringify(offline));
  assert.equal(advance(reopened,end).length,0);
  assert.equal(reopened.gold,online.gold);
});

test('limite de 12h descarta tempo excedente e mantém a exploração ativa',()=>{
  const state=fresh(1000,4);
  startExploration(state,1000);
  state.pending=makeBattle(state,1000);
  state.nextAt=1000+14*3600000;
  state.running=false;
  advance(state,state.pending.end);
  assert.equal(state.wins,1);
  state.running=true;
  state.nextAt=state.clock+14*3600000;
  advance(state,state.clock+13*3600000);
  assert.equal(state.running,true);
  assert.equal(state.pending,null);
});

test('sorteio registra Shiny, Trait e chance combinada e mantém 10% de entrada',()=>{
  const values=[.01,.01,.1,.1,.01,.1];
  const recruit=rollRecruit(()=>values.shift());
  assert.equal(recruit.id,'yamcha');
  assert.equal(recruit.shiny,true);
  assert.equal(recruit.trait,'Concentração Total');
  assert.equal(recruit.odds,4848);
  assert.equal(rollRecruit(()=>.1),null);
});

test('Shiny aumenta cinco atributos e deixa Velocidade com a mesma base',()=>{
  const unit=fresh().collection.find(c=>c.id==='bulma');
  const normal=fighter(unit),shiny=fighter({...unit,shiny:true});
  for(const stat of ['hp','attack','magic','defense','resistance'])assert(shiny[stat]>normal[stat]);
  assert.equal(shiny.speed,normal.speed);
  assert.equal(affinity('Branco','Branco'),1.5);
  assert.equal(affinity('Dourado','Dourado'),2);
  assert.equal(affinity('Vermelho','Rosa'),.75);
});

test('mudar o time na coleção mantém uma liderança válida e não troca a luta atual',()=>{
  const state=fresh(1000,222);
  startExploration(state,1000);
  advance(state,1000);
  const fight=state.pending;
  state.collection.push({id:'nami',uid:'nami-test',xp:0,serial:1,shiny:false,trait:null});
  assert(equip(state,'nami-test',state.leader));
  assert.equal(state.leader,'nami-test');
  assert.equal(state.pending,fight);
  assert.equal(fight.team[0].id,'piccolo');
  assert.equal(makeBattle(state,fight.end+waitFor(state)).team[0].id,'nami');
});

test('o relógio de busca aguarda a luta em andamento, inclusive após recarregar',()=>{
  const state=fresh(1000,222);
  startExploration(state,1000);
  advance(state,1000);
  const {start,end,result}=state.pending;
  assert(end-start<result.seconds*1000);
  state.nextAt=start+500;
  const restored=JSON.parse(JSON.stringify(state));
  assert.deepEqual(advance(restored,end-1),[]);
  assert.equal(restored.index,1);
  assert.equal(advance(restored,end).length,1);
  assert.deepEqual(advance(restored,end),[]);
  assert.equal(restored.wins,1);
  assert.equal(restored.nextAt,end+10000);
  advance(restored,end+9999);
  assert.equal(restored.pending,null);
  advance(restored,end+10000);
  assert.equal(restored.pending.start,end+10000);
});

test('o teto AFK preserva uma luta cujo replay já começou',()=>{
  const state=fresh(1000,222);
  const cap=state.clock+12*3600000;
  startExploration(state,state.clock);
  state.nextAt=cap-500;
  const restoredAt=cap+3600000;
  assert.deepEqual(advance(state,restoredAt),[]);
  assert.equal(state.running,true);
  assert.equal(state.pending.start,restoredAt-500);
  const end=state.pending.end;
  assert.equal(advance(state,end).length,1);
  assert.equal(state.wins,1);
  assert.equal(state.pending,null);
});

test('upgrades preservam compras antigas, cobram por nível e respeitam os tetos',()=>{
  const state=fresh(1000,222);
  delete state.upgrades;
  state.upgraded=true;
  assert.equal(waitFor(state),9000);
  assert.equal(buyUpgrade(state,'ritmo'),false);
  assert.equal(buyUpgrade(state,'ouro'),false);
  state.gold=2000;
  assert(buyUpgrade(state,'sorte'));
  assert(buyUpgrade(state,'sorte'));
  assert(buyUpgrade(state,'sorte'));
  assert.equal(buyUpgrade(state,'sorte'),false);
  assert.equal(buyUpgrade(state,'inexistente'),false);
  assert.equal(state.gold,1525);
  assert.equal(upgradeLevel(JSON.parse(JSON.stringify(state)),'sorte'),3);
  assert.equal(waitFor(state),9000);
  const values=[.125,.01,.1,.1,.01,.1];
  assert(rollRecruit(()=>values.shift(),.13));
  assert.equal(rollRecruit(()=>.125,.12),null);
});

test('ouro e XP usam o início da luta como referência e distribuem um único orçamento aos reservas',()=>{
  const state=fresh(1000,222);
  const reserves=['a','b'].map(uid=>({id:'nami',uid,xp:0,serial:1,shiny:false,trait:null}));
  state.collection.push(...reserves);
  state.gold=1000;
  startExploration(state,1000);
  advance(state,1000);
  assert(buyUpgrade(state,'ouro'));
  assert(buyUpgrade(state,'xp'));
  const [first]=advance(state,state.pending.end);
  assert.equal(first.reserveXp,0);
  assert(reserves.every(unit=>unit.xp===0));
  advance(state,state.nextAt);
  const battle=state.pending;
  const replaced=state.team[0];
  const before=state.collection.find(unit=>unit.uid===replaced).xp;
  equip(state,'a',replaced);
  const [second]=advance(state,battle.end);
  assert(second.won);
  assert.equal(second.gold,Math.round((6+2*battle.level)*1.20*1.10));
  assert.equal(second.reserveXp,Math.floor(second.xp*.25));
  assert.equal(reserves[0].xp+reserves[1].xp,second.reserveXp);
  assert.equal(state.collection.find(unit=>unit.uid===replaced).xp,before+second.xp);
  assert.deepEqual(xpProgress(22),{level:2,current:1,required:27});
});

test('o golpe em área de Freeza pune uma formação agrupada',()=>{
  const spread=fresh(1000,222), clumped=fresh(1000,222);
  for(const unit of [...spread.collection,...clumped.collection])unit.xp=409;
  for(const id of clumped.team)clumped.positions[id]=[50,50];
  const targets=state=>makeBattle(state,1000,true).result.events.find(e=>e.type==='onda').targets.length;
  assert(targets(clumped)>targets(spread));
});

test('os quatro iniciais avançam pelas três áreas e vencem Freeza sem usar recrutas',()=>{
  const state=fresh(1000,222);
  let t=1000;
  startExploration(state,t);
  for(let i=0;i<150 && state.finalWins<12;i++){
    advance(state,t);
    if(state.pending){t=state.pending.end;advance(state,t);}
    const level=maxLevel(state);
    state.area=level>=7?2:level>=4?1:0;
    if(!state.running)startExploration(state,t);
    t=Math.max(t,state.nextAt);
  }
  assert.equal(state.finalWins,12);
  assert(state.team.every(id=>id.startsWith('initial-')));
  assert.equal(maxLevel(state),10);
  assert(state.gold>=350);
  state.gold-=350;state.upgraded=true;
  assert.equal(waitFor(state),9000);
  state.autoRoutes=false;
  assert(challenge(state,t));
  advance(state,state.pending.end);
  assert(state.completed);
  assert(!challenge(state,state.clock));
  assert(state.collection.every(c=>levelAt(c.xp)<=10));
  assert.equal(new Set(state.collection.map(c=>`${c.id}-${c.shiny}-${c.serial}`)).size,state.collection.length);
});

test('campanha completa libera os dez mundos e preserva vitória nas revisitas',async()=>{
  const {WORLDS,applyGameAction}=await import('./public/game.js');
  const state=fresh(1000,222);
  for(let i=0;i<WORLDS.length;i++){
    assert.equal(state.world,i);
    assert.equal(applyGameAction(state,{type:'world',index:i+1},state.clock),false);
    let steps=0;
    while(state.world===i&&!state.completed&&steps++<800){
      advance(state,state.pending?.end??state.nextAt);
    }
    assert(i===9?state.completed:state.journey[i]?.completed,'Chefe do mundo '+WORLDS[i].name);
  }
  assert.equal(state.unlocked,9);
  applyGameAction(state,{type:'world',index:0},state.clock);
  assert(state.completed);
  assert(state.finalWins>=12);
});

test('parada manual persiste no retorno AFK e preserva a luta em andamento',async()=>{
  const {applyGameAction}=await import('./public/game.js');
  const state=fresh(1000,222);
  advance(state,1000);
  applyGameAction(state,{type:'pause'},1001);
  const restored=JSON.parse(JSON.stringify(state));
  const end=1000+13*3600000;
  assert.equal(advance(restored,end).length,1);
  assert.equal(restored.running,false);
  assert.equal(restored.pending,null);
  applyGameAction(restored,{type:'resume'},end);
  assert(restored.running);
});

test('reforços de Bleach, Fire Force e Tensura podem ser recrutados',async()=>{
  const {CHARACTERS}=await import('./public/game.js');
  const ids=['mayuri','starrk','yoruichi','urahara','shinra','arthur','maki_oze','iris','shinra_banshoman','benimaru_shinmon','luminous','veldora'];
  const weights=[.55,.27,.12,.045,.012,.0025,.00045,.00005];
  for(const id of ids){
    const card=CHARACTERS[id];
    const local=Object.values(CHARACTERS).filter(c=>c.tier===card.tier&&c.universe===card.universe);
    const tierRoll=weights.slice(0,card.tier-1).reduce((a,b)=>a+b,0)+weights[card.tier-1]/2;
    const rolls=[0,tierRoll,0,(local.indexOf(card)+.5)/local.length,.9,.99];
    assert.equal(rollRecruit(()=>rolls.shift(),.1,card.universe).id,id);
  }
});

test('efeitos próprios de Mayuri, Starrk, Yoruichi e Arthur obedecem à recarga',async()=>{
  const {Combate}=await import('./public/engine.js');
  const {CHARACTERS}=await import('./public/game.js');
  for(const [id,expectedHits] of [['mayuri',1],['starrk',3],['yoruichi',1],['arthur',1]]){
    const battle=new Combate([[fighter({id,xp:0})],[{hp:1000,defense:100}]]);
    const [actor,target]=battle.teams.map(team=>team[0]);
    const skill=CHARACTERS[id].kind;
    assert(battle.use(actor,target,skill));
    assert.equal(battle.log.filter(e=>e.type==='dano').length,expectedHits);
    assert.equal(battle.use(actor,target,skill),false);
    if(id==='mayuri')assert.equal(target.weakenUntil,4000);
    if(id==='yoruichi')assert.equal(actor.evade,1);
    if(id==='arthur')assert(Math.abs(1000-target.hp-actor.attack*1.45*40/(40+65))<1e-7);
  }
});

test('formas e habilidades de Fire Force e Tensura respeitam cura, alcance e alvos',async()=>{
  const {Combate}=await import('./public/engine.js');
  const {CHARACTERS}=await import('./public/game.js');
  assert.equal(CHARACTERS.shinra.tier,4);
  assert.equal(CHARACTERS.shinra_banshoman.tier,8);
  for(const id of ['shinra_banshoman','benimaru_shinmon','luminous','veldora']){
    const enemies=[10,25,85].map(x=>({x,y:0,hp:5000,resistance:100}));
    const battle=new Combate([[{attack:100,magic:100},{hp:1000}],enemies],{mode:'equipe'});
    const [actor,ally]=battle.teams[0], [target,near,far]=battle.teams[1];
    ally.hp=200;
    const use=()=>battle.use(actor,target,CHARACTERS[id].kind);
    assert(use());
    assert(!use());
    if(id==='shinra_banshoman'){
      assert.equal(ally.hp,700);
      assert.equal(target.hp,5000);
      ally.hp=200;battle.time=9000;
      assert(use());
      assert.equal(ally.hp,200);
      assert.equal(target.hp,4810);
    }else if(id==='luminous'){
      assert.equal(ally.hp,400);
      assert(target.hp<5000);
    }else if(id==='benimaru_shinmon'){
      assert.equal(target.hp,4820);
      assert.equal(near.hp,4915);
      assert.equal(far.hp,5000);
    }else{
      assert(Math.abs(5000-target.hp-185*40/110)<1e-7);
      assert(Math.abs(5000-near.hp-75*40/140)<1e-7);
      assert.equal(far.hp,5000);
    }
  }
});

test('vagas persistem e equipe vazia retoma sem encontros retroativos',async()=>{
  const {formationSlots,applyGameAction}=await import('./public/game.js');
  const s=fresh(0,22),initial=s.team.slice();
  advance(s,0);
  const snapshot=s.pending.team.map(u=>u.uid);
  for(const uid of initial)assert.ok(applyGameAction(s,{type:'remove',uid},1));
  assert.deepEqual(s.pending.team.map(u=>u.uid),snapshot);
  assert.equal(advance(s,80000).length,1);
  assert.equal(s.pending,null);
  const restored=JSON.parse(JSON.stringify(s));
  assert.deepEqual(formationSlots(restored),[null,null,null,null]);
  for(const slot of [3,1]){
    assert.ok(applyGameAction(restored,{type:'equip',slot,uid:initial[slot]},80000));
  }
  assert.deepEqual(restored.team,[initial[1],initial[3]]);
  assert.equal(restored.leader,initial[3]);
  assert.equal(applyGameAction(restored,{type:'equip',slot:1,uid:initial[0]},80000),false);
  assert.deepEqual(advance(restored,80000),[]);
  assert.equal(restored.pending.start,80000);
});

test('quinze encontros começam assim que termina a busca e liquidam uma única vez',()=>{
  let s=fresh(13000,234);advance(s,13000);
  for(let i=1;i<=15;i++){
    const battle=s.pending;
    assert.ok(battle.end-battle.start<=6000);
    assert.equal(advance(s,battle.end).length,1);
    assert.equal(s.pending,null);
    advance(s,s.nextAt-1);assert.equal(s.pending,null);
    s=JSON.parse(JSON.stringify(s));
    const next=s.nextAt;
    assert.deepEqual(advance(s,next),[]);
    assert.equal(s.pending.start,next);
    assert.equal(s.wins+s.losses,i);
  }
});
