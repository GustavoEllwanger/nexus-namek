import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {fresh,projectedPower,unitPower,autoFormation} from './public/game.js';
import {serialSchema,issueSerials} from './serials.mjs';

test('autoformação prefere o potencial da cópia nova sem alterar sua XP',()=>{
  const s=fresh(1000,1);
  s.collection=Array.from({length:5},(_,i)=>({...s.collection[0],uid:'p'+i,xp:i===4?0:1e7,shiny:i===4}));
  const [veteran,,,,rookie]=s.collection;
  assert(unitPower(veteran)>unitPower(rookie));
  assert(projectedPower(rookie)>projectedPower(veteran));
  autoFormation(s);
  assert(s.team.includes(rookie.uid));assert.equal(rookie.xp,0);
});

test('migração conserva inventário, históricos e lacunas de venda e mantém sequências por variante',()=>{
 const db=new DatabaseSync(':memory:');
 db.exec('CREATE TABLE players(id TEXT PRIMARY KEY,game TEXT)');
 for(const [id,created] of [['b',2],['a',1]]){
   const s=fresh(created,1);
   s.serials={piccolo:3};s.log=[{sold:{id:'piccolo',serial:3},won:true}];
   db.prepare('INSERT INTO players VALUES(?,?)').run(id,JSON.stringify(s));
 }
 for(let i=0;i<2;i++)for(const sql of serialSchema('players',false))db.exec(sql);
 const s=JSON.parse(db.prepare("SELECT game FROM players WHERE id='b'").get().game);
 assert.equal(s.collection[0].serial,4);assert.equal(s.log[0].sold.serial,6);
 const units=[{id:'piccolo'},{id:'piccolo',shiny:true},{id:'piccolo'}];
 issueSerials(s,units,db.prepare('SELECT * FROM nexus_serials').get());
 assert.deepEqual(units.map(u=>u.serial),[7,1,8]);
 db.prepare("UPDATE players SET game=? WHERE id='b'").run(JSON.stringify(s));
 assert.equal(JSON.parse(db.prepare('SELECT counts FROM nexus_serials').get().counts).piccolo,8);
 db.close();
});
