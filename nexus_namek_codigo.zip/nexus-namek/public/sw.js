const CACHE = 'nexus-namek-14';
const FILES = ['./','./index.html','./style.css','./app.js','./game.js','./duel.js','./community.js','./community-rules.js','./engine.js','./manifest.webmanifest','./art/namek.webp',...['ap-accelerator','ap-android-17-torneio-do-poder','ap-beerus','ap-broly-super','ap-bulma-shiny','ap-bulma','ap-byakuya','ap-dio','ap-freeza-forma-final-shiny','ap-freeza-forma-final','ap-gohan-namek-shiny','ap-gohan-namek','ap-gojo','ap-goku-instinto-superior','ap-kuririn-shiny','ap-kuririn','ap-mob-por-cento','ap-nami-shiny','ap-nami','ap-neferpitou','ap-neji','ap-netero','ap-piccolo-shiny','ap-piccolo','ap-renji','ap-rock-lee-shiny','ap-rock-lee','ap-tenshinhan-shiny','ap-tenshinhan','ap-trafalgar-law-shiny','ap-trafalgar-law','ap-usopp-shiny','ap-usopp','ap-vegeta-super-saiyajin-blue','ap-yamcha-shiny','ap-yamcha','ap-zoro-shiny','ap-zoro','fighter','freeza','monk','namek','soldier','support'].map(name=>`./art/${name}.png`),'./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('nexus-namek-')&&k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',event=>{
  if(new URL(event.request.url).pathname.startsWith('/api/'))return;
  if(event.request.method!=='GET'||new URL(event.request.url).origin!==location.origin)return;
  event.respondWith(fetch(event.request).then(response=>{
    if(response.ok){const copy=response.clone();event.waitUntil(caches.open(CACHE).then(cache=>cache.put(event.request,copy)));}
    return response;
  }).catch(async()=>await caches.match(event.request) || (event.request.mode==='navigate'?await caches.match('./index.html'):Response.error())));
});
