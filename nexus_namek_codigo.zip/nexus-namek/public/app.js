import {affinity} from "./engine.js";
import {formationCost,RECOVERY_MS,SALE_PRICES,readyAt,formationSlots,spriteFor,WORLDS,worldOf,levelCap,CHARACTERS,COLORS,SKILL_EFFECTS,TIERS,TRAITS,UPGRADES,AWAY_THRESHOLD,advanceWithPresence,advance,applyGameAction,fighter,fresh,levelAt,maxLevel,readyForBoss,upgradeLevel,waitFor,xpProgress} from './game.js';
import {collisionBonus,collisionPower,createDuel,stepDuel} from './duel.js';
import {createCommunity} from './community.js';

const saveKey = 'nexus.namek.v1';
const $ = selector=>document.querySelector(selector);
const int = new Intl.NumberFormat('pt-BR');
const validTabs=['exploracao','formacao','colecao','configuracoes','upgrades','comunidade','arena','guia'];
const time = milliseconds=>{const sec=Math.max(0,Math.ceil(milliseconds/1000));return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`;};
const copy=id=>state.collection.find(c=>c.uid===id);
const card=id=>CHARACTERS[copy(id).id];
let preferences={motion:true,numbers:true};
try{preferences={...preferences,...JSON.parse(localStorage.getItem('nexus.display')||'{}')};}catch{}
document.documentElement.dataset.motion=preferences.motion?'on':'off';
const spriteURL = name => `art/${name}.png`;
const img=(sprite,alt='')=>`<img src="${spriteURL(sprite)}" alt="${alt}">`;
const note = text=> { const box=$('#notice');box.textContent=text;box.hidden=!text; };

function load(){
  try { const parsed=JSON.parse(localStorage.getItem(saveKey));if(parsed?.version===1&&Array.isArray(parsed.team)&&Array.isArray(parsed.collection))return parsed; } catch {}
  return null;
}
let state=load()??fresh(Date.now(),crypto.getRandomValues(new Uint32Array(1))[0]);
let selected=state.team[0];
let pickSlot=null;
let tab=validTabs.includes(location.hash.slice(1))?location.hash.slice(1):'exploracao';
let replay=null, finishedBattle=null, eventCursor=0, stageKey='', busy=false, drag=null, installPrompt=null;
let transactionQueue=Promise.resolve();
let publicUnit=null, profileUid=null, profileOpener=null, profileContent='';
let serverOffset=0;
const gameNow=()=>Date.now()+serverOffset;
let duel=null,rival=null,frameTime=0,carry=0;
function loadArenaRecovery(){
  try{return JSON.parse(localStorage.getItem('nexus.arena.recovery.'+state.created))??{};}catch{return {};}
}
let arenaRecovery=loadArenaRecovery();
function arenaReadyAt(uid){return Math.max(arenaRecovery[uid]??0,arenaRecovery.all??0);}
function arenaWait(){return Math.min(...state.team.map(arenaReadyAt))-gameNow();}
function playerSquad(){
  const leader=CHARACTERS[copy(state.leader)?.id];
  return state.team.filter(uid=>arenaReadyAt(uid)<=gameNow()).map(uid=>fighter(copy(uid),undefined,arenaReadyAt(state.leader)<=gameNow()?leader:null));
}
function startDuel(){
  const team=playerSquad();
  if(!team.length||rival?.team.length===0){renderPanel();note('As duas equipes precisam ter pelo menos um personagem.');return;}
  const ids=['yamcha','kuririn','bulma','piccolo'];
  const opponent=rival?.team??team.map((u,i)=>fighter({id:ids[i],xp:copy(u.uid).xp},undefined,CHARACTERS.yamcha));
  duel=createDuel(team,opponent);
  frameTime=0;carry=0;
  renderPanel();
}
function duelPanel(panel){
  if(!panel.querySelector('#duel-field')){
    panel.innerHTML='<article class="card duel-card"><p class="smallcaps">NEXUS · REVEZAMENTO</p><h2>Arena das bolas</h2><p class="caption">Cada acerto por colisão soma 12 pontos percentuais ao bônus de dano da próxima colisão, até +40%. As reservas ajudam a cada 8 s e entram na ordem da formação. Aos dois minutos, vence a equipe com mais PV proporcionais restantes.</p><strong id="duel-rival"></strong><div id="duel-field"><i></i><i></i><div class="damage-popups" aria-hidden="true"></div></div><div id="duel-teams"></div><p role="status" id="duel-status"></p><div id="duel-log"></div><ul id="damage-feed" aria-label="Últimos golpes"></ul><button class="primary" id="duel-start"></button> <button class="ghost" id="duel-train">Voltar ao treino</button></article>';
  }
  $('#duel-rival').textContent=rival?'Desafio contra '+rival.name:'Treino · Equipe de Namek';
  updateDuelButton();
  paintDuel();
}
function updateDuelButton(){
  const btn=$('#duel-start');if(!btn)return;
  $('#duel-train').hidden=!rival;
  btn.disabled=arenaWait()>0||!state.team.length||rival?.team.length===0||!!duel&&duel.result===null;
  btn.textContent=duel&&duel.result===null?'Duelo em andamento':state.team.length&&arenaWait()>0?'Recuperação · '+Math.ceil(arenaWait()/1000)+' s':duel?'Jogar novamente':'Começar duelo';
}
const damageNumber=new Intl.NumberFormat('pt-BR',{maximumFractionDigits:1});
function damageText(n){return n>0&&n<.1?'<0,1':damageNumber.format(n);}
function drawDamage(field){
  const list=$('#damage-feed'),layer=field.querySelector('.damage-popups');
  const latest=duel.damageFeed[0]?.seq??-1;
  if(layer.match===duel&&layer.seen===latest)return;
  const seen=layer.match===duel?layer.seen:-1;
  if(layer.match!==duel){layer.replaceChildren();layer.match=duel;}
  layer.seen=latest;
  list.replaceChildren(...duel.damageFeed.slice(0,5).map(hit=>{
    const li=document.createElement('li');li.dataset.side=hit.side;
    li.textContent=`${hit.side?'Inimigo':'Você'} · ${hit.source} → ${hit.target} · −${damageText(hit.amount)} PV`;
    return li;
  }));
  if(!preferences.numbers)return;
  for(const hit of duel.damageFeed.filter(h=>h.seq>seen).reverse()){
    const pop=document.createElement('span');pop.dataset.side=hit.side;
    pop.textContent=`${hit.source} −${damageText(hit.amount)}`;
    layer.append(pop);
    const group=layer.querySelectorAll(`[data-side="${hit.side}"]`);
    if(group.length>3)group[0].remove();
    setTimeout(()=>pop.remove(),1500);
  }
}
function paintDuel(){
  const field=$('#duel-field');if(!field)return;
  if(!duel){
    field.hidden=true;$('#damage-feed').replaceChildren();$('#duel-status').textContent=state.team.length?'Sua formação está pronta.':'Escolha um personagem na coleção para começar.';
    $('#duel-teams').textContent=playerSquad().map(u=>u.name).join(' → ');$('#duel-log').textContent='';return;
  }
  field.hidden=false;
  drawDamage(field);
  const rows=duel.sides.map((s,i)=>{
    const f=s.team[s.slot],ball=field.children[i];
    ball.hidden=!f;
    if(f){
      const x=preferences.motion?s.x:i?75:25,y=preferences.motion?s.y:25;
      ball.style.left=x+'%';ball.style.top=2*y+'%';
      ball.style.backgroundColor=COLORS[f.color];if(ball.dataset.sprite!==f.sprite){ball.dataset.sprite=f.sprite;ball.style.backgroundImage='url("'+spriteURL(f.sprite)+'")';}
    }
    return '<section><small>'+(i?'ADVERSÁRIO':'SUA FORMAÇÃO')+'</small><strong>'+(f?.name??'Equipe eliminada')+'</strong>'+(f?'<progress max="'+f.maxHp+'" value="'+Math.ceil(f.hp)+'"></progress><small>'+Math.ceil(f.hp)+'/'+f.maxHp+' PV</small><b class="collision-power">Dano de colisão · '+damageText(collisionPower(duel,f))+'</b><small>+'+collisionBonus(f.hits)+'% por colisões · antes da defesa e da afinidade</small>':'')+'<small>Reserva · '+(s.team.slice(s.slot+1).map(u=>u.name).join(', ')||'—')+'</small></section>';
  }).join('');
  if($('#duel-teams').innerHTML!==rows)$('#duel-teams').innerHTML=rows;
  $('#duel-status').textContent=duel.result??('Em combate · '+Math.floor(duel.t)+' s');
  $('#duel-log').textContent=duel.events.slice(0,3).join('  •  ');
}
function duelFrame(now){
  if(tab==='arena'&&!document.hidden&&duel&&duel.result===null){
    carry+=frameTime?Math.min(.15,(now-frameTime)/1000):0;frameTime=now;
    const home=duel.sides[0],previousSlot=home.slot;
    while(carry>=1/60&&duel.result===null){stepDuel(duel);carry-=1/60;}
    if(previousSlot!==home.slot){
      const until=gameNow()+RECOVERY_MS;
      for(const f of home.team.slice(previousSlot,home.slot))arenaRecovery[f.uid]=until;
      if(home.slot===home.team.length)arenaRecovery.all=until;
      try{localStorage.setItem('nexus.arena.recovery.'+state.created,JSON.stringify(arenaRecovery));}catch{}
    }
    if(duel.result!==null)duelPanel($('#panel'));else paintDuel();
  }else frameTime=0;
  requestAnimationFrame(duelFrame);
}
requestAnimationFrame(duelFrame);

const community=createCommunity({spriteURL,onChallenge(profile){
  rival={name:profile.name,team:profile.team.map(u=>fighter(u,undefined,CHARACTERS[profile.leaderId]))};
  duel=null;tab='arena';history.replaceState(null,'','#arena');startDuel();
},onSession(data){
  duel=null;rival=null;
  state=data?.state??load()??fresh(Date.now(),crypto.getRandomValues(new Uint32Array(1))[0]);
  arenaRecovery=loadArenaRecovery();
  serverOffset=data?data.now-Date.now():0;
  saveTick=Date.now();
  stageKey='';finishedBattle=null;
  selected=state.team[0];pickSlot=null;
  renderPanel();
  drawScene(gameNow());
}});

const serial=unit=>`#${String(unit.serial).padStart(3,'0')}`;
const statLabels={hp:'PV',attack:'Ataque',magic:'Magia',defense:'Defesa',resistance:'Resistência',speed:'Velocidade'};
let storageFailed=false;
function store(){try {localStorage.setItem(saveKey,JSON.stringify(state));storageFailed=false;}catch{storageFailed=true;note('O navegador bloqueou o salvamento neste dispositivo.');}}
function receive(entries,offline=false){
  if(!entries.length)return;
  if(state.awayReports?.length)return;
  if(offline){
    const wins=entries.filter(e=>e.won).length;
    const recruits=entries.filter(e=>e.recruit).map(e=>CHARACTERS[e.recruit.id].name);
    const gold=entries.reduce((a,e)=>a+e.gold,0);
    note(`Progresso AFK · ${wins} vitórias em ${entries.length} lutas · +${int.format(gold)} ouro${recruits.length?` · ${recruits.length} recrutados (${recruits.slice(0,3).join(', ')}${recruits.length>3?'…':''})`:''}.`);
    return;
  }
  const last=entries.at(-1);
  if(last.sold)note(`Cópia de ${CHARACTERS[last.sold.id].name} vendida por ${int.format(last.saleGold)} ouro.`);
  else if(last.recruit){const r=last.recruit;note(`${CHARACTERS[r.id].name}${r.shiny?' Shiny':''} #${String(r.serial).padStart(3,'0')} entrou para a coleção${r.trait?` · ${r.trait}`:''}.`);}
  else if(last.boss)note(last.won?`Vitória sobre ${last.label}! Confira os destinos da campanha.`:`Derrota contra ${last.label}. Ajuste a formação para a próxima tentativa.`);
}

let lastObservation=document.hidden?null:Date.now();
let sentObservation=null;
let renderedReport='';
function showAway(){
  const dialog=$('#away-dialog'),r=state.awayReports?.[0];
  if(!r){if(dialog.open)dialog.close();renderedReport='';return;}
  if(document.hidden||!document.hasFocus())return;
  if(renderedReport!==String(r.start)+'/'+r.end){
    renderedReport=String(r.start)+'/'+r.end;
    const minutes=Math.floor((r.end-r.start)/60000);
    $('#away-time').textContent=(minutes>=60?Math.floor(minutes/60)+' h ':'')+(minutes%60)+' min de ausência'+(minutes>720?' · limite de exploração de 12 h':'');
    const recruits=state.collection.slice(r.firstRecruit,r.lastRecruit);
    $('#away-stats').innerHTML=[[r.encounters,'Encontros'],[r.wins,'Vitórias'],[recruits.length,'Mantidos na coleção'],[r.sold??0,'Cópias vendidas'],[r.saleGold??0,'Ouro de vendas (incluído no total)'],[r.gold,'Ouro'],[r.teamXp,'XP dos titulares'],[r.reserveXp,'XP dos reservas']].map(([v,label])=>`<div><strong>${int.format(v)}</strong><small>${label}</small></div>`).join('');
    $('#away-recruits').innerHTML=recruits.length?recruits.map(u=>{
      const c=CHARACTERS[u.id];return `<li style="--tone:${COLORS[c.color]}">${img(spriteFor(u))}<strong>${c.name}${u.shiny?' ✦':''}</strong><small>${TIERS[c.tier-1]} · ${serial(u)}</small></li>`;
    }).join(''):'<li>Nenhum personagem recrutado neste período.</li>';
  }
  if(!dialog.open)dialog.showModal();
}
function transaction(action,offline=false){
  function commit(){
    if(!storageFailed)state=load()??state;
    const now=Date.now();
    const previousBattle=state.pending;
    const entries=advanceWithPresence(state,now,lastObservation);
    const lastEntry=entries.at(-1);
    if(previousBattle&&lastEntry?.end===previousBattle.end)finishedBattle={battle:previousBattle,entry:lastEntry};
    const changed=applyGameAction(state,action,now)||entries.length;
    if(action)entries.push(...advance(state,now));
    store();
    if(changed&&!drag)renderPanel();
    if(profileUid)renderProfile();
    receive(entries,offline);
  }
  const next=transactionQueue.then(async()=>{
    busy=true;
    try{
      if(community?.active()){
        const firstConnection=!community.ready();
        const previous=state;
        const observed=lastObservation;
        const age=observed===null||observed===sentObservation?null:Math.max(0,Date.now()-observed);
        const data=await community.game(action,age);
        if(!data)return;
        sentObservation=observed;
        serverOffset=data.now-Date.now();
        state=data.state;
        if(firstConnection){arenaRecovery=loadArenaRecovery();finishedBattle=null;stageKey='';}
        if(data.finished)finishedBattle=data.finished;
        if((firstConnection||data.changed||data.entries.length||previous.gold!==state.gold)&&!drag)renderPanel();
        if(firstConnection&&tab==='comunidade')community.mount();
        if(profileUid)renderProfile();
        if(!state.awayReports?.length&&data.offline.total>25){
          const {total,wins,gold,recruits}=data.offline;
          note(`Progresso AFK · ${wins} vitórias em ${total} lutas · +${int.format(gold)} ouro · ${recruits} recrutados.`);
        }else receive(data.entries,offline);
      }else if(navigator.locks)await navigator.locks.request(saveKey,commit);
      else commit();
    } finally{busy=false;showAway();}
  });
  transactionQueue=next.catch(error=>{
    if(error.status===401&&community?.active()){
      community.clear();
      state=load()??fresh(Date.now());
      serverOffset=0;finishedBattle=null;stageKey='';
      renderPanel();
    }
    note(error.message||'Não foi possível atualizar o progresso.');
  });
  return transactionQueue;
}

function unitSummary(unit){
  const c=CHARACTERS[unit.id];
  return `<span class="member">${img(spriteFor(unit))}<span class="unit-summary"><strong>${c.name}${unit.shiny?' ✦':''}</strong><small>${TIERS[c.tier-1]} · ${c.color} · Nv. ${levelAt(unit.xp)} · ${serial(unit)}</small></span></span>`;
}

let chartColor='Vermelho',chartMode='ataque';
function colorChart(){
  const colors=Object.keys(COLORS);
  const symbols={Vermelho:'◆',Laranja:'▲',Amarelo:'✦',Verde:'✿',Turquesa:'≈',Azul:'●',Roxo:'☾',Rosa:'♥',Branco:'○',Preto:'■',Dourado:'✹'};
  const attack=chartMode==='ataque';
  const mult=c=>attack?affinity(chartColor,c):affinity(c,chartColor);
  const ring=['Vermelho','Laranja','Amarelo','Verde','Turquesa','Azul','Roxo','Rosa'];
  const point=i=>{const t=i*Math.PI/4-Math.PI/2;return [160+108*Math.cos(t),134+102*Math.sin(t)];};
  const wheel=`<svg class="affinity-wheel" viewBox="0 0 320 275" role="img" aria-label="Ciclo de vantagem: Vermelho, Laranja, Amarelo, Verde, Turquesa, Azul, Roxo, Rosa e volta para Vermelho."><defs><marker id="aff-tip" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0 0L5 2.5L0 5Z" fill="#d6d9ec"/></marker></defs>
    ${ring.map((c,i)=>{const [x,y]=point(i),[nx,ny]=point(i+1),dx=nx-x,dy=ny-y;
      return `<line x1="${x+dx*.3}" y1="${y+dy*.3}" x2="${x+dx*.68}" y2="${y+dy*.68}" stroke="#d6d9ec" stroke-width="1.8" marker-end="url(#aff-tip)"/>`;}).join('')}
    ${ring.map((c,i)=>{const [x,y]=point(i);return `<g><circle cx="${x}" cy="${y}" r="15" fill="#232639" stroke="${COLORS[c]}" stroke-width="${chartColor===c?4:2}"/><text x="${x}" y="${y+5}" fill="${COLORS[c]}">${symbols[c]}</text><text x="${x}" y="${y+30}" class="wheel-name">${c}</text></g>`;}).join('')}
    <text x="160" y="126" class="wheel-title">1,5×</text><text x="160" y="146" class="wheel-name">no sentido da seta</text></svg>`;
  return `<section class="match-chart"><h3>Mapa de afinidades</h3>${wheel}<div class="chart-modes">${['ataque','defesa'].map(m=>`<button class="ghost" data-mode="${m}" aria-pressed="${m===chartMode}">${m==='ataque'?'Atacando':'Defendendo'}</button>`).join('')}</div>
  <p>Escolha a cor de quem ${attack?'ataca':'defende'}.</p><div class="palette">${colors.map(c=>`<button style="--hue:${COLORS[c]}" data-color="${c}" aria-pressed="${c===chartColor}"><b>${symbols[c]}</b>${c}</button>`).join('')}</div>
  <h4>${attack?chartColor+' ataca':'Dano recebido por '+chartColor}</h4><div class="match-groups">${[2,1.5,.75,1].map(n=>{
    const targets=colors.filter(c=>mult(c)===n);
    return targets.length?`<div class="match-row"><strong>${n.toLocaleString('pt-BR')}×</strong><div>${targets.map(c=>`<span style="--hue:${COLORS[c]}"><b>${symbols[c]}</b> ${c}</span>`).join('')}</div></div>`:'';
  }).join('')}</div></section>`;
}
function traitEffects(trait){
  if(!trait)return [];
  const effects=trait.buffs.flatMap((v,i)=>v?[`+${Math.round(v*100)}% ${Object.values(statLabels)[i]}`]:[]);
  if(trait.passive)effects.push(trait.passive);
  return effects;
}
function renderProfile(){
  const unit=publicUnit??copy(profileUid);
  if(!unit){$('#character-profile').close();return;}
  const inTeam=state.team.includes(unit.uid);
  const stats=fighter(unit,undefined,inTeam?card(state.leader):null);
  const base=fighter(unit);
  const xp=xpProgress(unit.xp,publicUnit?100:levelCap(state));
  const trait=TRAITS.find(t=>t.name===unit.trait);
  const bonuses=traitEffects(trait);
  const content=`<header class="profile-title" style="--tone:${COLORS[stats.color]}">
    ${img(stats.sprite)}
    <div><p class="smallcaps">${stats.universe}</p><h2 id="profile-title">${stats.name}</h2>
    <p>${TIERS[stats.tier-1]} · ${stats.color} · ${stats.role} · ${unit.shiny?'Shiny':'Normal'}</p>
    <p><b>Serial ${serial(unit)}</b> · ${publicUnit?'Comunidade':inTeam?'Formação principal':'Reserva'}${state.leader===unit.uid?' · Líder':''}</p></div>
  </header>
  <div class="profile-grid">
    <section class="card"><h3>Atributos</h3>${inTeam?`<p class="caption">Bônus de liderança de ${card(state.leader).name} incluído quando aplicável.</p>`:''}
      <dl class="profile-stats">${Object.entries(statLabels).map(([key,label])=>{
        const boost=stats[key]-base[key];
        return `<div><dt>${label}</dt><dd>${int.format(stats[key])}${boost?` <small>(+${int.format(boost)})</small>`:''}</dd></div>`;
      }).join('')}</dl>
    </section>
    <section class="card"><h3>Nível ${xp.level}</h3>
      ${publicUnit?'':xp.required?`<label for="profile-xp">${xp.current} / ${xp.required} XP até o próximo nível</label><progress id="profile-xp" value="${xp.current}" max="${xp.required}"></progress>`:'<p>Nível máximo</p>'}
      <p class="caption">${int.format(unit.xp)} XP total</p>
      <h3>Habilidade</h3><p><b>${stats.skill}</b><br>${SKILL_EFFECTS[stats.kind]}</p>
      <h3>Efeito como líder</h3><p>${stats.leader}</p>
    </section>
    <section class="card"><h3>Trait</h3><p>${unit.trait??'Sem Trait'}</p>${trait?`<p>${trait.rarity} · 1 em ${int.format(trait.odds)} recrutáveis</p>`:''}
      ${!publicUnit&&unit.trait==='Voto de Nen'?`<button class="ghost" data-nen="${unit.uid}" ${inTeam&&!unit.nen&&formationCost(state)>=4?'disabled':''}>${unit.nen?'Desativar Última Aposta':inTeam&&formationCost(state)>=4?'Libere uma vaga para ativar':'Ativar Última Aposta'}</button>`:''}
      ${bonuses.length?`<ul>${bonuses.map(bonus=>`<li>${bonus}</li>`).join('')}</ul>`:''}
    </section>
    <section class="card"><h3>Recrutamento</h3><p>${unit.odds?`Chance registrada no encontro · 1 em ${int.format(unit.odds)}`:'Integrante inicial'}</p>
      ${unit.shiny?'<p class="caption">Shiny concede +25% a PV, Ataque, Magia, Defesa e Resistência.</p>':''}
    </section>
  </div>`;
  if(content===profileContent)return;
  profileContent=content;
  $('#profile-content').innerHTML=content;
}

let saleTier=1;
function renderPanel(){
  $('#gold').textContent=int.format(state.gold);
  $('#wins').textContent=int.format(state.wins);
  $('#collection-count').textContent=state.collection.length;
  document.querySelectorAll('[data-tab]').forEach(b=>{
    if(b.dataset.tab===tab)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');
  });
  const panel=$('#panel');
  const social=tab==='comunidade';
  const communityPanel=$('#community-panel');
  panel.hidden=social;
  const arena=$('.arena');
  if(arena)arena.hidden=tab!=='exploracao';
  const mode=$('#game-mode');
  if(mode)mode.textContent=community?.ready()?'Online':community?.active()?'Conectando':'Solo';
  if(social){
    if(communityPanel?.hidden)community?.mount();
    return;
  }
  community?.hide();
  if(tab==='arena'){duelPanel(panel);return;}
  if(tab==='exploracao'){
    const level=maxLevel(state),world=worldOf(state);
    panel.innerHTML=`<div class="layout"><article class="card"><div class="world-picker"><h2>Campanha</h2><label>Mundo <select id="world-select">${WORLDS.map((w,i)=>`<option value="${i}" ${i===(state.destination??state.world??0)?'selected':''} ${i>(state.unlocked??0)?'disabled':''}>${i+1} · ${w.name}${i>(state.unlocked??0)?' · Bloqueado':''}</option>`).join('')}</select></label></div><p class="caption">${state.destination!==undefined?'Viagem após o combate atual.':`Mundo ${(state.world??0)+1} de ${WORLDS.length}`}</p><p class="caption">Escolha uma área para procurar inimigos e personagens recrutáveis.</p><div class="area-list">${world.areas.map((a,i)=>`<button class="area-option" type="button" data-area="${i}" ${level<a.unlock?'disabled':''} aria-pressed="${state.area===i}"><span class="index-badge">${i+1}</span><span><strong>${a.name}</strong><small>${a.description}</small></span><em>${level<a.unlock?`Libera no nv. ${a.unlock}`:`Nv. ${a.levels[0]}–${a.levels[1]}`}</em></button>`).join('')}</div></article><aside><article class="card boss"><p class="smallcaps purple">CHEFE DO MUNDO</p><h3>${world.boss.name} <small>· Nv. ${world.boss.level}</small></h3><div class="meter"><i style="width:${Math.min(100,state.finalWins/12*100)}%"></i></div><p class="caption">${state.completed?(state.world===9?'Campanha concluída.':'Próximo mundo disponível no seletor.'):`${Math.min(12,state.finalWins)} / 12 vitórias em ${world.areas[2].name}`}</p><button class="primary" data-action="boss" ${!readyForBoss(state)||state.pending?'disabled':''}>${state.completed?'Chefe derrotado':state.pending?'Aguarde o fim da luta':'Desafiar chefe'}</button></article><article class="card"><h3>Últimos encontros</h3><ul class="activity">${state.log.length?state.log.slice(0,4).map(e=>`<li><span>${e.label}${e.reserveXp?`<small>+${e.reserveXp} XP entre reservas</small>`:''}</span><b ${!e.won?'class="loss"':''}>${e.won?`+${int.format(e.gold)} ouro`:'Derrota'}</b></li>`).join(''):'<li>Seus resultados aparecem aqui.</li>'}</ul></article></aside></div>`;
  }else if(tab==='formacao'){
    if(!state.team.includes(selected))selected=state.team[0];
    const slots=formationSlots(state);
    const active=state.leader?card(state.leader):null;
    const reserves=state.collection.filter(u=>!state.team.includes(u.uid));
    panel.innerHTML=`<div class="formation-layout"><article class="card formation-board"><h2>Formação de combate</h2>
      <p class="caption">Toque em um personagem para ver a ficha. Arraste para mudar sua posição.</p>
      <div class="field" id="field"><span class="field-label back">RETAGUARDA</span><span class="field-label">FRENTE</span>
      ${state.team.map(uid=>{const [x,y]=state.positions[uid];return `<button class="field-marker ${uid===selected?'active':''}" data-marker="${uid}" aria-label="Ficha de ${card(uid).name}. Use as setas para mover." style="left:${x}%;top:${y}%">${img(spriteFor(copy(uid)))}<small>${card(uid).name.split(' · ')[0]}</small></button>`;}).join('')}</div>
      <p class="caption">As mudanças entram em vigor no próximo combate.</p></article>
      <article class="card"><h2>Equipe principal</h2><p class="caption">${active?'Líder · '+active.name+' · '+active.leader:'Formação vazia. Escolha um personagem para explorar.'}</p>
      <div class="members">${slots.map((uid,i)=>!uid?`<button class="ghost slot-empty" data-vaga="${i}">＋ Vaga ${i+1} · Escolher na coleção</button>`:`<div class="member squad-row"><small>Vaga ${i+1}</small><button class="character-hit" data-profile="${uid}">${unitSummary(copy(uid))}</button>
        <button class="ghost" data-leader="${uid}" ${uid===state.leader?'disabled':''}>${uid===state.leader?'Líder':'Liderar'}</button>
        <span data-recovery="${uid}"></span><button class="ghost" data-remove="${uid}">Remover</button>
        ${reserves.length?`<label>Substituir <select data-replace="${uid}"><option value="">Escolher reserva</option>${reserves.map(r=>`<option value="${r.uid}">${CHARACTERS[r.id].name} · Nv. ${levelAt(r.xp)} · ${serial(r)}</option>`).join('')}</select></label>`:''}</div>`).join('')}</div></article></div>`;
  }else if(tab==='colecao'){
    const slots=formationSlots(state);
    const index=pickSlot??(slots.includes(null)?slots.indexOf(null):3);
    panel.innerHTML=`<article class="card"><div class="swap"><div><h2>Coleção</h2><p class="caption">${state.collection.length} personagens recrutados</p></div><label>Vaga de destino <select id="swap-target">${slots.map((uid,i)=>`<option value="${i}" ${index===i?'selected':''}>${i+1} · ${uid?card(uid).name:'Vazia'}</option>`).join('')}</select></label></div><div class="collection-grid">${state.collection.map(unit=>{
      const c=CHARACTERS[unit.id];
      return `<div class="collection-card" style="--tone:${COLORS[c.color]}"><button class="character-hit" data-profile="${unit.uid}">${unitSummary(unit)}</button><p>${c.role} · ${c.skill}${unit.trait?` · ${unit.trait}`:''}</p><div class="collection-actions"><button class="ghost" data-equip="${unit.uid}" data-slot="${index}" data-occupant="${slots[index]??''}" ${state.team.includes(unit.uid)?'disabled':''}>${state.team.includes(unit.uid)?'Na equipe':slots[index]?'Substituir na vaga '+(index+1):'Colocar na vaga '+(index+1)}</button></div></div>`;
    }).join('')}</div></article>`;
  }else if(tab==='guia'){
    panel.innerHTML=`<article class="card guide"><h2>Guia de combate</h2>${colorChart()}
    <h3>Funções</h3><ul><li><b>Combatente</b> · Ataque elevado e golpes básicos físicos.</li><li><b>Guardião</b> · Mais PV e defesa. Seus golpes básicos são físicos.</li><li><b>Mágico</b> · Usa Magia nos golpes básicos e enfrenta a Resistência do alvo.</li><li><b>Suporte</b> · Usa Magia nos golpes básicos. Na reserva da Arena, cura o aliado ativo.</li></ul>
    <h3>Formação e liderança</h3><p>Na exploração, os titulares lutam juntos. Na Arena, entra um por vez, na ordem das vagas ocupadas. Escolha o líder na Formação e consulte a ficha para ver quem recebe o bônus.</p>
    <h3>Raridade e traits</h3><p>${TIERS.join(' → ')}. Na ficha, você encontra a raridade, a versão Shiny e os bônus da trait de cada cópia.</p><h3>Traits e efeitos</h3><p>A chance indica quantos personagens recrutáveis, em média, correspondem a uma ocorrência da trait.</p><div class="trait-list">${TRAITS.map(t=>`<section><header><strong>${t.name}</strong><small>${t.rarity} · 1/${int.format(t.odds)} · ${(100/t.odds).toLocaleString('pt-BR',{maximumFractionDigits:3})}%</small></header><p>${traitEffects(t).slice(0,t.buffs.filter(Boolean).length).join(' · ')}</p>${t.passive?`<p>${t.passive}</p>`:''}</section>`).join('')}</div></article>`;
  }else if(tab==='configuracoes'){
    const sale=state.autoSell??{},rule=sale.traitRules?.[saleTier]??{below:0,names:[]},traitsOpen=panel.querySelector('#sale-traits')?.open,open=panel.querySelector('#sale-characters')?.open;

    panel.innerHTML=`<article class="card settings"><h2>Configurações</h2>
      <label><input type="checkbox" id="auto-play" ${!state.paused?'checked':''}> Exploração automática</label><p class="caption">Parar conclui a luta em andamento e suspende os próximos encontros, inclusive AFK.</p>
      <label><input type="checkbox" id="auto-routes" ${state.autoRoutes?'checked':''}> Avançar de área ao atingir o nível necessário</label><p class="caption">Escolher uma área manualmente fixa a rota atual.</p>
      <h3>Venda automática de cópias</h3><label><input type="checkbox" data-sale="enabled" ${sale.enabled?'checked':''}> Vender novas cópias selecionadas</label>
      <p class="caption">Escolha raridades ou personagens. A primeira cópia de cada combinação de personagem, versão normal ou Shiny e trait fica na coleção. A venda só acontece quando outra cópia igual é recrutada.</p>
      <fieldset class="sale-options"><legend>Raridade e preço por cópia</legend>${TIERS.map((name,i)=>`<label><input type="checkbox" data-sale="tiers" value="${i+1}" ${sale.tiers?.includes(i+1)?'checked':''}> ${name} · ${int.format(SALE_PRICES[i])} ouro</label>`).join('')}</fieldset>
      <details id="sale-characters" ${open?'open':''}><summary>Selecionar personagens (${sale.characters?.length??0})</summary><div class="sale-options">${Object.values(CHARACTERS).sort((x,y)=>x.name.localeCompare(y.name,'pt-BR')).map(c=>`<label><input type="checkbox" data-sale="characters" value="${c.id}" ${sale.characters?.includes(c.id)?'checked':''}> ${c.name}</label>`).join('')}</div></details>
      <details id="sale-traits" ${traitsOpen?'open':''}><summary>Exceções para cópias com trait</summary><p class="caption">Por padrão, toda cópia com trait fica na coleção. As exceções abaixo só valem para personagens selecionados para venda, dentro da raridade indicada.</p>
      <label>Raridade do personagem <select id="sale-trait-tier">${TIERS.map((n,i)=>`<option value="${i+1}" ${saleTier===i+1?'selected':''}>${n}</option>`).join('')}</select></label>
      <label>Vender traits mais frequentes que <select id="sale-trait-limit"><option value="0">Nenhuma por frequência</option>${[...new Set([5,10,20,25,30,50,100,125,200,250,500,1000,2000,2001,rule.below])].filter(Boolean).sort((a,b)=>a-b).map(n=>`<option value="${n}" ${n===rule.below?'selected':''}>1/${int.format(n)}</option>`).join('')}</select></label>
      <p class="caption">Com o limite 1/30, uma cópia 1/25 pode ser vendida. Uma 1/30 ou mais rara fica protegida, salvo se você marcar a trait pelo nome.</p>
      <fieldset class="sale-options"><legend>Também permitir estas traits em personagens de raridade ${TIERS[saleTier-1]}</legend>${TRAITS.map(t=>`<label><input type="checkbox" data-sale-trait="${t.name}" ${rule.names.includes(t.name)?'checked':''}> ${t.name} · 1/${int.format(t.odds)}</label>`).join('')}</fieldset></details>
      <h3>Exibição neste dispositivo</h3><label><input type="checkbox" data-pref="motion" ${preferences.motion?'checked':''}> Animações de combate</label>
      <label><input type="checkbox" data-pref="numbers" ${preferences.numbers?'checked':''}> Números de dano na arena</label></article>`;
  }else{
    panel.innerHTML=`<article class="card"><h2>Upgrades de exploração</h2>${Object.entries(UPGRADES).map(([id,upgrade])=>{
      const level=upgradeLevel(state,id);
      const price=upgrade.costs[level];
      const world=upgrade.worlds[level];
      const locked=world>(state.unlocked??0)+1;
      const effect=index=>`${id==='ouro'?'+':''}${upgrade.values[index]}${upgrade.unit}`;
      return `<div class="upgrades-row"><div><h3>${upgrade.name} <small>Nível ${level} / ${upgrade.costs.length}</small></h3><p>${upgrade.description}</p><p class="upgrade-effect">${effect(level)}${price===undefined?'':` → ${effect(level+1)}`}</p></div><button class="primary" data-upgrade="${id}" aria-label="${upgrade.name} · ${price===undefined?'Nível máximo':`Comprar por ${int.format(price)} ouro`}" ${price===undefined||locked||state.gold<price?'disabled':''}>${price===undefined?'Nível máximo':`${int.format(price)} ouro${locked?' · Mundo '+world:''}`}</button></div>`;
    }).join('')}</article>`;
  }
}

function stageUnit(u,token,enemy=false){
  const x=enemy?79:12+u.x*.49;
  const y=enemy?62:27+u.y*.56;
  const tag=enemy?'div':'button';
  return `<${tag} ${enemy?'':`data-profile="${u.uid}" aria-label="Abrir ficha de ${u.name}"`} class="battler ${enemy?'enemy':''}" data-actor="${token}" style="--x:${x}%;--y:${y}%;--z:${Math.ceil(y)}"><span class="tag">${u.name} <small>· ${u.level}</small></span><div class="hp-track"><b></b></div><img class="sprite" src="${spriteURL(u.sprite)}" alt=""></${tag}>`;
}
function drawScene(now){
  const activeBattle=state.pending;
  const finish=!activeBattle&&finishedBattle&&now<finishedBattle.battle.end+1800?finishedBattle:null;
  const battle=activeBattle??finish?.battle;
  const world=WORLDS[battle?.world??state.world??0];
  const key=battle?`battle-${battle.start}-${battle.boss}`:'idle-'+state.team.filter(uid=>readyAt(state,uid)<=now).join(',')+JSON.stringify(state.positions)+state.area+state.completed+world.name;
  if(key!==stageKey){
    stageKey=key;replay=battle;eventCursor=0;
    const team=battle?.team??state.team.filter(uid=>readyAt(state,uid)<=now).map(uid=>fighter(copy(uid),state.positions[uid]));
    const foe=battle?.enemy??{name:world.areas[state.area].enemy,level:world.areas[state.area].levels[0],sprite:'soldier'};
    $('#stage').innerHTML=team.map((u,i)=>stageUnit(u,`0:${i}`)).join('')+(battle?stageUnit(foe,'1:0',true):'');
    $('#combat-note').textContent=battle?.recruit?'ENCONTRO RECRUTÁVEL':'';
  }
  const duration=battle?Math.max(1,battle.end-battle.start):1;
  const elapsed=battle?Math.max(0,Math.min(now-battle.start,duration)):0;
  const replayRate=battle?battle.result.seconds*1000/duration:1;
  const replayTime=elapsed*replayRate;
  if(replay){
    const events=replay.result.events;
    while(eventCursor<events.length&&events[eventCursor].time<=replayTime+.00001){
      const e=events[eventCursor++];
      const source=$(`[data-actor="${e.actor}"]`);
      const target=$(`[data-actor="${e.target}"]`);
      const updateHp=(node,id,current)=>{
        const max=id==='1:0'?replay.enemy.hp:replay.team[Number(id?.split(':')[1])]?.hp;
        if(node&&max) {node.querySelector('.hp-track b').style.width=`${Math.max(0,100*current/max)}%`;node.classList.toggle('ko',current<=0);}
      };
      if(e.type==='dano'){
        updateHp(target,e.target,e.remaining);
        if((replayTime-e.time)/replayRate<650&&target&&e.hp>0){
          pulse(source,'attack');pulse(target,'hit');
          if(!preferences.numbers)continue;
          const hit=document.createElement('span');hit.className='float';hit.textContent=`−${Math.round(e.hp)}`;target.append(hit);setTimeout(()=>hit.remove(),670);
        }
      }
      if(['cura','sobrevive','ressurge'].includes(e.type))updateHp(source,e.actor,e.remaining);
      if(e.type==='onda'&&(replayTime-e.time)/replayRate<700)$('#combat-note').textContent='ONDA DE ENERGIA';
    }
  }
  const recoverAt=Math.min(...state.team.map(uid=>readyAt(state,uid)));
  const recovering=!battle&&state.running&&state.team.length&&recoverAt>now;
  const waiting=state.team.length>0&&state.running&&!activeBattle;
  $('#arena-status').textContent=finish?(finish.entry.won?'VITÓRIA':'DERROTA'):battle?.boss?'DESAFIO DE CHEFE':battle?.elite?'ENCONTRO DE ELITE':battle?'EM COMBATE':recovering?'EM RECUPERAÇÃO':waiting?'PRÓXIMO ENCONTRO':state.team.length?'EXPLORAÇÃO PARADA':'FORMAÇÃO VAZIA';
  $('#world-title').textContent=world.name;
  $('.arena').dataset.world=String(battle?.world??state.world??0);
  $('#arena-location').textContent=world.areas[battle?.area??state.area].name;
  $('#arena-time').textContent=time(activeBattle?elapsed:recovering?recoverAt-now:waiting?state.nextAt-now:0);
  $('#arena-label').textContent=finish?(finish.entry.won?`+${int.format(finish.entry.gold)} ouro · +${finish.entry.xp} XP por titular${finish.entry.reserveXp?` · +${finish.entry.reserveXp} XP entre reservas`:''}`:`Derrota contra ${battle.enemy.name}`):battle?`Enfrentando ${battle.enemy.name}`:recovering?'Aguardando a recuperação da equipe.':waiting?'O time está procurando um adversário.':state.team.length?'Exploração parada. Reative em Configurações.':'Coloque um personagem na formação para explorar.';
  $('#fight-progress').style.width=`${battle?100*elapsed/duration:waiting?Math.max(0,Math.min(100,100*(1-(state.nextAt-now)/(state.waitDuration||waitFor(state))))):0}%`;
  const toggle=$('#explore-toggle');
  toggle.hidden=!!state.paused;
}

function openUnit(uid,button){
  if(!copy(uid))return;
  publicUnit=null;profileUid=uid;profileOpener=button;
  renderProfile();
  if(!$('#character-profile').open)$('#character-profile').showModal();
}
function pulse(node,cls){
  if(!node)return;
  node.classList.remove(cls);void node.offsetWidth;node.classList.add(cls);
  setTimeout(()=>node.classList.remove(cls),300);
}

document.addEventListener('click',e=>{
  const b=e.target.closest('button');if(!b)return;
  if(b.dataset.tab){tab=b.dataset.tab;pickSlot=null;history.replaceState(null,'',`#${tab}`);renderPanel();return;}
  if(b.dataset.nen){const u=copy(b.dataset.nen);if(u)void transaction({type:'nen',uid:u.uid,enabled:!u.nen});}
  if(b.dataset.color||b.dataset.mode){
    if(b.dataset.color)chartColor=b.dataset.color;else chartMode=b.dataset.mode;
    const attribute=b.dataset.color?'color':'mode';renderPanel();document.querySelector(`[data-${attribute}="${b.dataset[attribute]}"]`)?.focus();
  }
  if(b.id==='duel-start')startDuel();
  if(b.id==='duel-train'){duel=null;rival=null;renderPanel();}
  if(b.id==='explore-toggle')void transaction({type:'pause'});
  if(b.dataset.area!==undefined)void transaction({type:'area',area:Number(b.dataset.area)});
  if(b.dataset.leader)void transaction({type:'leader',uid:b.dataset.leader});
  if(b.dataset.remove)void transaction({type:'remove',uid:b.dataset.remove});
  if(b.dataset.vaga!==undefined){pickSlot=Number(b.dataset.vaga);tab='colecao';history.replaceState(null,'','#colecao');renderPanel();}
  if(b.dataset.equip){
    const uid=b.dataset.equip,slot=Number(b.dataset.slot);
    void transaction({type:'equip',uid,slot,replaced:b.dataset.occupant||null}).then(()=>{
      if(formationSlots(state)[slot]===uid&&tab==='colecao'){pickSlot=null;tab='formacao';history.replaceState(null,'','#formacao');renderPanel();}
    });
  }
  if(b.dataset.action==='boss')void transaction({type:'boss'});
  if(b.dataset.upgrade)void transaction({type:'upgrade',id:b.dataset.upgrade});
  if(b.dataset.publicUnit){
    publicUnit=JSON.parse(b.dataset.publicUnit);profileUid=null;profileOpener=b;
    renderProfile();$('#character-profile').showModal();
  }
  if(b.dataset.profile)openUnit(b.dataset.profile,b);
  if(b.dataset.marker&&e.detail===0)openUnit(b.dataset.marker,b);
  if(b.id==='close-profile')$('#character-profile').close();
  if(b.id==='install'&&installPrompt){void installPrompt.prompt();installPrompt=null;b.hidden=true;}
});
$('#character-profile').addEventListener('close',()=>{
  const uid=profileUid;
  publicUnit=null;profileUid=null;
  if(profileOpener?.isConnected)profileOpener.focus();
  else $(`[data-profile="${uid}"]`)?.focus();
  profileOpener=null;
});
document.addEventListener('change',e=>{const target=e.target;
  if(target.id==='swap-target'){pickSlot=Number(target.value);renderPanel();}
  if(target.id==='world-select')void transaction({type:'world',index:Number(target.value)});
  if(target.dataset.replace&&target.value)void transaction({type:'equip',uid:target.value,replaced:target.dataset.replace});
  if(target.id==='sale-trait-tier'){saleTier=Number(target.value);renderPanel();return;}
  if(target.id==='sale-trait-limit')void transaction({type:'saleTrait',tier:saleTier,below:Number(target.value)});
  if(target.dataset.saleTrait)void transaction({type:'saleTrait',tier:saleTier,name:target.dataset.saleTrait,checked:target.checked});
  if(target.dataset.sale)void transaction({type:'saleSetting',group:target.dataset.sale,value:target.dataset.sale==='tiers'?Number(target.value):target.value,checked:target.checked});
  if(target.id==='auto-play')void transaction({type:target.checked?'resume':'pause'});
  if(target.id==='auto-routes')void transaction({type:'autoRoutes',enabled:target.checked});
  if(target.dataset.pref){
    preferences[target.dataset.pref]=target.checked;
    document.documentElement.dataset.motion=preferences.motion?'on':'off';
    try{localStorage.setItem('nexus.display',JSON.stringify(preferences));}catch{}
  }});
document.addEventListener('keydown',e=>{
  const uid=e.target.dataset.marker;
  const direction={ArrowLeft:[-5,0],ArrowRight:[5,0],ArrowUp:[0,-5],ArrowDown:[0,5]}[e.key];
  if(!uid||!direction)return;
  e.preventDefault();selected=uid;
  void transaction({type:'position',uid,coords:state.positions[uid].map((v,i)=>v+direction[i])}).then(()=>$(`[data-marker="${uid}"]`)?.focus());
});
function point(e,field){const r=field.getBoundingClientRect();return [100*(e.clientX-r.left)/r.width,100*(e.clientY-r.top)/r.height].map(v=>Math.round(Math.max(8,Math.min(92,v))));}
document.addEventListener('pointerdown',e=>{
  const field=e.target.closest('#field');if(!field)return;
  const marker=e.target.closest('[data-marker]');
  if(marker){selected=marker.dataset.marker;drag={field,marker,id:e.pointerId,moved:false,x:e.clientX,y:e.clientY};field.setPointerCapture(e.pointerId);}
  else void transaction({type:'position',uid:selected,coords:point(e,field)});
});
document.addEventListener('pointermove',e=>{
  if(drag?.id!==e.pointerId)return;
  if(Math.hypot(e.clientX-drag.x,e.clientY-drag.y)>3)drag.moved=true;
  if(drag.moved){const [x,y]=point(e,drag.field);drag.marker.style.left=`${x}%`;drag.marker.style.top=`${y}%`;}
});
document.addEventListener('pointerup',e=>{
  if(drag?.id!==e.pointerId)return;
  const {field,moved,marker}=drag;drag=null;
  if(moved)void transaction({type:'position',uid:selected,coords:point(e,field)});else openUnit(selected,marker);
});
document.addEventListener('pointercancel',()=>{drag=null;renderPanel();});
addEventListener('hashchange',()=>{if(validTabs.includes(location.hash.slice(1))){tab=location.hash.slice(1);renderPanel();}});
addEventListener('storage',e=>{if(e.key===saveKey&&!busy&&!community?.active()){state=load()??state;if(!drag)renderPanel();if(profileUid)renderProfile();}});
addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;$('#install').hidden=false;});
if(location.protocol!=='file:'&&'serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});

renderPanel();
let saveTick=Date.now();
function observe(){
  if(document.hidden)return;
  const now=Date.now(),returned=lastObservation===null||now-lastObservation>=AWAY_THRESHOLD;
  lastObservation=now;
  if(returned||state.awayReports?.length&&!$('#away-dialog').open)void transaction(null,true);
}
for(const event of ['pointerdown','keydown','pointermove','wheel'])document.addEventListener(event,observe,{passive:true});
addEventListener('focus',()=>{observe();void transaction(null,true);});
$('#away-dialog').addEventListener('cancel',event=>{event.preventDefault();$('#away-continue').click();});
$('#away-continue').addEventListener('click',()=>{const report=state.awayReports?.[0];if(report)void transaction({type:'dismissAway',end:report.end});});
const wasAway=gameNow()-state.clock>=AWAY_THRESHOLD;
void transaction(null,wasAway).then(()=>{renderPanel();drawScene(gameNow());});
setInterval(()=>{
  if(document.hidden)return;
  const now=gameNow();

  if(!busy&&(state.pending?.end<=now||state.team.length&&state.running&&!state.pending&&Math.max(state.nextAt,Math.min(...state.team.map(uid=>readyAt(state,uid))))<=now||Date.now()-saveTick>(community?.ready()?8000:12000))){
    saveTick=Date.now();void transaction(null,now-state.clock>45000).then(()=>{
      if(tab==='exploracao'&&($('#panel [data-action="boss"]')?.disabled??true)!==(!readyForBoss(state)||!!state.pending))renderPanel();
    });
  }
  if(tab==='arena')updateDuelButton();
  if(tab==='formacao')document.querySelectorAll('[data-recovery]').forEach(el=>{
    const left=readyAt(state,el.dataset.recovery)-now;
    el.textContent=left>0?'Recupera em '+Math.ceil(left/1000)+' s':'';
  });
  if(tab==='exploracao'){
    drawScene(now);
    const boss=$('#panel [data-action="boss"]');
    if(boss)boss.disabled=!readyForBoss(state)||!!state.pending||state.team.every(uid=>readyAt(state,uid)>now);
  }
  community?.tick();
},130);

document.addEventListener('visibilitychange',()=>{
  if(!document.hidden)observe();
  saveTick=Date.now();void transaction(null,!document.hidden);
});
