import {affinity} from "./engine.js";
import {saleSettings,canSellUnit,formationCost,leaderApplies,RECOVERY_MS,SALE_PRICES,readyAt,formationSlots,spriteFor,projectedPower,unitPower,WORLDS,worldOf,levelCap,CHARACTERS,COLORS,SKILL_EFFECTS,TIERS,TRAITS,UPGRADES,AWAY_THRESHOLD,advanceWithPresence,advance,applyGameAction,fighter,fresh,levelAt,maxLevel,readyForBoss,upgradeLevel,waitFor,xpProgress} from './game.js';
import {collisionBonus,collisionPower,createDuel,stepDuel} from './duel.js';
import {createCommunity} from './community.js';

import {isUnreadableCampaign,saveKey,readCampaign,writeCampaign,packCampaign,unpackCampaign} from './save.js';
const $ = selector=>document.querySelector(selector);
const int = new Intl.NumberFormat('pt-BR');
const validTabs=['exploracao','formacao','colecao','configuracoes','upgrades','comunidade','arena','guia'];
const time = milliseconds=>{const sec=Math.max(0,Math.ceil(milliseconds/1000));return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`;};
const copy=id=>state.collection.find(c=>c.uid===id);
const card=id=>CHARACTERS[copy(id).id];
const isPaused=()=>Boolean(state.paused??!state.running);
let preferences={motion:true,numbers:true};
try{preferences={...preferences,...JSON.parse(localStorage.getItem('nexus.display')||'{}')};}catch{}
document.documentElement.dataset.motion=preferences.motion?'on':'off';
const spriteURL = name => `art/${name}.png`;
const img=(sprite,alt='')=>`<img src="${spriteURL(sprite)}" alt="${alt}">`;
const note = text=> { const box=$('#notice');box.textContent=text;box.hidden=!text; };

let storageIssue='';
let blockedCampaign=false;
let storageFailed=false;
function load(){
  try { const value=readCampaign(localStorage);storageIssue='';blockedCampaign=false;return value; }
  catch(error){
    blockedCampaign=isUnreadableCampaign(error);
    storageIssue=blockedCampaign?error.message:'O navegador bloqueou o armazenamento. Exporte seu progresso em Configurações.';
    return null;
  }
}
const initialSave=load();
let state=initialSave??fresh(Date.now(),crypto.getRandomValues(new Uint32Array(1))[0]);
let selected=state.team[0];
let pickSlot=null;
let tab=validTabs.includes(location.hash.slice(1))?location.hash.slice(1):'exploracao';
let replay=null, finishedBattle=null, eventCursor=0, stageKey='', busy=false, drag=null, installPrompt=null;
let transactionQueue=Promise.resolve();
let publicUnit=null, profileUid=null, profileOpener=null, profileContent='';
let serverOffset=0;
const gameNow=()=>Date.now()+serverOffset;
let duel=null,rival=null,frameTime=0,carry=0;
function loadArenaRecovery(){
  try{return JSON.parse(localStorage.getItem('nexus.arena.recovery.'+state.created))??{};}catch{return {};}
}
let arenaRecovery=loadArenaRecovery();
function arenaReadyAt(uid){return Math.max(arenaRecovery[uid]??0,arenaRecovery.all??0);}
function arenaWait(){return Math.min(...state.team.map(arenaReadyAt))-gameNow();}
function playerSquad(){
  const leader=CHARACTERS[copy(state.leader)?.id];
  return state.team.filter(uid=>arenaReadyAt(uid)<=gameNow()).map(uid=>fighter(copy(uid),undefined,arenaReadyAt(state.leader)<=gameNow()?leader:null));
}
function startDuel(){
  const team=playerSquad();
  if(!team.length||rival?.team.length===0){renderPanel();note('As duas equipes precisam ter pelo menos um personagem.');return;}
  const ids=['yamcha','kuririn','bulma','piccolo'];
  const opponent=rival?.team??team.map((u,i)=>fighter({id:ids[i],xp:copy(u.uid).xp},undefined,CHARACTERS.yamcha));
  duel=createDuel(team,opponent);
  frameTime=0;carry=0;
  renderPanel();
}
function duelPanel(panel){
  if(!panel.querySelector('#duel-field')){
    panel.innerHTML='<article class="card duel-card"><h2>Arena das bolas</h2><p class="caption">Cada acerto por colisão soma 12 pontos percentuais ao bônus de dano da próxima colisão, até +40%. As reservas ajudam a cada 8 s e entram na ordem da formação. Aos dois minutos, vence a equipe com mais PV proporcionais restantes.</p><strong id="duel-rival"></strong><div id="duel-field"><i></i><i></i><div class="damage-popups" aria-hidden="true"></div></div><div id="duel-teams"></div><p role="status" id="duel-status"></p><div id="duel-log"></div><ul id="damage-feed" aria-label="Últimos golpes"></ul><button class="primary" id="duel-start"></button> <button class="ghost" id="duel-train">Voltar ao treino</button></article>';
  }
  $('#duel-rival').textContent=rival?'Desafio contra '+rival.name:'Treino · Equipe de Namek';
  updateDuelButton();
  paintDuel();
}
function updateDuelButton(){
  const btn=$('#duel-start');if(!btn)return;
  $('#duel-train').hidden=!rival;
  btn.disabled=arenaWait()>0||!state.team.length||rival?.team.length===0||!!duel&&duel.result===null;
  btn.textContent=duel&&duel.result===null?'Duelo em andamento':state.team.length&&arenaWait()>0?'Recuperação · '+Math.ceil(arenaWait()/1000)+' s':duel?'Jogar novamente':'Começar duelo';
}
const damageNumber=new Intl.NumberFormat('pt-BR',{maximumFractionDigits:1});
function damageText(n){return n>0&&n<.1?'<0,1':damageNumber.format(n);}
function drawDamage(field){
  const list=$('#damage-feed'),layer=field.querySelector('.damage-popups');
  const latest=duel.damageFeed[0]?.seq??-1;
  if(layer.match===duel&&layer.seen===latest)return;
  const seen=layer.match===duel?layer.seen:-1;
  if(layer.match!==duel){layer.replaceChildren();layer.match=duel;}
  layer.seen=latest;
  list.replaceChildren(...duel.damageFeed.slice(0,5).map(hit=>{
    const li=document.createElement('li');li.dataset.side=hit.side;
    li.textContent=`${hit.side?'Inimigo':'Você'} · ${hit.source} → ${hit.target} · −${damageText(hit.amount)} PV`;
    return li;
  }));
  if(!preferences.numbers)return;
  for(const hit of duel.damageFeed.filter(h=>h.seq>seen).reverse()){
    const pop=document.createElement('span');pop.dataset.side=hit.side;
    pop.textContent=`${hit.source} −${damageText(hit.amount)}`;
    layer.append(pop);
    const group=layer.querySelectorAll(`[data-side="${hit.side}"]`);
    if(group.length>3)group[0].remove();
    setTimeout(()=>pop.remove(),1500);
  }
}
function paintDuel(){
  const field=$('#duel-field');if(!field)return;
  if(!duel){
    field.hidden=true;$('#damage-feed').replaceChildren();$('#duel-status').textContent=state.team.length?'Sua formação está pronta.':'Escolha um personagem na coleção para começar.';
    $('#duel-teams').textContent=playerSquad().map(u=>u.name).join(' → ');$('#duel-log').textContent='';return;
  }
  field.hidden=false;
  drawDamage(field);
  const rows=duel.sides.map((s,i)=>{
    const f=s.team[s.slot],ball=field.children[i];
    ball.hidden=!f;
    if(f){
      const x=preferences.motion?s.x:i?75:25,y=preferences.motion?s.y:25;
      ball.style.left=x+'%';ball.style.top=2*y+'%';
      ball.style.backgroundColor=COLORS[f.color];if(ball.dataset.sprite!==f.sprite){ball.dataset.sprite=f.sprite;ball.style.backgroundImage='url("'+spriteURL(f.sprite)+'")';}
    }
    return '<section><small>'+(i?'ADVERSÁRIO':'SUA FORMAÇÃO')+'</small><strong>'+(f?.name??'Equipe eliminada')+'</strong>'+(f?'<progress max="'+f.maxHp+'" value="'+Math.ceil(f.hp)+'"></progress><small>'+Math.ceil(f.hp)+'/'+f.maxHp+' PV</small><b class="collision-power">Dano de colisão · '+damageText(collisionPower(duel,f))+'</b><small>+'+collisionBonus(f.hits)+'% por colisões · antes da defesa e da afinidade</small>':'')+'<small>Reserva · '+(s.team.slice(s.slot+1).map(u=>u.name).join(', ')||'—')+'</small></section>';
  }).join('');
  if($('#duel-teams').innerHTML!==rows)$('#duel-teams').innerHTML=rows;
  $('#duel-status').textContent=duel.result??('Em combate · '+Math.floor(duel.t)+' s');
  $('#duel-log').textContent=duel.events.slice(0,3).join('  •  ');
}
function duelFrame(now){
  if(tab==='arena'&&!document.hidden&&duel&&duel.result===null){
    carry+=frameTime?Math.min(.15,(now-frameTime)/1000):0;frameTime=now;
    const home=duel.sides[0],previousSlot=home.slot;
    while(carry>=1/60&&duel.result===null){stepDuel(duel);carry-=1/60;}
    if(previousSlot!==home.slot){
      const until=gameNow()+RECOVERY_MS;
      for(const f of home.team.slice(previousSlot,home.slot))arenaRecovery[f.uid]=until;
      if(home.slot===home.team.length)arenaRecovery.all=until;
      try{localStorage.setItem('nexus.arena.recovery.'+state.created,JSON.stringify(arenaRecovery));}catch{}
    }
    if(duel.result!==null)duelPanel($('#panel'));else paintDuel();
  }else frameTime=0;
  requestAnimationFrame(duelFrame);
}
requestAnimationFrame(duelFrame);

const community=createCommunity({spriteURL,onChallenge(profile){
  rival={name:profile.name,team:profile.team.map(u=>fighter(u,undefined,CHARACTERS[profile.leaderId]))};
  duel=null;tab='arena';history.replaceState(null,'','#arena');startDuel();
},onSession(data){
  duel=null;rival=null;
  state=data?.state??load()??fresh(Date.now(),crypto.getRandomValues(new Uint32Array(1))[0]);
  arenaRecovery=loadArenaRecovery();
  serverOffset=data?data.now-Date.now():0;
  saveTick=Date.now();
  stageKey='';finishedBattle=null;
  selected=state.team[0];pickSlot=null;
  renderPanel();
  drawScene(gameNow());
}});

const serial=unit=>`#${String(unit.serial).padStart(3,'0')}`;
const statLabels={hp:'PV',attack:'Ataque',magic:'Magia',defense:'Defesa',resistance:'Resistência',speed:'Velocidade'};
function store(){
  if(storageIssue){note(storageIssue);return false;}
  try {writeCampaign(localStorage,state);storageFailed=false;return true;}
  catch{storageFailed=true;note('Não foi possível salvar neste navegador. Exporte seu progresso em Configurações.');return false;}
}
async function exportCampaign(){
  await transaction(null);
  if(community?.active())return;
  const url=URL.createObjectURL(new Blob([packCampaign(state)],{type:'application/json'}));
  const link=document.createElement('a');
  link.href=url;link.download='nexus-progresso-'+new Date().toISOString().slice(0,10)+'.json';
  link.click();setTimeout(()=>URL.revokeObjectURL(url),30000);
}
async function importCampaign(file){
  if(!file||community?.active())return;
  try{
    const candidate=unpackCampaign(await file.text(),CHARACTERS,WORLDS);
    const message=`Restaurar a campanha com ${int.format(candidate.gold)} ouro e ${candidate.collection.length} personagens? Isso substituirá o progresso solo aberto neste navegador.`;
    if(!confirm(message))return;
    const restore=()=>{
      if(community?.active())return;
      writeCampaign(localStorage,candidate);
      location.reload();
    };
    transactionQueue=transactionQueue.then(()=>navigator.locks?navigator.locks.request(saveKey,restore):restore()).catch(()=>note('O navegador não conseguiu gravar o backup.'));
    await transactionQueue;
  }catch{note('Não foi possível ler este backup do Nexus. A campanha atual foi preservada.');}
}
function receive(entries,offline=false){
  if(!entries.length)return;
  if(state.awayReports?.length)return;
  if(offline){
    const wins=entries.filter(e=>e.won).length;
    const recruits=entries.filter(e=>e.recruit).map(e=>CHARACTERS[e.recruit.id].name);
    const gold=entries.reduce((a,e)=>a+e.gold,0);
    note(`Progresso AFK · ${wins} vitórias em ${entries.length} lutas · +${int.format(gold)} ouro${recruits.length?` · ${recruits.length} recrutados (${recruits.slice(0,3).join(', ')}${recruits.length>3?'…':''})`:''}.`);
    return;
  }
  const last=entries.at(-1);
  if(last.sold)note(`Cópia de ${CHARACTERS[last.sold.id].name} vendida por ${int.format(last.saleGold)} ouro.`);
  else if(last.recruit){const r=last.recruit;note(`${CHARACTERS[r.id].name}${r.shiny?' Shiny':''} #${String(r.serial).padStart(3,'0')} entrou para a coleção${r.trait?` · ${r.trait}`:''}.`);}
  else if(last.boss)note(last.won?`Vitória sobre ${last.label}! Confira os destinos da campanha.`:`Derrota contra ${last.label}. Ajuste a formação para a próxima tentativa.`);
}

let lastObservation=document.hidden?null:Date.now();
let sentObservation=null;
let renderedReport='';
function showAway(){
  const dialog=$('#away-dialog'),r=state.awayReports?.[0];
  if(!r){if(dialog.open)dialog.close();renderedReport='';return;}
  if(document.hidden||!document.hasFocus())return;
  if(renderedReport!==String(r.start)+'/'+r.end){
    renderedReport=String(r.start)+'/'+r.end;
    const minutes=Math.floor((r.end-r.start)/60000);
    $('#away-time').textContent=(minutes>=60?Math.floor(minutes/60)+' h ':'')+(minutes%60)+' min de ausência'+(minutes>720?' · limite de exploração de 12 h':'');
    const byUid=new Map(state.collection.map(u=>[u.uid,u]));
    const recruits=Array.isArray(r.recruitUids)?r.recruitUids.map(uid=>byUid.get(uid)).filter(Boolean):state.collection.slice(r.firstRecruit,r.lastRecruit);
    $('#away-stats').innerHTML=[[r.encounters,'Encontros'],[r.wins,'Vitórias'],[recruits.length,'Mantidos na coleção'],[r.sold??0,'Cópias vendidas'],[r.saleGold??0,'Ouro de vendas (incluído no total)'],[r.gold,'Ouro'],[r.teamXp,'XP dos titulares'],[r.reserveXp,'XP dos reservas']].map(([v,label])=>`<div><strong>${int.format(v)}</strong><small>${label}</small></div>`).join('');
    $('#away-recruits').innerHTML=recruits.length?recruits.map(u=>{
      const c=CHARACTERS[u.id];return `<li style="--tone:${COLORS[c.color]}">${img(spriteFor(u))}<strong>${c.name}${u.shiny?' ✦':''}</strong><small>${TIERS[c.tier-1]} · ${serial(u)}</small></li>`;
    }).join(''):'<li>Nenhum personagem recrutado neste período.</li>';
  }
  if(!dialog.open)dialog.showModal();
}
function transaction(action,offline=false){
  let ok=false;
  function commit(){
    if(!storageFailed)state=load()??state;
    if(blockedCampaign){note(storageIssue);return;}
    const now=Date.now();
    const previousBattle=state.pending;
    const entries=advanceWithPresence(state,now,lastObservation);
    const lastEntry=entries.at(-1);
    if(previousBattle&&lastEntry?.end===previousBattle.end)finishedBattle={battle:previousBattle,entry:lastEntry};
    const actionChanged=action?applyGameAction(state,action,now):false;
    const changed=actionChanged||entries.length;
    if(action)entries.push(...advance(state,now));
    const saved=store();
    ok=saved&&(action?Boolean(actionChanged):true);
    if(changed&&!drag)renderPanel();
    if(profileUid)renderProfile();
    if(saved)receive(entries,offline);
  }
  const next=transactionQueue.then(async()=>{
    busy=true;
    try{
      if(community?.active()){
        const firstConnection=!community.ready();
        const previous=state;
        const observed=lastObservation;
        const age=observed===null||observed===sentObservation?null:Math.max(0,Date.now()-observed);
        const data=await community.game(action,age);
        if(!data)return;
        sentObservation=observed;
        serverOffset=data.now-Date.now();
        state=data.state;
        ok=action?Boolean(data.changed):true;
        if(firstConnection){arenaRecovery=loadArenaRecovery();finishedBattle=null;stageKey='';}
        if(data.finished)finishedBattle=data.finished;
        if((firstConnection||data.changed||data.entries.length||previous.gold!==state.gold)&&!drag)renderPanel();
        if(firstConnection&&tab==='comunidade')community.mount();
        if(profileUid)renderProfile();
        if(!state.awayReports?.length&&data.offline.total>25){
          const {total,wins,gold,recruits}=data.offline;
          note(`Progresso AFK · ${wins} vitórias em ${total} lutas · +${int.format(gold)} ouro · ${recruits} recrutados.`);
        }else receive(data.entries,offline);
      }else if(navigator.locks)await navigator.locks.request(saveKey,commit);
      else commit();
    } finally{busy=false;showAway();}
  });
  transactionQueue=next.catch(error=>{
    ok=false;
    if(error.status===401&&community?.active()){
      community.clear();
      state=load()??fresh(Date.now());
      serverOffset=0;finishedBattle=null;stageKey='';
      renderPanel();
    }
    note(error.message||'Não foi possível atualizar o progresso.');
  });
  return transactionQueue.then(()=>ok);
}

function unitSummary(unit){
  const c=CHARACTERS[unit.id];
  return `<span class="member">${img(spriteFor(unit))}<span class="unit-summary"><strong>${c.name}${unit.shiny?' ✦':''}</strong><small>${TIERS[c.tier-1]} · ${c.color} · Nv. ${levelAt(unit.xp)} · ${serial(unit)}</small></span></span>`;
}

let chartColor='Vermelho',chartMode='ataque';
function colorChart(){
  const colors=Object.keys(COLORS);
  const symbols={Vermelho:'◆',Laranja:'▲',Amarelo:'✦',Verde:'✿',Turquesa:'≈',Azul:'●',Roxo:'☾',Rosa:'♥',Branco:'○',Preto:'■',Dourado:'✹'};
  const attack=chartMode==='ataque';
  const mult=c=>attack?affinity(chartColor,c):affinity(c,chartColor);
  const ring=['Vermelho','Laranja','Amarelo','Verde','Turquesa','Azul','Roxo','Rosa'];
  const point=i=>{const t=i*Math.PI/4-Math.PI/2;return [160+108*Math.cos(t),134+102*Math.sin(t)];};
  const wheel=`<svg class="affinity-wheel" viewBox="0 0 320 275" role="img" aria-label="Ciclo de vantagem: Vermelho, Laranja, Amarelo, Verde, Turquesa, Azul, Roxo, Rosa e volta para Vermelho."><defs><marker id="aff-tip" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0 0L5 2.5L0 5Z" fill="#d6d9ec"/></marker></defs>
    ${ring.map((c,i)=>{const [x,y]=point(i),[nx,ny]=point(i+1),dx=nx-x,dy=ny-y;
      return `<line x1="${x+dx*.3}" y1="${y+dy*.3}" x2="${x+dx*.68}" y2="${y+dy*.68}" stroke="#d6d9ec" stroke-width="1.8" marker-end="url(#aff-tip)"/>`;}).join('')}
    ${ring.map((c,i)=>{const [x,y]=point(i);return `<g><circle cx="${x}" cy="${y}" r="15" fill="#232639" stroke="${COLORS[c]}" stroke-width="${chartColor===c?4:2}"/><text x="${x}" y="${y+5}" fill="${COLORS[c]}">${symbols[c]}</text><text x="${x}" y="${y+30}" class="wheel-name">${c}</text></g>`;}).join('')}
    <text x="160" y="126" class="wheel-title">1,5×</text><text x="160" y="146" class="wheel-name">no sentido da seta</text></svg>`;
  return `<section class="match-chart"><h3>Mapa de afinidades</h3>${wheel}<div class="chart-modes">${['ataque','defesa'].map(m=>`<button class="ghost" data-mode="${m}" aria-pressed="${m===chartMode}">${m==='ataque'?'Atacando':'Defendendo'}</button>`).join('')}</div>
  <p>Escolha a cor de quem ${attack?'ataca':'defende'}.</p><div class="palette">${colors.map(c=>`<button style="--hue:${COLORS[c]}" data-color="${c}" aria-pressed="${c===chartColor}"><b>${symbols[c]}</b>${c}</button>`).join('')}</div>
  <h4>${attack?chartColor+' ataca':'Dano recebido por '+chartColor}</h4><div class="match-groups">${[2,1.5,.75,1].map(n=>{
    const targets=colors.filter(c=>mult(c)===n);
    return targets.length?`<div class="match-row"><strong>${n.toLocaleString('pt-BR')}×</strong><div>${targets.map(c=>`<span style="--hue:${COLORS[c]}"><b>${symbols[c]}</b> ${c}</span>`).join('')}</div></div>`:'';
  }).join('')}</div></section>`;
}
function traitEffects(trait){
  if(!trait)return [];
  const effects=trait.buffs.flatMap((v,i)=>v?[`+${Math.round(v*100)}% ${Object.values(statLabels)[i]}`]:[]);
  if(trait.passive)effects.push(trait.passive);
  return effects;
}
function renderProfile(){
  const unit=publicUnit??copy(profileUid);
  if(!unit){$('#character-profile').close();return;}
  const inTeam=state.team.includes(unit.uid);
  const stats=fighter(unit,undefined,inTeam?card(state.leader):null);
  const base=fighter(unit);
  const xp=xpProgress(unit.xp,publicUnit?100:levelCap(state));
  const trait=TRAITS.find(t=>t.name===unit.trait);
  const bonuses=traitEffects(trait);
  const content=`<header class="profile-title" style="--tone:${COLORS[stats.color]}">
    ${img(stats.sprite)}
    <div><p class="smallcaps">${stats.universe}</p><h2 id="profile-title">${stats.name}</h2>
    <p>${TIERS[stats.tier-1]} · ${stats.color} · ${stats.role} · ${unit.shiny?'Shiny':'Normal'}</p>
    <p>Força no nível 100 · ${int.format(projectedPower(unit))}</p><p><b>Serial ${publicUnit||community?.active()?'global':'local'} ${serial(unit)}</b> · ${publicUnit?'Comunidade':inTeam?'Formação principal':'Reserva'}${state.leader===unit.uid?' · Líder':''}</p></div>
  </header>
  <div class="profile-grid">
    <section class="card"><h3>Atributos</h3>${inTeam?`<p class="caption">Bônus de liderança de ${card(state.leader).name} incluído quando aplicável.</p>`:''}
      <dl class="profile-stats">${Object.entries(statLabels).map(([key,label])=>{
        const boost=stats[key]-base[key];
        return `<div><dt>${label}</dt><dd>${int.format(stats[key])}${boost?` <small>(+${int.format(boost)})</small>`:''}</dd></div>`;
      }).join('')}</dl>
    </section>
    <section class="card"><h3>Nível ${xp.level}</h3>
      ${publicUnit?'':xp.required?`<label for="profile-xp">${xp.current} / ${xp.required} XP até o próximo nível</label><progress id="profile-xp" value="${xp.current}" max="${xp.required}"></progress>`:'<p>Nível máximo</p>'}
      <p class="caption">${int.format(unit.xp)} XP total</p>
      <h3>Habilidade</h3><p><b>${stats.skill}</b><br>${SKILL_EFFECTS[stats.kind]}</p>
      <h3>Efeito como líder</h3><p>${stats.leader}</p>
    </section>
    <section class="card"><h3>Trait</h3><p>${unit.trait??'Sem Trait'}</p>${trait?`<p>${trait.rarity} · 1 em ${int.format(trait.odds)} recrutáveis</p>`:''}
      ${!publicUnit&&unit.trait==='Voto de Nen'?`<button class="ghost" data-nen="${unit.uid}" ${inTeam&&!unit.nen&&formationCost(state)>=4?'disabled':''}>${unit.nen?'Desativar Última Aposta':inTeam&&formationCost(state)>=4?'Libere uma vaga para ativar':'Ativar Última Aposta'}</button>`:''}
      ${bonuses.length?`<ul>${bonuses.map(bonus=>`<li>${bonus}</li>`).join('')}</ul>`:''}
    </section>
    <section class="card"><h3>Recrutamento</h3><p>${unit.odds?`Chance registrada no encontro · 1 em ${int.format(unit.odds)}`:'Integrante inicial'}</p>
      ${unit.shiny?'<p class="caption">Shiny concede +25% a PV, Ataque, Magia, Defesa e Resistência.</p>':''}
    </section>
  </div>`;
  if(content===profileContent)return;
  profileContent=content;
  $('#profile-content').innerHTML=content;
}

let saleTier=1;
// Keep the same form controls mounted while battles and settings requests finish.
const pendingSettings=new Map();
function settingKey(input){
  if(input.id==='sale-trait-limit'||input.hasAttribute('data-sale-trait')){
    return saleTier+':'+(input.dataset.saleTrait??'limit');
  }
  return input.dataset.sale?input.dataset.sale+':'+input.value:input.id;
}
function changeSetting(input,action){
  const key=settingKey(input);
  const edit={value:input.type==='checkbox'?input.checked:input.value};
  pendingSettings.set(key,edit);
  void transaction(action).finally(()=>{
    if(pendingSettings.get(key)===edit)pendingSettings.delete(key);
    if(tab==='configuracoes')renderSettings($('#panel'));
  });
}
function renderSettings(panel){
  const mode=community?.active()?'online':'solo';
  if(panel.querySelector('.settings')?.dataset.mode!==mode){
    panel.innerHTML=`<article class="card settings"><h2>Configurações</h2>
      <h3>Progresso da campanha</h3>${community?.active()?'<p class="caption">Sua conta salva no servidor. Guarde o código de acesso privado em Meu perfil.</p>':`<p class="caption"><span id="save-status"></span> ${location.protocol==='file:'?'Para atualizar o HTML, mantenha o mesmo nome, pasta e navegador. ':''}Use um backup para continuar em outro arquivo ou dispositivo.</p>
      <button type="button" id="export-save">Exportar backup</button> <button type="button" id="import-save">Importar backup</button>`}
      <label><input type="checkbox" id="auto-play"> Exploração automática</label><p class="caption">Parar conclui a luta em andamento e suspende os próximos encontros, inclusive AFK.</p>
      <label><input type="checkbox" id="auto-routes"> Avançar áreas e mundos automaticamente</label><p class="caption">A equipe desafia o chefe quando ele libera e viaja após vencer. Escolher uma área ou mundo manualmente fixa a rota.</p>
      <h3>Venda automática de cópias</h3><label><input type="checkbox" data-sale="enabled"> Vender novas cópias selecionadas</label>
      <p class="caption">Escolha raridades ou personagens. A primeira normal e a primeira shiny de cada personagem ficam na coleção. Depois, cópias sem trait são vendidas. Para vender cópias com trait, escolha as exceções abaixo.</p>
      <p class="caption" id="sale-status" role="status"></p>
      <fieldset class="sale-options"><legend>Raridade e preço por cópia</legend>${TIERS.map((name,i)=>`<label><input type="checkbox" data-sale="tiers" value="${i+1}"> ${name} · ${int.format(SALE_PRICES[i])} ouro</label>`).join('')}</fieldset>
      <details id="sale-characters"><summary>Selecionar personagens (<span id="sale-count"></span>)</summary><div class="sale-options">${Object.values(CHARACTERS).sort((x,y)=>x.name.localeCompare(y.name,'pt-BR')).map(c=>`<label><input type="checkbox" data-sale="characters" value="${c.id}"> ${c.name}</label>`).join('')}</div></details>
      <details id="sale-traits"><summary>Exceções para cópias com trait</summary><p class="caption">Por padrão, toda cópia com trait fica na coleção. As exceções abaixo só valem para personagens marcados individualmente ou pela raridade, inclusive quando a trait aparece pela primeira vez nessa versão.</p>
      <label>Raridade do personagem <select id="sale-trait-tier">${TIERS.map((n,i)=>`<option value="${i+1}">${n}</option>`).join('')}</select></label>
      <label>Vender traits mais frequentes que <select id="sale-trait-limit"></select></label>
      <p class="caption">Com o limite 1/30, uma cópia 1/25 pode ser vendida. Uma 1/30 ou mais rara fica protegida, salvo se você marcar a trait pelo nome.</p>
      <fieldset class="sale-options"><legend>Também permitir estas traits em personagens de raridade <span id="sale-tier-label"></span></legend>${TRAITS.map(t=>`<label><input type="checkbox" data-sale-trait="${t.name}"> ${t.name} · 1/${int.format(t.odds)}</label>`).join('')}</fieldset></details>
      <h3>Exibição neste dispositivo</h3><label><input type="checkbox" data-pref="motion"> Animações de combate</label>
      <label><input type="checkbox" data-pref="numbers"> Números de dano na arena</label></article>`;
    panel.querySelector('.settings').dataset.mode=mode;
  }
  const sale=saleSettings(state.autoSell);
  const rule=sale.traitRules[saleTier]??{below:0,names:[]};
  const localStatus=$('#save-status');
  if(localStatus)localStatus.textContent=storageIssue||storageFailed?'Salvamento local indisponível.':'Salvamento automático neste navegador.';
  function setChecked(input,value){
    input.checked=pendingSettings.get(settingKey(input))?.value??value;
  }
  setChecked($('#auto-play'),!isPaused());
  setChecked($('#auto-routes'),!!state.autoRoutes);
  for(const input of panel.querySelectorAll('[data-sale]')){
    const group=input.dataset.sale;
    const value=group==='tiers'?Number(input.value):input.value;
    setChecked(input,group==='enabled'?sale.enabled:sale[group].includes(value));
  }
  $('#sale-count').textContent=String(panel.querySelectorAll('[data-sale="characters"]:checked').length);
  $('#sale-status').textContent=!sale.enabled?'Venda automática desligada.':!sale.tiers.length&&!sale.characters.length?'Selecione uma raridade ou um personagem para começar a vender.':'Venda automática ligada para os próximos recrutamentos.';
  $('#sale-trait-tier').value=String(saleTier);
  $('#sale-tier-label').textContent=TIERS[saleTier-1];
  const limit=$('#sale-trait-limit');
  const below=Number(pendingSettings.get(settingKey(limit))?.value??rule.below);
  if(!limit.options.length){
    limit.add(new Option('Nenhuma por frequência','0'));
    for(const n of [5,10,20,25,30,50,100,125,200,250,500,1000,2000,2001]){
      limit.add(new Option('1/'+int.format(n),String(n)));
    }
  }
  if(!Array.from(limit.options).some(o=>o.value===String(below)))limit.add(new Option('1/'+int.format(below),String(below)));
  limit.value=String(below);
  for(const input of panel.querySelectorAll('[data-sale-trait]'))setChecked(input,rule.names.includes(input.dataset.saleTrait));
  for(const input of panel.querySelectorAll('[data-pref]'))input.checked=preferences[input.dataset.pref];
}


function renderWorldNav(){
  const nav=$('#world-nav');
  nav.hidden=tab!=='exploracao';
  if(nav.hidden)return;
  const list=$('#world-list');
  if(!list.childElementCount){
    list.innerHTML=WORLDS.map((world,i)=>{
      const levels=world.areas;
      return `<button type="button" class="mundo-cartao" data-world="${i}"><span class="mundo-texto"><strong>${world.name}</strong><small>Nv. ${levels[0].levels[0]}–${levels.at(-1).levels[1]}</small></span><span class="world-status"></span></button>`;
    }).join('');
  }
  for(const button of list.children){
    const i=Number(button.dataset.world);
    const current=i===(state.world??0);
    const queued=i===state.destination && !current;
    button.disabled=i>(state.unlocked??0);
    button.classList.toggle('atual',current);
    button.classList.toggle('fechado',button.disabled);
    button.classList.toggle('pendente',queued);
    if(current)button.setAttribute('aria-current','location');
    else button.removeAttribute('aria-current');
    const status=queued?'Após a luta':current?'Aqui':button.disabled?'Bloqueado':'';
    if(button.lastElementChild.textContent!==status)button.lastElementChild.textContent=status;
  }
}

let autoFormMode='power';
const colFilter={search:'',sort:'potential',role:'',tier:'',shiny:false,trait:false};
const ROLE_TAG={Guardião:'GUA',Combatente:'COM',Mágico:'MAG',Suporte:'SUP'};
function countAffordableUpgrades(){
  return Object.entries(UPGRADES).filter(([id,u])=>{
    const level=upgradeLevel(state,id),price=u.costs[level],world=u.worlds[level];
    return price!==undefined&&world<=(state.unlocked??0)+1&&state.gold>=price;
  }).length;
}
function teamAffinitySummary(targetColor){
  if(!targetColor||!state.team.length)return '';
  let adv=0,dis=0;
  for(const uid of state.team){
    const m=affinity(card(uid).color,targetColor);
    if(m>1)adv++;else if(m<1)dis++;
  }
  const parts=[];
  if(adv)parts.push(`<b class="aff-good">${adv} vantagem</b>`);
  if(dis)parts.push(`<b class="aff-bad">${dis} desvantagem</b>`);
  return parts.length?parts.join(' · '):'<span>Neutro</span>';
}
function efficiencySummary(){
  const wins=state.log.filter(e=>e.won);
  if(!wins.length)return '';
  const avgGold=wins.reduce((s,e)=>s+e.gold,0)/wins.length;
  const avgXp=wins.reduce((s,e)=>s+(e.xp??0),0)/wins.length;
  const cycleSec=(waitFor(state)/1000)+5;
  const perHour=3600/cycleSec*(wins.length/state.log.length);
  return `<div class="efficiency-bar"><span>~<b>${int.format(Math.round(avgGold*perHour))}</b> ouro/h</span><span>~<b>${int.format(Math.round(avgXp*perHour))}</b> XP/h</span><span>Média <b>+${int.format(Math.round(avgGold))}</b> ouro/vitória</span></div>`;
}
function tacticalHints(){
  const pts=state.team.map(uid=>({uid,c:card(uid),u:copy(uid),p:state.positions[uid]??[50,50]}));
  let clustered=0,covered=new Set();
  for(let i=0;i<pts.length;i++){
    for(let j=i+1;j<pts.length;j++){
      const d=Math.hypot(pts[i].p[0]-pts[j].p[0],pts[i].p[1]-pts[j].p[1]);
      if(d<=28)clustered++;
    }
    const protector=pts[i].c.role==='Guardião'||['Restrição Celestial','Full Counter'].includes(pts[i].u.trait);
    if(protector){
      for(let j=0;j<pts.length;j++){
        if(i===j)continue;
        if(Math.hypot(pts[i].p[0]-pts[j].p[0],pts[i].p[1]-pts[j].p[1])<=30)covered.add(pts[j].uid);
      }
    }
  }
  const tags=[];
  tags.push(clustered?`<span class="hint-chip warn">${clustered} par(es) próximo(s) (≤28): risco de golpe em área</span>`:`<span class="hint-chip ok">Equipe espaçada contra golpes em área</span>`);
  if(covered.size)tags.push(`<span class="hint-chip info">Cobertura ativa em ${covered.size} aliado(s)</span>`);
  return `<div class="tactical-hints">${tags.join('')}</div>`;
}
let collectionIndex=null;
function getCollectionIndex(){
  if(collectionIndex)return collectionIndex;
  collectionIndex=state.collection.map((unit,idx)=>{
    const c=CHARACTERS[unit.id];
    return {unit,idx,c,power:unitPower(unit),potential:projectedPower(unit),level:levelAt(unit.xp),searchKey:`${c.name} ${c.universe} ${unit.trait??''}`.toLowerCase()};
  });
  return collectionIndex;
}
function filteredCollection(){
  const q=colFilter.search.trim().toLowerCase();
  const list=getCollectionIndex().filter(({unit,c,searchKey})=>{
    if(q&&!searchKey.includes(q))return false;
    if(colFilter.role&&c.role!==colFilter.role)return false;
    if(colFilter.tier&&c.tier!==Number(colFilter.tier))return false;
    if(colFilter.shiny&&!unit.shiny)return false;
    if(colFilter.trait&&!unit.trait)return false;
    return true;
  });
  list.sort((a,b)=>{
    if(colFilter.sort==='potential')return b.potential-a.potential||b.power-a.power;
    if(colFilter.sort==='power')return b.power-a.power||b.level-a.level||b.c.tier-a.c.tier;
    if(colFilter.sort==='level')return b.level-a.level||b.power-a.power;
    if(colFilter.sort==='tier')return b.c.tier-a.c.tier||b.power-a.power;
    return b.idx-a.idx;
  });
  return list;
}
function renderCollectionGrid(){
  const grid=$('#collection-list');if(!grid)return;
  const slots=formationSlots(state);
  const index=pickSlot??(slots.includes(null)?slots.indexOf(null):3);
  const items=filteredCollection();
  const teamSet=new Set(state.team);
  const allowSell=state.collection.length>1;
  const countEl=$('#collection-filtered-count');
  if(countEl)countEl.textContent=items.length===state.collection.length?`${state.collection.length} personagens recrutados`:`Mostrando ${items.length} de ${state.collection.length} personagens`;
  grid.innerHTML=items.length?items.map(({unit,c,power,potential})=>{
    const inTeam=teamSet.has(unit.uid);
    const sellable=allowSell&&!inTeam;
    const price=SALE_PRICES[c.tier-1]??0;
    return `<div class="collection-card" style="--tone:${COLORS[c.color]}"><button class="character-hit" data-profile="${unit.uid}">${unitSummary(unit)}</button><p class="collection-meta"><span class="role-pill">${c.role}</span> <span class="power-pill">Força ${int.format(power)}</span> <span class="power-pill">Nv. 100 · ${int.format(potential)}</span>${unit.trait?` <span class="trait-pill">${unit.trait}</span>`:''}</p><p>${c.skill} · ${c.universe}</p><div class="collection-actions"><button class="ghost" data-equip="${unit.uid}" data-slot="${index}" data-occupant="${slots[index]??''}" ${inTeam?'disabled':''}>${inTeam?'Na equipe':slots[index]?'Substituir na vaga '+(index+1):'Colocar na vaga '+(index+1)}</button>${sellable?`<button class="ghost sell-btn" data-sell="${unit.uid}">Vender (+${int.format(price)})</button>`:''}</div></div>`;
  }).join(''):'<p class="caption">Nenhum personagem encontrado com os filtros selecionados.</p>';
}
function floatTag(target,text,cls=''){
  if(!target||!preferences.numbers)return;
  const hit=document.createElement('span');hit.className='float'+(cls?' '+cls:'');hit.textContent=text;
  target.append(hit);setTimeout(()=>hit.remove(),780);
}
function renderPanel(){
  renderWorldNav();
  collectionIndex=null;
  $('#gold').textContent=int.format(state.gold);
  $('#wins').textContent=int.format(state.wins);
  $('#collection-count').textContent=state.collection.length;
  const upgBadge=$('#upgrades-badge');
  if(upgBadge){const avail=countAffordableUpgrades();upgBadge.textContent=avail;upgBadge.hidden=avail===0;}
  const bossBadge=$('#boss-ready-badge');
  if(bossBadge)bossBadge.hidden=!readyForBoss(state);
  document.querySelectorAll('[data-tab]').forEach(b=>{
    if(b.dataset.tab===tab)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');
  });
  const panel=$('#panel');
  const social=tab==='comunidade';
  const communityPanel=$('#community-panel');
  panel.hidden=social;
  const arena=$('.arena');
  if(arena)arena.hidden=tab!=='exploracao';
  const mode=$('#game-mode');
  if(mode)mode.textContent=community?.ready()?'Online':community?.active()?'Conectando':'Solo';
  if(social){
    if(communityPanel?.hidden)community?.mount();
    return;
  }
  community?.hide();
  if(tab==='arena'){duelPanel(panel);return;}
  if(tab==='exploracao'){
    const level=maxLevel(state),world=worldOf(state),currentArea=world.areas[state.area];
    const toElite=state.area===2?(7-(state.index%7)):null;
    panel.innerHTML=`<div class="layout"><article class="card"><h2>Campanha</h2><p class="caption">${state.destination!==undefined?'Viagem após o combate atual.':`Mundo ${(state.world??0)+1} de ${WORLDS.length}`}</p>
    <div class="explore-meta"><label class="inline-toggle"><input type="checkbox" id="explore-auto-routes" ${state.autoRoutes?'checked':''}> Avançar áreas, chefes e mundos</label><span class="affinity-chip"><i class="color-dot" style="--hue:${COLORS[currentArea.color]}"></i> Contra <b>${currentArea.color}</b>: ${teamAffinitySummary(currentArea.color)}</span>${toElite!==null?`<span class="elite-chip">${toElite===1?'Próximo encontro: Elite':`Elite (${world.elite.name}) em ${toElite} lutas`}</span>`:''}</div>
    <div class="area-list">${world.areas.map((a,i)=>`<button class="area-option" type="button" data-area="${i}" ${level<a.unlock?'disabled':''} aria-pressed="${state.area===i}"><span class="index-badge">${i+1}</span><span><strong>${a.name} <i class="color-dot" style="--hue:${COLORS[a.color]}" title="Cor do inimigo: ${a.color}"></i></strong><small>${a.description}</small></span><em>${level<a.unlock?`Libera no nv. ${a.unlock}`:`Nv. ${a.levels[0]}–${a.levels[1]}`}</em></button>`).join('')}</div></article><aside><article class="card boss"><h3>Chefe · ${world.boss.name} <small>Nv. ${world.boss.level}</small></h3><p class="caption boss-aff"><i class="color-dot" style="--hue:${COLORS[world.boss.color]}"></i> ${world.boss.color} · ${teamAffinitySummary(world.boss.color)}</p><div class="meter"><i style="width:${Math.min(100,state.finalWins/12*100)}%"></i></div><p class="caption">${state.completed?(state.world===9?'Campanha concluída.':'Próximo mundo disponível no menu de mundos.'):`${Math.min(12,state.finalWins)} / 12 vitórias em ${world.areas[2].name}`}</p><button class="primary" data-action="boss" ${!readyForBoss(state)||state.pending?'disabled':''}>${state.completed?'Chefe derrotado':state.pending?'Aguarde o fim da luta':'Desafiar chefe'}</button></article><article class="card"><h3>Últimos encontros</h3>${efficiencySummary()}<ul class="activity">${state.log.length?state.log.slice(0,4).map(e=>`<li><span>${e.label}${e.reserveXp?`<small>+${e.reserveXp} XP entre reservas</small>`:''}</span><b ${!e.won?'class="loss"':''}>${e.won?`+${int.format(e.gold)} ouro`:'Derrota'}</b></li>`).join(''):'<li>Seus resultados aparecem aqui.</li>'}</ul></article></aside></div>`;
  }else if(tab==='formacao'){
    if(!state.team.includes(selected))selected=state.team[0];
    const slots=formationSlots(state);
    const active=state.leader?card(state.leader):null;
    const teamPower=state.team.reduce((sum,uid)=>sum+unitPower(copy(uid),active),0);
    const reserves=state.collection.filter(u=>!state.team.includes(u.uid)).sort((a,b)=>unitPower(b)-unitPower(a));
    const currentArea=worldOf(state).areas[state.area];
    panel.innerHTML=`<div class="formation-toolbar card"><div class="formation-stats"><span class="stat-pill">Força total <strong>${int.format(teamPower)}</strong></span><span class="stat-pill">Vagas <strong>${formationCost(state)}/4</strong></span><span class="stat-pill"><i class="color-dot" style="--hue:${COLORS[currentArea.color]}"></i> Contra ${currentArea.color}: ${teamAffinitySummary(currentArea.color)}</span></div><div class="auto-form-controls"><label>Critério no nível 100 <select id="auto-form-mode"><option value="power" ${autoFormMode==='power'?'selected':''}>Maior força</option><option value="balanced" ${autoFormMode==='balanced'?'selected':''}>Equilibrada</option><option value="area" ${autoFormMode==='area'?'selected':''}>Contra área atual</option></select></label><button type="button" class="primary" id="auto-form-btn">Auto-formação</button></div></div>
      <div class="formation-layout"><article class="card formation-board"><div class="board-head"><h2>Formação de combate</h2><div class="preset-group" role="group" aria-label="Posicionamento rápido"><button type="button" class="ghost" data-preset="padrao">Padrão</button><button type="button" class="ghost" data-preset="espalhado">Espalhado</button><button type="button" class="ghost" data-preset="proteger">Proteger</button></div></div>
      <div class="field" id="field"><span class="field-label back">RETAGUARDA</span><span class="field-label">FRENTE</span>
      ${state.team.map(uid=>{const [x,y]=state.positions[uid];const c=card(uid);return `<button class="field-marker ${uid===selected?'active':''}" data-marker="${uid}" aria-label="Ficha de ${c.name} (${c.role}). Use as setas para mover." style="left:${x}%;top:${y}%;--tone:${COLORS[c.color]}"><span class="marker-role">${ROLE_TAG[c.role]??''}</span>${img(spriteFor(copy(uid)))}<small>${c.name.split(' · ')[0]}</small></button>`;}).join('')}</div>
      ${tacticalHints()}
      <p class="caption">As mudanças valem no próximo combate. Na Arena, os titulares entram da vaga 1 à 4.</p></article>
      <article class="card"><h2>Equipe principal</h2><p class="caption">${active?`Líder: ${active.name} (${active.leader})`:'Formação vazia. Use Auto-formação ou escolha na coleção.'}</p>
      <div class="members">${slots.map((uid,i)=>{
        if(!uid)return `<button class="ghost slot-empty" data-vaga="${i}">＋ Vaga ${i+1} · Escolher na coleção</button>`;
        const u=copy(uid),c=CHARACTERS[u.id],pwr=unitPower(u,active),buffed=active&&leaderApplies(active,c);
        return `<div class="member squad-row" style="--tone:${COLORS[c.color]}"><div class="squad-top"><small>Vaga ${i+1}</small><span class="role-pill">${c.role}</span><span class="power-pill">Força ${int.format(pwr)}</span>${buffed?'<span class="leader-pill">Bônus de líder</span>':''}</div><button class="character-hit" data-profile="${uid}">${unitSummary(u)}</button>
        <div class="squad-actions"><button class="ghost" data-leader="${uid}" ${uid===state.leader?'disabled':''}>${uid===state.leader?'Líder':'Liderar'}</button>
        <span data-recovery="${uid}"></span><button class="ghost" data-remove="${uid}">Remover</button></div>
        ${reserves.length?`<label>Substituir <select data-replace="${uid}"><option value="">Escolher reserva</option>${reserves.map(r=>`<option value="${r.uid}">${CHARACTERS[r.id].name} (${CHARACTERS[r.id].role}, Nv. ${levelAt(r.xp)}, Força ${int.format(unitPower(r))})</option>`).join('')}</select></label>`:''}</div>`;
      }).join('')}</div></article></div>`;
  }else if(tab==='colecao'){
    const slots=formationSlots(state);
    const index=pickSlot??(slots.includes(null)?slots.indexOf(null):3);
    const slotOptions=slots.map((uid,i)=>`<option value="${i}" ${index===i?'selected':''}>${i+1} · ${uid?card(uid).name:'Vazia'}</option>`).join('');
    if(panel.querySelector('#collection-list')){
      const target=panel.querySelector('#swap-target');
      if(target){target.innerHTML=slotOptions;target.value=String(index);}
    }else{
      const searchValue=colFilter.search.replace(/&/g,'&amp;').replace(/"/g,'&quot;');
      panel.innerHTML=`<article class="card"><div class="swap"><div><h2>Coleção</h2><p class="caption" id="collection-filtered-count"></p></div><label>Vaga de destino <select id="swap-target">${slotOptions}</select></label></div>
    <div class="collection-filters"><label class="search-field"><span>Buscar</span><input type="search" id="col-search" placeholder="Nome, universo ou trait" value="${searchValue}"></label><select id="col-sort" aria-label="Ordenar coleção"><option value="potential" ${colFilter.sort==='potential'?'selected':''}>Força no nível 100</option><option value="power" ${colFilter.sort==='power'?'selected':''}>Maior força</option><option value="level" ${colFilter.sort==='level'?'selected':''}>Maior nível</option><option value="tier" ${colFilter.sort==='tier'?'selected':''}>Maior raridade</option><option value="recent" ${colFilter.sort==='recent'?'selected':''}>Mais recente</option></select><select id="col-role" aria-label="Filtrar por função"><option value="">Todas funções</option>${['Guardião','Combatente','Mágico','Suporte'].map(r=>`<option value="${r}" ${colFilter.role===r?'selected':''}>${r}</option>`).join('')}</select><select id="col-tier" aria-label="Filtrar por raridade"><option value="">Todas raridades</option>${TIERS.map((t,i)=>`<option value="${i+1}" ${colFilter.tier===String(i+1)?'selected':''}>${t}</option>`).join('')}</select><label class="filter-check"><input type="checkbox" id="col-shiny" ${colFilter.shiny?'checked':''}> Shiny</label><label class="filter-check"><input type="checkbox" id="col-trait" ${colFilter.trait?'checked':''}> Com Trait</label></div>
    <div class="collection-grid" id="collection-list"></div></article>`;
    }
    renderCollectionGrid();
  }else if(tab==='guia'){
    panel.innerHTML=`<article class="card guide"><h2>Guia de combate</h2>${colorChart()}
    <h3>Funções</h3><ul><li><b>Combatente</b> · Ataque elevado e golpes básicos físicos.</li><li><b>Guardião</b> · Mais PV e defesa. Seus golpes básicos são físicos.</li><li><b>Mágico</b> · Usa Magia nos golpes básicos e enfrenta a Resistência do alvo.</li><li><b>Suporte</b> · Usa Magia nos golpes básicos. Na reserva da Arena, cura o aliado ativo.</li></ul>
    <h3>Formação e liderança</h3><p>Na exploração, os titulares lutam juntos. Na Arena, entra um por vez, na ordem das vagas ocupadas. Escolha o líder na Formação e consulte a ficha para ver quem recebe o bônus.</p>
    <h3>Raridade e traits</h3><p>${TIERS.join(' → ')}. Na ficha, você encontra a raridade, a versão Shiny e os bônus da trait de cada cópia.</p><h3>Traits e efeitos</h3><p>A chance indica quantos personagens recrutáveis, em média, correspondem a uma ocorrência da trait.</p><div class="trait-list">${TRAITS.map(t=>`<section><header><strong>${t.name}</strong><small>${t.rarity} · 1/${int.format(t.odds)} · ${(100/t.odds).toLocaleString('pt-BR',{maximumFractionDigits:3})}%</small></header><p>${traitEffects(t).slice(0,t.buffs.filter(Boolean).length).join(' · ')}</p>${t.passive?`<p>${t.passive}</p>`:''}</section>`).join('')}</div></article>`;
  }else if(tab==='configuracoes'){
    renderSettings(panel);
  }else{
    const luck=UPGRADES.sorte.values[upgradeLevel(state,'sorte')];
    const rare=UPGRADES.rastreio.values[upgradeLevel(state,'rastreio')];
    const rareEncounter=(luck*rare/100).toLocaleString('pt-BR',{maximumFractionDigits:2});
    panel.innerHTML=`<article class="card"><h2>Upgrades de exploração</h2><p class="caption">Encontros comuns · ${luck}% de chance de aparecer um recruta · ${rareEncounter}% de chance de aparecer um recruta de raridade Rara ou superior.</p>${Object.entries(UPGRADES).map(([id,upgrade])=>{
      const level=upgradeLevel(state,id);
      const price=upgrade.costs[level];
      const world=upgrade.worlds[level];
      const locked=world>(state.unlocked??0)+1;
      const effect=index=>`${id==='ouro'||id==='treino'?'+':''}${upgrade.values[index]}${upgrade.unit}`;
      return `<div class="upgrades-row"><div><h3>${upgrade.name} <small>Nível ${level} / ${upgrade.costs.length}</small></h3><p>${upgrade.description}</p><p class="upgrade-effect">${effect(level)}${price===undefined?'':` → ${effect(level+1)}`}</p></div><button class="primary" data-upgrade="${id}" aria-label="${upgrade.name} · ${price===undefined?'Nível máximo':`Comprar por ${int.format(price)} ouro`}" ${price===undefined||locked||state.gold<price?'disabled':''}>${price===undefined?'Nível máximo':`${int.format(price)} ouro${locked?' · Mundo '+world:''}`}</button></div>`;
    }).join('')}</article>`;
  }
}

function stageUnit(u,token,enemy=false){
  const x=enemy?79:12+u.x*.49;
  const y=enemy?62:27+u.y*.56;
  const tag=enemy?'div':'button';
  return `<${tag} ${enemy?'':`data-profile="${u.uid}" aria-label="Abrir ficha de ${u.name}"`} class="battler ${enemy?'enemy':''}" data-actor="${token}" style="--x:${x}%;--y:${y}%;--z:${Math.ceil(y)}"><span class="tag">${u.name} <small>· ${u.level}</small></span><div class="hp-track"><b></b></div><img class="sprite" src="${spriteURL(u.sprite)}" alt=""></${tag}>`;
}
function drawScene(now){
  const activeBattle=state.pending;
  const finish=!activeBattle&&finishedBattle&&now<finishedBattle.battle.end+1800?finishedBattle:null;
  const battle=activeBattle??finish?.battle;
  const world=WORLDS[battle?.world??state.world??0];
  const key=battle?`battle-${battle.start}-${battle.boss}`:'idle-'+state.team.filter(uid=>readyAt(state,uid)<=now).join(',')+JSON.stringify(state.positions)+state.area+state.completed+world.name;
  if(key!==stageKey){
    stageKey=key;replay=battle;eventCursor=0;
    const team=battle?.team??state.team.filter(uid=>readyAt(state,uid)<=now).map(uid=>fighter(copy(uid),state.positions[uid]));
    const foe=battle?.enemy??{name:world.areas[state.area].enemy,level:world.areas[state.area].levels[0],sprite:'soldier'};
    $('#stage').innerHTML=team.map((u,i)=>stageUnit(u,`0:${i}`)).join('')+(battle?stageUnit(foe,'1:0',true):'');
    $('#combat-note').textContent=battle?.recruit?'ENCONTRO RECRUTÁVEL':'';
  }
  const duration=battle?Math.max(1,battle.end-battle.start):1;
  const elapsed=battle?Math.max(0,Math.min(now-battle.start,duration)):0;
  const replayRate=battle?battle.result.seconds*1000/duration:1;
  const replayTime=elapsed*replayRate;
  if(replay){
    const events=replay.result.events;
    while(eventCursor<events.length&&events[eventCursor].time<=replayTime+.00001){
      const e=events[eventCursor++];
      const source=$(`[data-actor="${e.actor}"]`);
      const target=$(`[data-actor="${e.target}"]`);
      const updateHp=(node,id,current)=>{
        const max=id==='1:0'?replay.enemy.hp:replay.team[Number(id?.split(':')[1])]?.hp;
        if(node&&max) {node.querySelector('.hp-track b').style.width=`${Math.max(0,100*current/max)}%`;node.classList.toggle('ko',current<=0);}
      };
      const freshEvent=(replayTime-e.time)/replayRate<650;
      if(e.type==='dano'){
        updateHp(target,e.target,e.remaining);
        if(freshEvent&&target&&e.hp>0){
          pulse(source,'attack');pulse(target,'hit');
          floatTag(target,`−${Math.round(e.hp)}`);
        }
      }
      if(['cura','sobrevive','ressurge'].includes(e.type)){
        updateHp(source,e.actor,e.remaining);
        if(freshEvent){
          if(e.type==='cura')floatTag(source,'+Cura','heal');
          if(e.type==='sobrevive')floatTag(source,'Sobrevive','special');
          if(e.type==='ressurge')floatTag(source,'Ressurge','special');
        }
      }
      if(freshEvent){
        if(e.type==='esquiva')floatTag(source,'Esquiva','info');
        if(e.type==='intercepta')floatTag(source,'Intercepta','info');
        if(e.type==='reflete')floatTag(source,'Reflete','special');
        if(e.type==='escudo rompe')floatTag(target,'Escudo quebrado','warn');
        if(e.type==='onda')$('#combat-note').textContent='Onda de energia';
        if(e.type==='aceleração')$('#combat-note').textContent='Made in Heaven · Aceleração';
        if(e.type==='tempo parado')$('#combat-note').textContent='The World · Tempo parado';
        if(e.type==='dimensão')$('#combat-note').textContent='Dimensão alterada';
      }
    }
  }
  const recoverAt=Math.min(...state.team.map(uid=>readyAt(state,uid)));
  const recovering=!battle&&state.running&&state.team.length&&recoverAt>now;
  const waiting=state.team.length>0&&state.running&&!activeBattle;
  $('#arena-status').textContent=finish?(finish.entry.won?'VITÓRIA':'DERROTA'):battle?.boss?'DESAFIO DE CHEFE':battle?.elite?'ENCONTRO DE ELITE':battle?'EM COMBATE':recovering?'EM RECUPERAÇÃO':waiting?'PRÓXIMO ENCONTRO':state.team.length?'EXPLORAÇÃO PARADA':'FORMAÇÃO VAZIA';
  $('#world-title').textContent=world.name;
  $('.arena').dataset.world=String(battle?.world??state.world??0);
  $('#arena-location').textContent=world.areas[battle?.area??state.area].name;
  $('#arena-time').textContent=time(activeBattle?elapsed:recovering?recoverAt-now:waiting?state.nextAt-now:0);
  $('#arena-label').textContent=finish?(finish.entry.won?`+${int.format(finish.entry.gold)} ouro · +${finish.entry.xp} XP por titular${finish.entry.reserveXp?` · +${finish.entry.reserveXp} XP entre reservas`:''}`:`Derrota contra ${battle.enemy.name}`):battle?`Enfrentando ${battle.enemy.name}`:recovering?'Aguardando a recuperação da equipe.':waiting?'O time está procurando um adversário.':state.team.length?'Exploração parada. Clique em Explorar para retomar.':'Coloque um personagem na formação para explorar.';
  $('#fight-progress').style.width=`${battle?100*elapsed/duration:waiting?Math.max(0,Math.min(100,100*(1-(state.nextAt-now)/(state.waitDuration||waitFor(state))))):0}%`;
  const paused=isPaused();
  const toggle=$('#explore-toggle');
  toggle.hidden=false;
  toggle.textContent=paused?'Explorar':'Parar exploração';
  toggle.dataset.mode=paused?'resume':'pause';
  toggle.disabled=paused&&!state.team.length;
}

function openUnit(uid,button){
  if(!copy(uid))return;
  publicUnit=null;profileUid=uid;profileOpener=button;
  renderProfile();
  if(!$('#character-profile').open)$('#character-profile').showModal();
}
function pulse(node,cls){
  if(!node)return;
  node.classList.remove(cls);void node.offsetWidth;node.classList.add(cls);
  setTimeout(()=>node.classList.remove(cls),300);
}

document.addEventListener('click',e=>{
  const b=e.target.closest('button');if(!b)return;
  if(b.dataset.world!==undefined){
    const index=Number(b.dataset.world);
    if(!b.disabled && index!==(state.destination??state.world??0))void transaction({type:'world',index});
    return;
  }
  if(b.id==='export-save')void exportCampaign();
  if(b.id==='import-save')$('#save-file').click();
  if(b.dataset.tab){tab=b.dataset.tab;pickSlot=null;history.replaceState(null,'',`#${tab}`);renderPanel();return;}
  if(b.dataset.nen){const u=copy(b.dataset.nen);if(u)void transaction({type:'nen',uid:u.uid,enabled:!u.nen});}
  if(b.dataset.color||b.dataset.mode){
    if(b.dataset.color)chartColor=b.dataset.color;else chartMode=b.dataset.mode;
    const attribute=b.dataset.color?'color':'mode';renderPanel();document.querySelector(`[data-${attribute}="${b.dataset[attribute]}"]`)?.focus();
  }
  if(b.id==='duel-start')startDuel();
  if(b.id==='duel-train'){duel=null;rival=null;renderPanel();}
  if(b.id==='explore-toggle')void transaction({type:isPaused()?'resume':'pause'});
  if(b.id==='auto-form-btn'){
    void transaction({type:'autoFormation',mode:autoFormMode}).then(ok=>{if(ok)note('Formação atualizada.');});
  }
  if(b.dataset.preset)void transaction({type:'formationPreset',preset:b.dataset.preset});
  if(b.dataset.sell){
    const u=copy(b.dataset.sell);
    if(u&&canSellUnit(state,u.uid)){
      const c=CHARACTERS[u.id],price=SALE_PRICES[c.tier-1]??0;
      const valuable=u.shiny||!!u.trait||c.tier>=3;
      if(!valuable||confirm(`Vender ${c.name}${u.shiny?' Shiny':''}${u.trait?` (${u.trait})`:''} ${serial(u)} por ${int.format(price)} ouro?`)){
        void transaction({type:'sell',uid:u.uid}).then(ok=>{if(ok)note(`${c.name} ${serial(u)} vendido por +${int.format(price)} ouro.`);});
      }
    }
  }
  if(b.dataset.area!==undefined)void transaction({type:'area',area:Number(b.dataset.area)});
  if(b.dataset.leader)void transaction({type:'leader',uid:b.dataset.leader});
  if(b.dataset.remove)void transaction({type:'remove',uid:b.dataset.remove});
  if(b.dataset.vaga!==undefined){pickSlot=Number(b.dataset.vaga);tab='colecao';history.replaceState(null,'','#colecao');renderPanel();}
  if(b.dataset.equip){
    const uid=b.dataset.equip,slot=Number(b.dataset.slot);
    void transaction({type:'equip',uid,slot,replaced:b.dataset.occupant||null}).then(ok=>{
      if(ok&&formationSlots(state)[slot]===uid&&tab==='colecao'){pickSlot=null;tab='formacao';history.replaceState(null,'','#formacao');renderPanel();}
    });
  }
  if(b.dataset.action==='boss')void transaction({type:'boss'});
  if(b.dataset.upgrade)void transaction({type:'upgrade',id:b.dataset.upgrade});
  if(b.dataset.publicUnit){
    publicUnit=JSON.parse(b.dataset.publicUnit);profileUid=null;profileOpener=b;
    renderProfile();$('#character-profile').showModal();
  }
  if(b.dataset.profile)openUnit(b.dataset.profile,b);
  if(b.dataset.marker&&e.detail===0)openUnit(b.dataset.marker,b);
  if(b.id==='close-profile')$('#character-profile').close();
  if(b.id==='install'&&installPrompt){void installPrompt.prompt();installPrompt=null;b.hidden=true;}
});
$('#character-profile').addEventListener('close',()=>{
  const uid=profileUid;
  publicUnit=null;profileUid=null;
  if(profileOpener?.isConnected)profileOpener.focus();
  else $(`[data-profile="${uid}"]`)?.focus();
  profileOpener=null;
});
document.addEventListener('change',e=>{const target=e.target;
  if(target.id==='save-file'){void importCampaign(target.files[0]);target.value='';return;}
  if(target.id==='swap-target'){pickSlot=Number(target.value);renderPanel();}
  if(target.dataset.replace&&target.value)void transaction({type:'equip',uid:target.value,replaced:target.dataset.replace});
  if(target.id==='sale-trait-tier'){saleTier=Number(target.value);renderSettings($('#panel'));return;}
  if(target.id==='sale-trait-limit')changeSetting(target,{type:'saleTrait',tier:saleTier,below:Number(target.value)});
  if(target.dataset.saleTrait)changeSetting(target,{type:'saleTrait',tier:saleTier,name:target.dataset.saleTrait,checked:target.checked});
  if(target.dataset.sale)changeSetting(target,{type:'saleSetting',group:target.dataset.sale,value:target.dataset.sale==='tiers'?Number(target.value):target.value,checked:target.checked});
  if(target.id==='auto-play')changeSetting(target,{type:target.checked?'resume':'pause'});
  if(target.id==='auto-routes')changeSetting(target,{type:'autoRoutes',enabled:target.checked});
  if(target.id==='explore-auto-routes')void transaction({type:'autoRoutes',enabled:target.checked});
  if(target.id==='auto-form-mode'){autoFormMode=target.value;return;}
  if(target.id==='col-sort'){colFilter.sort=target.value;renderCollectionGrid();return;}
  if(target.id==='col-role'){colFilter.role=target.value;renderCollectionGrid();return;}
  if(target.id==='col-tier'){colFilter.tier=target.value;renderCollectionGrid();return;}
  if(target.id==='col-shiny'){colFilter.shiny=target.checked;renderCollectionGrid();return;}
  if(target.id==='col-trait'){colFilter.trait=target.checked;renderCollectionGrid();return;}
  if(target.dataset.pref){
    preferences[target.dataset.pref]=target.checked;
    document.documentElement.dataset.motion=preferences.motion?'on':'off';
    try{localStorage.setItem('nexus.display',JSON.stringify(preferences));}catch{note('A preferência de exibição vale nesta sessão. O navegador não conseguiu salvá-la.');}
  }});
document.addEventListener('input',e=>{
  if(e.target.id==='col-search'){colFilter.search=e.target.value;renderCollectionGrid();}
});
document.addEventListener('keydown',e=>{
  const uid=e.target.dataset.marker;
  const direction={ArrowLeft:[-5,0],ArrowRight:[5,0],ArrowUp:[0,-5],ArrowDown:[0,5]}[e.key];
  if(!uid||!direction)return;
  e.preventDefault();selected=uid;
  void transaction({type:'position',uid,coords:state.positions[uid].map((v,i)=>v+direction[i])}).then(()=>$(`[data-marker="${uid}"]`)?.focus());
});
function point(e,field){const r=field.getBoundingClientRect();return [100*(e.clientX-r.left)/r.width,100*(e.clientY-r.top)/r.height].map(v=>Math.round(Math.max(8,Math.min(92,v))));}
document.addEventListener('pointerdown',e=>{
  const field=e.target.closest('#field');if(!field)return;
  const marker=e.target.closest('[data-marker]');
  if(marker){selected=marker.dataset.marker;drag={field,marker,id:e.pointerId,moved:false,x:e.clientX,y:e.clientY};field.setPointerCapture(e.pointerId);}
  else void transaction({type:'position',uid:selected,coords:point(e,field)});
});
document.addEventListener('pointermove',e=>{
  if(drag?.id!==e.pointerId)return;
  if(Math.hypot(e.clientX-drag.x,e.clientY-drag.y)>3)drag.moved=true;
  if(drag.moved){const [x,y]=point(e,drag.field);drag.marker.style.left=`${x}%`;drag.marker.style.top=`${y}%`;}
});
document.addEventListener('pointerup',e=>{
  if(drag?.id!==e.pointerId)return;
  const {field,moved,marker}=drag;drag=null;
  if(moved)void transaction({type:'position',uid:selected,coords:point(e,field)});else openUnit(selected,marker);
});
document.addEventListener('pointercancel',()=>{drag=null;renderPanel();});
addEventListener('hashchange',()=>{if(validTabs.includes(location.hash.slice(1))){tab=location.hash.slice(1);renderPanel();}});
addEventListener('storage',e=>{if(e.key===saveKey&&!busy&&!community?.active()){state=load()??state;if(!drag)renderPanel();if(profileUid)renderProfile();}});
addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;$('#install').hidden=false;});
if(location.protocol!=='file:'&&'serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});

renderPanel();
let saveTick=Date.now();
function observe(){
  if(document.hidden)return;
  const now=Date.now(),returned=lastObservation===null||now-lastObservation>=AWAY_THRESHOLD;
  lastObservation=now;
  if(returned||state.awayReports?.length&&!$('#away-dialog').open)void transaction(null,true);
}
for(const event of ['pointerdown','keydown','pointermove','wheel'])document.addEventListener(event,observe,{passive:true});
addEventListener('focus',()=>{observe();void transaction(null,true);});
$('#away-dialog').addEventListener('cancel',event=>{event.preventDefault();$('#away-continue').click();});
$('#away-continue').addEventListener('click',()=>{const report=state.awayReports?.[0];if(report)void transaction({type:'dismissAway',end:report.end});});
if(!initialSave&&!storageIssue&&!community?.active()&&location.protocol==='file:'){
  note('Primeira campanha neste arquivo. Já jogava? Em Configurações, importe seu backup ou abra a atualização no caminho do HTML antigo.');
}
const wasAway=gameNow()-state.clock>=AWAY_THRESHOLD;
void transaction(null,wasAway).then(()=>{renderPanel();drawScene(gameNow());});
setInterval(()=>{
  if(document.hidden)return;
  const now=gameNow();

  if(!busy&&(state.pending?.end<=now||state.team.length&&state.running&&!state.pending&&Math.max(state.nextAt,Math.min(...state.team.map(uid=>readyAt(state,uid))))<=now||Date.now()-saveTick>(community?.ready()?8000:12000))){
    saveTick=Date.now();void transaction(null,now-state.clock>45000).then(()=>{
      if(tab==='exploracao'&&($('#panel [data-action="boss"]')?.disabled??true)!==(!readyForBoss(state)||!!state.pending))renderPanel();
    });
  }
  if(tab==='arena')updateDuelButton();
  if(tab==='formacao')document.querySelectorAll('[data-recovery]').forEach(el=>{
    const left=readyAt(state,el.dataset.recovery)-now;
    el.textContent=left>0?'Recupera em '+Math.ceil(left/1000)+' s':'';
  });
  if(tab==='exploracao'){
    drawScene(now);
    const boss=$('#panel [data-action="boss"]');
    if(boss)boss.disabled=!readyForBoss(state)||!!state.pending||state.team.every(uid=>readyAt(state,uid)>now);
  }
  community?.tick();
},130);

document.addEventListener('visibilitychange',()=>{
  if(!document.hidden)observe();
  saveTick=Date.now();void transaction(null,!document.hidden);
});
