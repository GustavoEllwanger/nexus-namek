import { Combate } from './engine.js';

export const AREAS = [
  { id:'entrada', name:'Costa de Namek', description:'Patrulhas do império rondam o litoral.', levels:[1,3], unlock:1, enemy:'Soldado da Tropa Freeza', base:[150,18,9,9], color:'Roxo' },
  { id:'meio', name:'Planícies Verdes', description:'O terreno aberto favorece as tropas de elite.', levels:[4,6], unlock:4, enemy:'Veterano da Tropa Freeza', base:[220,23,12,12], color:'Amarelo' },
  { id:'final', name:'Base de Freeza', description:'Vença 12 encontros nesta área para liberar Freeza.', levels:[7,10], unlock:7, enemy:'Oficial da Tropa Freeza', base:[300,28,14,14], color:'Vermelho' },
];
export const BOSS = {name:'Freeza · Forma Final',base:[520,38,18,18], color:'Roxo'};
export const WORLDS = [
  {
    name:"Namek", universe:"Dragon Ball",
    areas:AREAS,
    elite:{"name": "Capitão Ginyu", "level": 11, "base": [380, 33, 16, 16]},
    boss:{"name": "Freeza · forma final", "level": 12, "base": [520, 38, 18, 18], "kind": "freeza-boss", "color": "Roxo"},
  },
  {
    name:"Arlong Park", universe:"One Piece",
    areas:[
      {"name": "Costa de Cocoyasi", "enemy": "Vigia dos Piratas Arlong", "levels": [11, 13], "unlock": 1, "base": [150, 18, 9, 9], "color": "Amarelo", "description": "Vigia dos Piratas Arlong"},
      {"name": "Vila de Cocoyasi", "enemy": "Homem-peixe dos Piratas Arlong", "levels": [14, 16], "unlock": 14, "base": [220, 23, 12, 12], "color": "Vermelho", "description": "Homem-peixe dos Piratas Arlong"},
      {"name": "Fortaleza de Arlong", "enemy": "Veterano dos Piratas Arlong", "levels": [17, 20], "unlock": 17, "base": [300, 28, 14, 14], "color": "Azul", "description": "Veterano dos Piratas Arlong"}
    ],
    elite:{"name": "Kuroobi", "level": 21, "base": [385, 33, 16, 16]},
    boss:{"name": "Arlong", "level": 22, "base": [532, 38, 18, 18], "kind": "rush", "color": "Azul"},
  },
  {
    name:"Exames Chūnin", universe:"Naruto",
    areas:[
      {"name": "Portões da Folha", "enemy": "Genin rival", "levels": [21, 23], "unlock": 1, "base": [150, 18, 9, 9], "color": "Vermelho", "description": "Genin rival"},
      {"name": "Floresta da Morte", "enemy": "Genin da Vila do Som", "levels": [24, 26], "unlock": 24, "base": [220, 23, 12, 12], "color": "Azul", "description": "Genin da Vila do Som"},
      {"name": "Arena dos Exames", "enemy": "Genin da Vila da Areia", "levels": [27, 30], "unlock": 27, "base": [300, 28, 14, 14], "color": "Verde", "description": "Genin da Vila da Areia"}
    ],
    elite:{"name": "Neji Hyūga", "level": 31, "base": [390, 33, 16, 16]},
    boss:{"name": "Gaara · transformação parcial", "level": 32, "base": [544, 38, 18, 18], "kind": "ward", "color": "Laranja"},
  },
  {
    name:"Soul Society", universe:"Bleach",
    areas:[
      {"name": "Rukongai", "enemy": "Shinigami em patrulha", "levels": [31, 33], "unlock": 1, "base": [150, 18, 9, 9], "color": "Azul", "description": "Shinigami em patrulha"},
      {"name": "Muralhas do Seireitei", "enemy": "Soldado da guarda do Seireitei", "levels": [34, 36], "unlock": 34, "base": [220, 23, 12, 12], "color": "Verde", "description": "Soldado da guarda do Seireitei"},
      {"name": "Colina de Sōkyoku", "enemy": "Oficial de esquadrão", "levels": [37, 40], "unlock": 37, "base": [300, 28, 14, 14], "color": "Turquesa", "description": "Oficial de esquadrão"}
    ],
    elite:{"name": "Renji Abarai", "level": 41, "base": [395, 33, 16, 16]},
    boss:{"name": "Byakuya Kuchiki", "level": 42, "base": [556, 38, 18, 18], "kind": "beam", "color": "Rosa"},
  },
  {
    name:"Jujutsu Kaisen", universe:"Jujutsu Kaisen",
    areas:[
      {"name": "Escola de Jujutsu", "enemy": "Maldição menor", "levels": [41, 43], "unlock": 1, "base": [150, 18, 9, 9], "color": "Verde", "description": "Maldição menor"},
      {"name": "Distrito amaldiçoado", "enemy": "Maldição de distrito", "levels": [44, 46], "unlock": 44, "base": [220, 23, 12, 12], "color": "Turquesa", "description": "Maldição de distrito"},
      {"name": "Domínio vulcânico", "enemy": "Maldição de grau 2", "levels": [47, 50], "unlock": 47, "base": [300, 28, 14, 14], "color": "Rosa", "description": "Maldição de grau 2"}
    ],
    elite:{"name": "Portador de Dedo", "level": 51, "base": [400, 33, 16, 16]},
    boss:{"name": "Jogo", "level": 52, "base": [568, 38, 18, 18], "kind": "ginyu", "color": "Vermelho"},
  },
  {
    name:"Black Clover", universe:"Black Clover",
    areas:[
      {"name": "Vila de Hage", "enemy": "Recruta do Olho do Sol da Meia-Noite", "levels": [51, 53], "unlock": 1, "base": [150, 18, 9, 9], "color": "Turquesa", "description": "Recruta do Olho do Sol da Meia-Noite"},
      {"name": "Floresta encantada", "enemy": "Mago do Olho do Sol da Meia-Noite", "levels": [54, 56], "unlock": 54, "base": [220, 23, 12, 12], "color": "Rosa", "description": "Mago do Olho do Sol da Meia-Noite"},
      {"name": "Templo submerso", "enemy": "Veterano do Olho do Sol da Meia-Noite", "levels": [57, 60], "unlock": 57, "base": [300, 28, 14, 14], "color": "Laranja", "description": "Veterano do Olho do Sol da Meia-Noite"}
    ],
    elite:{"name": "Fana", "level": 61, "base": [405, 33, 16, 16]},
    boss:{"name": "Vetto", "level": 62, "base": [580, 38, 18, 18], "kind": "rush", "color": "Verde"},
  },
  {
    name:"Nanatsu no Taizai", universe:"Nanatsu no Taizai",
    areas:[
      {"name": "Arredores de Liones", "enemy": "Recruta de Liones", "levels": [61, 63], "unlock": 1, "base": [150, 18, 9, 9], "color": "Rosa", "description": "Recruta de Liones"},
      {"name": "Cidade de Liones", "enemy": "Cavaleiro de Liones", "levels": [64, 66], "unlock": 64, "base": [220, 23, 12, 12], "color": "Laranja", "description": "Cavaleiro de Liones"},
      {"name": "Castelo real", "enemy": "Cavaleiro Sagrado", "levels": [67, 70], "unlock": 67, "base": [300, 28, 14, 14], "color": "Roxo", "description": "Cavaleiro Sagrado"}
    ],
    elite:{"name": "Dreyfus", "level": 71, "base": [410, 33, 16, 16]},
    boss:{"name": "Hendrickson · forma demoníaca", "level": 72, "base": [592, 38, 18, 18], "kind": "beam", "color": "Preto"},
  },
  {
    name:"JoJo", universe:"JoJo",
    areas:[
      {"name": "Ruas do Cairo", "enemy": "Capanga de DIO", "levels": [71, 73], "unlock": 1, "base": [150, 18, 9, 9], "color": "Laranja", "description": "Capanga de DIO"},
      {"name": "Distrito antigo", "enemy": "Usuário de Stand a serviço de DIO", "levels": [74, 76], "unlock": 74, "base": [220, 23, 12, 12], "color": "Roxo", "description": "Usuário de Stand a serviço de DIO"},
      {"name": "Mansão de DIO", "enemy": "Usuário de Stand veterano", "levels": [77, 80], "unlock": 77, "base": [300, 28, 14, 14], "color": "Amarelo", "description": "Usuário de Stand veterano"}
    ],
    elite:{"name": "Vanilla Ice", "level": 81, "base": [415, 33, 16, 16]},
    boss:{"name": "DIO · The World", "level": 82, "base": [604, 38, 18, 18], "kind": "rush", "color": "Amarelo"},
  },
  {
    name:"Hunter × Hunter", universe:"Hunter × Hunter",
    areas:[
      {"name": "Fronteira de NGL", "enemy": "Formiga Quimera operária", "levels": [81, 83], "unlock": 1, "base": [150, 18, 9, 9], "color": "Roxo", "description": "Formiga Quimera operária"},
      {"name": "Território das formigas", "enemy": "Formiga Quimera soldado", "levels": [84, 86], "unlock": 84, "base": [220, 23, 12, 12], "color": "Amarelo", "description": "Formiga Quimera soldado"},
      {"name": "Palácio Real", "enemy": "Formiga Quimera capitã", "levels": [87, 90], "unlock": 87, "base": [300, 28, 14, 14], "color": "Vermelho", "description": "Formiga Quimera capitã"}
    ],
    elite:{"name": "Neferpitou", "level": 91, "base": [420, 33, 16, 16]},
    boss:{"name": "Meruem", "level": 92, "base": [616, 38, 18, 18], "kind": "rush", "color": "Verde"},
  },
  {
    name:"One Punch Man", universe:"One Punch Man",
    areas:[
      {"name": "Periferia da Cidade Z", "enemy": "Monstro nível Lobo", "levels": [91, 93], "unlock": 1, "base": [150, 18, 9, 9], "color": "Amarelo", "description": "Monstro nível Lobo"},
      {"name": "Zona evacuada", "enemy": "Monstro nível Tigre", "levels": [94, 96], "unlock": 94, "base": [220, 23, 12, 12], "color": "Vermelho", "description": "Monstro nível Tigre"},
      {"name": "Covil dos monstros", "enemy": "Monstro nível Demônio", "levels": [97, 100], "unlock": 97, "base": [300, 28, 14, 14], "color": "Azul", "description": "Monstro nível Demônio"}
    ],
    elite:{"name": "Rei do Mar Profundo", "level": 101, "base": [425, 33, 16, 16]},
    boss:{"name": "Boros", "level": 102, "base": [628, 38, 18, 18], "kind": "freeza-boss", "color": "Vermelho"},
  }
];
export const worldOf = state=>WORLDS[state.world??0];
export const levelCap = state=>10*(1+(state.unlocked??0));
export const COLORS = {Verde:'#71dd9f',Laranja:'#ffab68',Amarelo:'#f5d66c',Azul:'#83baff',Branco:'#ecebff',Roxo:'#cc95ff',Rosa:'#f592bc',Preto:'#a8a2be',Vermelho:'#ff8290',Turquesa:'#70e1da',Dourado:'#ffe28a'};
export const TIERS = ['Comum','Incomum','Rara','Épica','Mítica','Divina','Secreta','Transcendente'];
const baseStats = [[100,20,20,12,12,100],[106,21,21,13,13,101],[113,23,23,14,14,102],[121,24,24,15,15,103],[130,26,26,16,16,104],[140,28,28,17,17,105],[151,30,30,18,18,106],[164,33,33,20,20,108]];
const roles = {Combatente:[.10,.25,-.15,0,0,0],Guardião:[.25,-.10,0,.25,.15,0],Mágico:[-.15,0,.30,0,.10,0],Suporte:[0,-.15,.15,0,.15,.05]};
const roster = [
  ["shinra_banshoman", "Shinra Banshōman", 8, "Dourado", "Combatente", "reescrita", "Reescrita da Realidade", "Ataque dos Dourados +22%", "fighter", "Fire Force"],
  ["benimaru_shinmon", "Benimaru Shinmon", 7, "Vermelho", "Combatente", "nichirin", "Nichirin", "Ataque dos Vermelhos +18%", "fighter", "Fire Force"],
  ["luminous", "Luminous Valentine", 7, "Rosa", "Suporte", "ciclo_vital", "Ciclo de Vida e Morte", "PV dos Rosas +18%", "support", "Tensei Shitara Slime Datta Ken"],
  ["veldora", "Veldora Tempest", 7, "Turquesa", "Mágico", "tempestade", "Tempestade do Dragão", "Magia dos Turquesas +18%", "freeza", "Tensei Shitara Slime Datta Ken"],

  ["mayuri", "Mayuri Kurotsuchi", 5, "Roxo", "Mágico", "ashisogi", "Ashisogi Jizō", "Magia dos Roxos +15%", "support", "Bleach"],
  ["starrk", "Coyote Starrk", 6, "Azul", "Mágico", "metralleta", "Cero Metralleta", "Magia dos Azuis +15%", "fighter", "Bleach"],
  ["yoruichi", "Yoruichi Shihōin", 5, "Amarelo", "Combatente", "shunko", "Shunkō", "Ataque dos Amarelos +15%", "fighter", "Bleach"],
  ["urahara", "Kisuke Urahara", 6, "Verde", "Suporte", "bulma", "Benihime · Escudo de Sangue", "PV dos Verdes +15%", "support", "Bleach"],
  ["shinra", "Shinra Kusakabe", 4, "Vermelho", "Combatente", "rush", "Chute de Ignição", "Ataque dos Vermelhos +12%", "fighter", "Fire Force"],
  ["arthur", "Arthur Boyle", 4, "Azul", "Combatente", "excalibur", "Excalibur", "Ataque dos Azuis +12%", "fighter", "Fire Force"],
  ["maki_oze", "Maki Oze", 3, "Laranja", "Guardião", "ward", "Guarda das Chamas", "PV dos Laranjas +10%", "namek", "Fire Force"],
  ["iris", "Iris", 2, "Branco", "Suporte", "heal", "Prece da Companhia 8", "PV dos Brancos +10%", "support", "Fire Force"],
  ['piccolo','Piccolo',4,'Verde','Guardião','piccolo','Proteção Namekuseijin','Defesa e Resistência de Dragon Ball +12%','namek'],
  ['yamcha','Yamcha',1,'Laranja','Combatente','yamcha','Punho do Lobo','Ataque de Combatentes +8%','fighter'],
  ['kuririn','Kuririn',2,'Amarelo','Mágico','kuririn','Disco Cortante','Magia dos Amarelos +10%','monk'],
  ['bulma','Bulma',1,'Azul','Suporte','bulma','Cápsula de Proteção','PV dos Azuis +8%','support'],
  ['tenshinhan','Tenshinhan',3,'Branco','Suporte','ward','Taiyōken','Velocidade dos Brancos +10%','monk'],
  ['gohan','Gohan · Namek',4,'Amarelo','Combatente','rush','Explosão de Raiva','Ataque dos Amarelos +10%','fighter'],
  ['freeza','Freeza · Forma Final',5,'Roxo','Mágico','beam','Raio da Morte','Magia dos Roxos +15%','freeza'],
  ['android17','Android 17',6,'Verde','Guardião','ward','Barreira Contínua','Defesa dos Verdes +15%','fighter'],
  ['vegeta','Vegeta · Blue',7,'Azul','Combatente','rush','Final Flash','Ataque dos Azuis +18%','fighter'],
  ['broly','Broly · Super',7,'Verde','Combatente','rush','Fúria Crescente','Ataque de Combatentes +18%','namek'],
  ['goku','Goku · Instinto Superior',8,'Branco','Combatente','rush','Resposta Instintiva','Ataque de Dragon Ball +22%','fighter'],
  ['beerus','Beerus',8,'Roxo','Mágico','beerus','Hakai','Magia de Mágicos +22%','freeza'],
  ['usopp','Usopp',1,'Amarelo','Suporte','heal','Estilingue','PV dos Amarelos +8%','support','One Piece'],
  ['nami','Nami',2,'Turquesa','Mágico','beam','Nuvem de Tempestade','Magia dos Turquesas +10%','support','One Piece'],
  ['rocklee','Rock Lee',3,'Verde','Combatente','rush','Lótus Primária','Velocidade dos Verdes +10%','fighter','Naruto'],
  ['zoro','Zoro',4,'Verde','Combatente','rush','Santōryū','Ataque dos Verdes +12%','fighter','One Piece'],
  ['law','Trafalgar Law',5,'Azul','Suporte','bulma','ROOM','PV dos Azuis +12%','support','One Piece'],
  ['gojo','Gojo',8,'Azul','Mágico','beam','Vazio Ilimitado','Magia dos Azuis +22%','fighter','Jujutsu Kaisen'],
  ['netero','Netero',6,'Dourado','Combatente','rush','Mãos do Bodisatva','Ataque dos Dourados +15%','monk','Hunter × Hunter'],
  ['mob','Mob · ???%',7,'Preto','Mágico','beam','Despertar Psíquico','Magia dos Pretos +18%','support','Mob Psycho 100'],
  ['accelerator','Accelerator',8,'Branco','Guardião','accelerator','Controle Vetorial','Resistência dos Brancos +22%','fighter','Toaru'],
];
const approvedArt = {
  "yamcha": "yamcha",
  "bulma": "bulma",
  "piccolo": "piccolo",
  "kuririn": "kuririn",
  "gohan": "gohan-namek",
  "tenshinhan": "tenshinhan",
  "freeza": "freeza-forma-final",
  "android17": "android-17-torneio-do-poder",
  "vegeta": "vegeta-super-saiyajin-blue",
  "broly": "broly-super",
  "goku": "goku-instinto-superior",
  "beerus": "beerus",
  "usopp": "usopp",
  "nami": "nami",
  "rocklee": "rock-lee",
  "zoro": "zoro",
  "law": "trafalgar-law",
  "gojo": "gojo",
  "netero": "netero",
  "mob": "mob-por-cento",
  "accelerator": "accelerator",
  "shinra_banshoman": "shinra-banshoman",
  "benimaru_shinmon": "benimaru-shinmon",
  "luminous": "luminous-valentine",
  "veldora": "veldora-tempest",
  "shinra": "shinra-kusakabe",
  "arthur": "arthur-boyle",
  "maki_oze": "maki-oze",
  "iris": "iris",
  "mayuri": "mayuri-kurotsuchi",
  "starrk": "coyote-starrk",
  "yoruichi": "yoruichi-shihoin",
  "urahara": "kisuke-urahara"
};

export function spriteFor(unit){
  const slug=approvedArt[unit.id];
  if(!slug)return CHARACTERS[unit.id].sprite;
  return "ap-"+slug+(unit.shiny?"-shiny":"");
}

export const CHARACTERS = Object.fromEntries(roster.map(([id,name,tier,color,role,kind,skill,leader,sprite,universe='Dragon Ball'])=>[id,{id,name,tier,color,role,kind,skill,leader,sprite:approvedArt[id]?"ap-"+approvedArt[id]:sprite,universe}]));
export const SKILL_EFFECTS = {
  reescrita:"Golpeia com 190% do Ataque. Uma vez por luta, se um aliado em campo estiver com até 40% de PV, usa a ação para restaurar metade dos PV máximos do mais ferido. Recarga de 9 s.",
  nichirin:"Atinge o alvo com 180% do Ataque e os demais inimigos a até 28 unidades dele com 85% do Ataque. Recarga de 10 s.",
  ciclo_vital:"Cura em 200% da Magia o aliado em campo com a menor porcentagem de PV e atinge o adversário com 105% da Magia. Recarga de 9 s.",
  tempestade:"Desfere um raio de 185% da Magia que ignora 30% da Resistência. Um arco secundário de 75% da Magia atinge outro inimigo em campo, se houver. Recarga de 10 s.",

  ashisogi:"Enfraquece os ataques básicos do alvo em 35% por 4 s e causa dano mágico de 130% da Magia. Recarga de 9 s.",
  metralleta:"Dispara três tiros de 60% da Magia contra o mesmo alvo. Recarga de 9 s.",
  shunko:"Golpeia com 140% do Ataque e ganha uma carga de esquiva contra um golpe de alvo único. Recarga de 12 s.",
  excalibur:"O corte de plasma causa 145% do Ataque e ignora 35% da Defesa do alvo. Recarga de 7 s.",

  piccolo:'Cria um escudo de 110% da Magia e pode interceptar um golpe contra um aliado próximo nos 4,5 s seguintes.',
  bulma:'Aplica um escudo de 200% da Magia ao aliado com a menor porcentagem de PV, quando ele tem 95% de PV ou menos.',
  heal:'Cura o aliado com a menor porcentagem de PV em 130% da Magia, quando ele tem 95% de PV ou menos.',
  yamcha:'Causa dano físico equivalente a 160% do Ataque.',
  kuririn:'Causa dano mágico equivalente a 165% da Magia ao inimigo com menos PV.',
  beam:'Causa dano mágico equivalente a 165% da Magia.',
  beerus:'Remove o escudo, causa dano mágico equivalente a 240% da Magia e bloqueia a ressurreição se o golpe for fatal.',
  accelerator:'Reflete até duas habilidades de alvo único por luta, com recarga de 8 s e alcance de um espaço na ordem da formação.',
};
SKILL_EFFECTS.ward=SKILL_EFFECTS.piccolo;
SKILL_EFFECTS.rush=SKILL_EFFECTS.yamcha;
const chanceByTier = [.55,.27,.12,.045,.012,.0025,.00045,.00005];
const passives={
  'Haki do Rei':'Ao iniciar a luta, trava as ações inimigas por 2 s. Durante esse período, os inimigos recebem 30% mais dano. Uma ativação por equipe.',
  'Instinto Superior':'Esquiva dos três primeiros golpes diretos de alvo único e contra-ataca o agressor se ele estiver em campo e o portador puder agir.',
  'Restrição Celestial':'Intercepta os dois primeiros golpes de alvo único contra aliados próximos e sofre metade do dano. Na Arena, pode proteger o titular da reserva.',
  'Haki da Observação':'Até duas vezes por luta, antecipa uma habilidade de alvo único com um golpe de 200% do dano básico. Eliminar o atacante cancela a habilidade.',
  'Zenkai':'Uma vez por luta, sobrevive a um golpe fatal com 40% dos PV máximos e ganha +75% de Ataque e Magia até o fim do combate.',
  'Full Counter':'Reflete a primeira habilidade mágica de alvo único que atingir o portador ou um aliado próximo. Devolve o dobro do dano-base da habilidade.',
  'The World':'Após a primeira habilidade principal bem-sucedida, para o tempo por 3 s. Só o portador pode agir e sua habilidade fica pronta outra vez.',
  'Voto de Nen':'Última Aposta é opcional. Ative na ficha para causar 4× o dano e ocupar duas vagas. Desative para voltar a usar uma vaga e conservar os bônus de atributos.',
  'Made in Heaven':'Causa 4× o dano durante toda a luta e ocupa uma vaga. Na primeira ação ofensiva, ativa Aceleração do Tempo por 5 s. O intervalo de ações cai 80% para o portador e 40% para aliados. A aceleração coletiva não acumula.'
};
const T=(name,odds,buffs)=>({name,odds,buffs,passive:passives[name]??null,
  rarity:TIERS[odds<=5?0:odds<=10?1:odds<=25?2:odds<=50?3:odds<=125?4:odds<=250?5:odds<=1000?6:7]});
export const TRAITS = [T('Concentração Total',4,[.3,0,0,0,0,0]),T('Reforço Amaldiçoado',5,[0,.25,.25,0,0,0]),T('Haki do Armamento',10,[0,0,0,.4,0,0]),T('Ten',10,[0,0,0,0,.4,0]),T('Kaidō',20,[0,0,.35,0,.2,0]),T('Shunpo',20,[0,.2,0,0,0,.35]),T('Modo Sábio',25,[.35,0,0,.25,.25,0]),T('Respiração do Trovão',25,[0,.4,0,0,0,.25]),T('Haki do Rei',50,[.3,.5,.5,0,0,0]),T('Instinto Superior',100,[0,.4,.4,0,0,.5]),T('Restrição Celestial',125,[.6,0,0,.5,.5,0]),T('Haki da Observação',125,[0,.4,0,.4,0,0]),T('Zenkai',200,[.45,0,0,.35,0,0]),T('Full Counter',250,[0,0,0,.6,.6,0]),T('The World',500,[0,.6,.6,0,0,.4]),T('Voto de Nen',1000,[.6,0,0,.4,.4,0]),T('Made in Heaven',2000,[0,0,0,0,.5,0])];
const initial = ['piccolo','yamcha','kuririn','bulma'];
const position = [[72,47],[56,72],[39,28],[22,59]];
const HOUR = 3600000;
export const UPGRADES = {
  ritmo:{name:'Ritmo de expedição',worlds:[1,2,4,6,8],costs:[350,6000,50000,150000,400000],values:[10,9,8,7,6,5],unit:' s',description:'Reduz a espera entre encontros.'},
  sorte:{name:'Sorte',worlds:[1,1,1,2,4,6,8],costs:[180,420,900,6500,48000,155000,410000],values:[10,11,12,13,14,15,16,17],unit:'%',description:'Aumenta a chance de encontrar um recruta. A distribuição de raridades, Shiny e Traits é a mesma.'},
  ouro:{name:'Bônus de ouro',worlds:[1,1,1,2,4,6,8],costs:[220,480,960,7500,54000,170000,440000],values:[0,10,20,30,35,40,45,50],unit:'%',description:'Aumenta o ouro das vitórias em encontros comuns.'},
  xp:{name:'Experiência compartilhada',worlds:[1,1,1,2,4,6,8],costs:[150,360,750,5500,42000,135000,360000],values:[0,25,40,60,70,80,90,100],unit:'%',description:'Distribui entre os reservas uma fração da XP que um titular recebe por vitória. Cada titular mantém sua recompensa integral.'},
};
export const xpFor = level => 16 + level*5 + Math.round(.14*level**2);
const scale = level => 1 + .1*(level-1) + .001*(level-1)**2;
const thresholds=[0,0];
for(let level=1;level<100;level++)thresholds.push(thresholds[level]+xpFor(level));
const xpTo=level=>thresholds[level];
export function levelAt(xp){
  let low=1,high=100;
  while(low<high){const mid=Math.ceil((low+high)/2);if(xp>=thresholds[mid])low=mid;else high=mid-1;}
  return low;
}
export function xpProgress(xp,cap=100){
  const level=levelAt(xp);
  return {level,current:xp-xpTo(level),required:level<cap?xpFor(level):0};
}
export const maxLevel = state=>Math.max(1,...state.team.map(id=>levelAt(state.collection.find(x=>x.uid===id).xp)));
export const readyForBoss = state=>state.team.length>0 && state.finalWins>=12 && !state.completed;
export const upgradeLevel = (state,id)=>state.upgrades?.[id]??(id==='ritmo'&&state.upgraded?1:0);
const upgradeValue = (state,id)=>UPGRADES[id].values[upgradeLevel(state,id)];
export const waitFor = state=>upgradeValue(state,'ritmo')*1000;

export function buyUpgrade(state,id){
  if(!Object.hasOwn(UPGRADES,id))return false;
  const level=upgradeLevel(state,id);
  const cost=UPGRADES[id].costs[level];
  if(cost===undefined||state.gold<cost||(state.unlocked??0)+1<UPGRADES[id].worlds[level])return false;
  state.gold-=cost;
  (state.upgrades??={})[id]=level+1;
  return true;
}

export function fresh(now=Date.now(),seed=Date.now()>>>0){
  const collection = initial.map(id=>({uid:`initial-${id}`,id,xp:0,serial:1,shiny:false,trait:null,odds:null}));
  return {version:1,seed,created:now,collection,team:collection.map(x=>x.uid),positions:Object.fromEntries(collection.map((x,i)=>[x.uid,position[i]])),leader:collection[0].uid,area:0,gold:0,wins:0,losses:0,finalWins:0,streak:0,upgrades:{},completed:false,world:0,unlocked:0,journey:{},autoRoutes:true,paused:false,running:true,nextAt:now,waitDuration:0,pending:null,index:0,clock:now,log:[]};
}

const starterBonus = {piccolo:[.05,0,0,.05,0,0],yamcha:[0,.05,0,0,0,.05],kuririn:[0,0,.05,0,0,0],bulma:[0,0,0,0,.05,0]};
function leaderBuff(leader,member){
  if(!leader) return [];
  if(leader.id==='piccolo') return leader.universe===member.universe?[0,0,0,.12,.12]:[];
  if(leader.id==='yamcha') return member.role==='Combatente'?[0,.08]:[];
  const roleMatch = {broly:'Combatente',beerus:'Mágico'};
  const eligible = roleMatch[leader.id] ? member.role===roleMatch[leader.id] : leader.id==='goku' ? member.universe===leader.universe : member.color===leader.color;
  if(!eligible) return [];
  const amount = [.08,.10,.10,.12,.15,.15,.18,.22][leader.tier-1];
  if(leader.id==='gohan') return [0,.10];
  if(leader.id==='law') return [.12];
  if(['tenshinhan','rocklee'].includes(leader.id)) return [0,0,0,0,0,amount];
  if(leader.id==='android17') return [0,0,0,amount];
  if(leader.id==='accelerator') return [0,0,0,0,amount];
  if(leader.role==='Mágico') return [0,0,amount];
  if(leader.role==='Combatente') return [0,amount];
  return [amount];
}

export function fighter(unit, coords=[55,50], leader=null, tactical=false){
  const card=CHARACTERS[unit.id];
  const level=levelAt(unit.xp);
  const growth=scale(level);
  const trait=TRAITS.find(t=>t.name===unit.trait);
  const [hp,attack,magic,defense,resistance,speed]=baseStats[card.tier-1].map((base,i)=>Math.round(Math.round(baseStats[0][i]+.7*(base-baseStats[0][i]))*(1+roles[card.role][i])*(1+(starterBonus[card.id]?.[i]||0))*(1+(trait?.buffs[i]||0))*(1+(leaderBuff(leader,card)[i]||0))*(i===5?1:growth*(unit.shiny?1.25:1))));
  const [x,y]=coords;
  return {...card, uid:unit.uid,trait:unit.trait,nen:unit.trait==="Voto de Nen"&&unit.nen===true, level, x,y,hp,attack,magic,defense,resistance,speed,scale:growth,interval:tactical?Math.max(600,Math.round(300000/speed/100)*100):3000,magicBasic:card.role==='Mágico'||card.role==='Suporte',evade:unit.trait==='Instinto Superior'?3:0,survive:unit.trait==='Zenkai'?1:0,sprite:spriteFor(unit)};
}

function rng(seed,index){
  let state=(seed^Math.imul(index+1,2654435761))>>>0 || 1;
  return ()=>{state^=state<<13;state^=state>>>17;state^=state<<5;return (state>>>0)/4294967296;};
}
function pickTrait(random){
  let p=random();for(const t of TRAITS){p-=1/t.odds;if(p<0)return t;}return null;
}
export function rollRecruit(random,chance=.10,universe='Dragon Ball'){
  if(random()>=chance) return null;
  let p=random(),tier=1;
  for(const weight of chanceByTier){if(p<weight)break;p-=weight;tier++;}
  tier=Math.min(tier,8);
  const candidates=Object.values(CHARACTERS).filter(c=>c.tier===tier);
  const local=candidates.filter(c=>c.universe===universe);
  const others=candidates.filter(c=>c.universe!==universe);
  const group = !local.length ? others : !others.length || random()<.6 ? local : others;
  const groupP=local.length&&others.length?(group===local?.6:.4):1;
  const card=group[Math.floor(random()*group.length)];
  const shinyP=tier>=7?.1:.05;
  const shiny=random()<shinyP;
  const trait=pickTrait(random);
  const traitP=trait?1/trait.odds:1-TRAITS.reduce((sum,t)=>sum+1/t.odds,0);
  return {id:card.id,shiny,trait:trait?.name??null,odds:Math.round(1/(chance*chanceByTier[tier-1]*groupP/group.length*(shiny?shinyP:1-shinyP)*traitP))};
}

export const SALE_PRICES=[8,20,50,125,350,1000,3500,12000];
export const RECOVERY_MS=20000;
export function readyAt(state,uid){
  return Math.max(state.partyRecovery??0,state.recovery?.[uid]??0);
}
function firstReady(state){
  return Math.min(...state.team.map(uid=>readyAt(state,uid)));
}

export function makeBattle(state,start,boss=false){
  const random=rng(state.seed,state.index++);
  const world=worldOf(state);
  const area=world.areas[state.area];
  const elite=!boss&&state.area===2&&state.index%7===0;
  const special=boss?world.boss:elite?world.elite:null;
  const leader=state.collection.find(c=>c.uid===state.leader);
  const available=state.team.filter(uid=>readyAt(state,uid)<=start);
  const team=available.map(uid=>fighter(state.collection.find(c=>c.uid===uid),state.positions[uid],available.includes(leader?.uid)?CHARACTERS[leader.id]:null,!!special));
  const level=special?special.level:Math.max(area.levels[0],Math.min(area.levels[1],maxLevel(state)+Math.floor(random()*3)-1));
  const recruit=special?null:rollRecruit(random,upgradeValue(state,'sorte')/100,world.universe);
  const grow=scale(level);
  const [hp,power,def,res]=(special?.base??area.base).map(x=>Math.round(x*grow));
  const baseEnemy={name:special?.name??area.enemy,hp,attack:power,magic:boss?Math.round(power*.88):power,defense:def,resistance:res,scale:grow,color:boss?world.boss.color:area.color,level,sprite:`enemy-${(state.world??0)+1}-${boss?5:elite?4:state.area+1}`,interval:boss?3200:3000,kind:boss?world.boss.kind:null,x:60,y:50};
  const candidate = recruit ? fighter({...recruit,xp:xpTo(level)},[60,50],null,false) : null;
  const enemy = candidate ? {...baseEnemy,name:candidate.name,sprite:candidate.sprite,trait:candidate.trait,color:candidate.color,kind:candidate.kind, hp:Math.max(hp,Math.round(candidate.hp*1.65)),attack:Math.max(power,candidate.attack),magic:Math.max(power,candidate.magic),magicBasic:candidate.magicBasic,defense:Math.max(def,candidate.defense),resistance:Math.max(res,candidate.resistance),evade:candidate.evade,survive:candidate.survive} : baseEnemy;
  const damageBoost=boss?1.30:elite?1.45:1.55;
  enemy.attack=Math.round(enemy.attack*damageBoost);
  enemy.magic=Math.round(enemy.magic*damageBoost);
  const result=new Combate([team,[enemy]],{mode:'equipe'}).run();
  const simulatedTime=result.seconds*1000;
  const duration=Math.max(1200,Math.min(boss?16000:6000,simulatedTime/(boss?2:4)));
  const reserveShare=upgradeValue(state,'xp')/100;
  const reserves=reserveShare?state.collection.filter(unit=>!state.team.includes(unit.uid)&&unit.xp<xpTo(levelCap(state))).map(unit=>unit.uid):[];
  return {start,end:start+duration,boss,elite,world:state.world??0,area:state.area,level,team,enemy,recruit,result,
    goldBonus:boss?0:upgradeValue(state,'ouro')/100,reserveShare,reserves};
}

function shareExperience(state,battle,xp){
  let available=Math.floor(xp*(battle.reserveShare??0));
  if(!available||!battle.reserves?.length)return 0;
  const maxXp=xpTo(levelCap(state));
  const reserves=new Set(battle.reserves);
  const eligible=state.collection.filter(unit=>reserves.has(unit.uid)&&unit.xp<maxXp).sort((a,b)=>b.xp-a.xp);
  let granted=0;
  for(const [index,unit] of eligible.entries()){
    const amount=Math.min(maxXp-unit.xp,Math.floor(available/(eligible.length-index)));
    unit.xp+=amount;
    available-=amount;
    granted+=amount;
  }
  return granted;
}

function saleMatches(settings,unit){
  const tier=CHARACTERS[unit.id].tier;
  if(!settings?.enabled||!(settings.tiers?.includes(tier)||settings.characters?.includes(unit.id)))return false;
  if(!unit.trait)return true;
  const rule=settings.traitRules?.[tier];
  const trait=TRAITS.find(t=>t.name===unit.trait);
  return !!(trait&&rule&&(trait.odds<rule.below||rule.names?.includes(trait.name)));
}

function settle(state,battle){
  const entry={won:battle.result.winner===0&&battle.result.reason==='eliminação',gold:0,xp:0,reserveXp:0,teamXp:0,recruit:null,boss:battle.boss,label:battle.enemy.name,end:battle.end};
  const fallen=battle.result.events.filter(e=>e.type==='cai'&&e.actor.startsWith('0:'));
  if(fallen.length){
    state.recovery??={};
    for(const e of fallen){
      const unit=battle.team[Number(e.actor.slice(2))];
      const when=battle.start+(battle.end-battle.start)*Math.min(1,e.time/Math.max(1,battle.result.seconds*1000));
      state.recovery[unit.uid]=Math.ceil(when)+RECOVERY_MS;
    }
    if(fallen.length===battle.team.length)state.partyRecovery=battle.end+RECOVERY_MS;
  }
  if(entry.won){
    state.wins++;state.streak=0;
    if(battle.area===2&&!battle.boss) state.finalWins++;
    entry.xp=(8+2*battle.level)*(battle.boss?3:battle.elite?2:1);
    entry.gold=Math.round((6+2*battle.level)*(battle.boss?8:(battle.elite?2:1)*(1+(battle.goldBonus??0))));
    state.gold+=entry.gold;
    for(const fighter of battle.team){const copy=state.collection.find(c=>c.uid===fighter.uid);if(copy){const previous=copy.xp;copy.xp=Math.min(xpTo(levelCap(state)),previous+entry.xp);entry.teamXp+=copy.xp-previous;}}
    entry.reserveXp=shareExperience(state,battle,entry.xp);
    if(battle.recruit){
      const {id,shiny}=battle.recruit;
      const key=id+(shiny?'-shiny':'');
      const serial=1+(state.serials?.[key]??state.collection.reduce((max,c)=>c.id===id&&!!c.shiny===!!shiny?Math.max(max,c.serial):max,0));
      (state.serials??={})[key]=serial;
      const copy={...battle.recruit,uid:`catch-${state.index}`,xp:xpTo(Math.min(levelCap(state),battle.level)),serial};
      const settings=state.autoSell,tier=CHARACTERS[id].tier;
      const match=saleMatches(settings,copy);
      if(match&&state.collection.some(c=>c.id===id&&!!c.shiny===!!shiny&&(c.trait??null)===(copy.trait??null))){
        entry.sold=copy;entry.saleGold=SALE_PRICES[tier-1];entry.gold+=entry.saleGold;state.gold+=entry.saleGold;
      }else{state.collection.push(copy);entry.recruit=copy;}
    }
    if(battle.boss){
      state.completed=true;
      state.unlocked=Math.min(WORLDS.length-1,Math.max(state.unlocked??0,(state.world??0)+1));
    }
    if(state.autoRoutes){
      const areas=worldOf(state).areas;
      state.area=Math.max(state.area,areas.findLastIndex(a=>a.unlock<=maxLevel(state)));
    }
  }else{
    state.losses++;
    if(!battle.boss && ++state.streak>=3){if(state.area>0)state.area--;state.streak=0;}
  }
  state.log=[entry,...state.log].slice(0,25);
  return entry;
}

export function advance(state,now){
  if(state.world===undefined){
    state.world=0;state.unlocked=state.completed?1:0;state.journey={};state.autoRoutes=true;
    state.paused=false;
    if(!state.running&&!state.pending)state.nextAt=now;
    state.running=true;
  }
  const previous=state.clock;
  if(now<previous) return [];
  const cap=Math.min(now,previous+12*HOUR);
  const entries=[];
  while(true){
    if(state.pending){
      if(state.pending.end>cap) break;
      const battle=state.pending;
      state.pending=null;
      entries.push(settle(state,battle));
      state.waitDuration=waitFor(state);
      state.nextAt=battle.end+state.waitDuration;
      state.running=!state.paused;
      if(state.destination!==undefined)travel(state,state.destination);
      continue;
    }
    if(!state.team.length||!state.running||state.nextAt>cap) break;
    const start=Math.max(state.nextAt,firstReady(state));
    if(start>cap)break;
    state.pending=makeBattle(state,start);
  }
  if(now>cap){
    if(state.pending){
      // Preserve the fight and the remaining replay when the AFK window ends mid-battle.
      state.pending.start+=now-cap;
      state.pending.end+=now-cap;
    }
    state.running=!state.paused;
    state.nextAt=now+waitFor(state);
  }
  state.clock=now;
  return entries;
}

export const AWAY_THRESHOLD=10*60*1000;
function newWindow(state,start){
  return {start,encounters:0,wins:0,gold:0,teamXp:0,reserveXp:0,firstRecruit:state.collection.length};
}
export function advanceWithPresence(state,now,observedAt=null){
  const window=state.awayWindow??=newWindow(state,state.clock);
  const all=[];
  function run(until){
    const w=state.awayWindow;
    const limit=w.start+12*HOUR;
    if(until>=state.clock&&state.clock<=limit){
      const entries=advance(state,Math.min(until,limit));
      for(const e of entries){
        if(e.sold){w.sold=(w.sold??0)+1;w.saleGold=(w.saleGold??0)+e.saleGold;}
        w.encounters++;w.wins+=Number(e.won);w.gold+=e.gold;w.teamXp+=e.teamXp;w.reserveXp+=e.reserveXp;all.push(e);
      }
    }
    if(until>limit&&until>state.clock){
      const shift=until-state.clock;
      if(state.pending){state.pending.start+=shift;state.pending.end+=shift;}
      state.nextAt+=shift;state.clock=until;
    }
  }
  if(Number.isFinite(observedAt)&&observedAt>window.start){
    const seen=Math.min(now,observedAt);
    run(seen);
    if(seen-window.start>=AWAY_THRESHOLD){
      (state.awayReports??=[]).push({...window,end:seen,lastRecruit:state.collection.length});
    }
    state.awayWindow=newWindow(state,seen);
  }
  run(now);
  return all;
}

export function startExploration(state,now){
  if(state.pending?.boss||state.running)return false;
  state.running=true;
  if(!state.pending)state.nextAt=Math.max(now,state.nextAt);
  return true;
}

export function challenge(state,now){
  if(!readyForBoss(state))return false;
  if(state.pending||firstReady(state)>now)return false;
  state.pending=makeBattle(state,now,true);
  return true;
}

export function formationSlots(state){
  return state.slots??Array.from({length:4},(_,i)=>state.team[i]??null);
}

export function formationCost(state,slots=state.team){
  return slots.reduce((n,uid)=>n+(uid?(state.collection.find(u=>u.uid===uid)?.nen?2:1):0),0);
}
export function equip(state,uid,replaced,requestedSlot){
  if(!state.collection.some(c=>c.uid===uid)||state.team.includes(uid))return false;
  const slots=formationSlots(state).slice();
  const index=requestedSlot??(replaced?slots.indexOf(replaced):slots.indexOf(null));
  if(!Number.isInteger(index)||index<0||index>=4||slots[index]!== (replaced??null))return false;
  const next=slots.slice();next[index]=uid;
  if(formationCost(state,next)>4)return false;
  state.positions[uid]=(state.positions[replaced]??state.slotPositions?.[index]??position[index]).slice();
  if(!state.leader||state.leader===replaced)state.leader=uid;
  slots[index]=uid;
  state.slots=slots;state.team=slots.filter(Boolean);
  return true;
}

function removeMember(state,uid){
  const slots=formationSlots(state).slice(),index=slots.indexOf(uid);
  if(!uid||index<0)return false;
  state.slotPositions??={};
  state.slotPositions[index]=state.positions[uid];
  slots[index]=null;
  state.slots=slots;state.team=slots.filter(Boolean);
  if(state.leader===uid)state.leader=state.team[0]??null;
  return true;
}

function travel(state,index){
  state.journey[state.world]={area:state.area,completed:state.completed,finalWins:state.finalWins};
  const progress=state.journey[index]??{area:0,completed:false,finalWins:0};
  Object.assign(state,progress,{world:index,streak:0});
  delete state.destination;
}
export function applyGameAction(state,action,now){
  switch(action?.type){
    case 'nen': {
      const u=state.collection.find(c=>c.uid===action.uid);
      if(u?.trait!=='Voto de Nen'||typeof action.enabled!=='boolean')return false;
      if(action.enabled&&!u.nen&&state.team.includes(u.uid)&&formationCost(state)>=4)return false;
      u.nen=action.enabled;return true;
    }
    case 'saleTrait': {
      const {tier,name,below,checked}=action;
      if(!Number.isInteger(tier)||tier<1||tier>TIERS.length)return false;
      const named=name!==undefined;
      if(named&&(!TRAITS.some(t=>t.name===name)||typeof checked!=='boolean'))return false;
      if(!named&&(!Number.isInteger(below)||below<0||below>1000000))return false;
      const settings=state.autoSell??={enabled:false,tiers:[],characters:[]};
      const rules=settings.traitRules??={};
      const rule=rules[tier]??={below:0,names:[]};
      if(!named)rule.below=below;
      else if(checked){if(!rule.names.includes(name))rule.names.push(name);}
      else rule.names=rule.names.filter(n=>n!==name);
      return true;
    }
    case 'saleSetting': {
      const {group,value,checked}=action;
      if(typeof checked!=='boolean'||!['enabled','tiers','characters'].includes(group))return false;
      if(group==='tiers'&&(!Number.isInteger(value)||value<1||value>TIERS.length))return false;
      if(group==='characters'&&!Object.hasOwn(CHARACTERS,value))return false;
      const settings=state.autoSell??={enabled:false,tiers:[],characters:[]};
      if(group==='enabled')settings.enabled=checked;
      else settings[group]=checked?[...new Set([...settings[group],value])]:settings[group].filter(v=>v!==value);
      return true;
    }
    case 'dismissAway': {
      if(!state.awayReports?.length||state.awayReports[0].end!==action.end)return false;
      state.awayReports.shift();return true;
    }
    case 'pause':
      state.running=false;state.paused=true;return true;
    case 'resume':
      state.paused=false;
      return startExploration(state,now);
    case 'autoRoutes':
      state.autoRoutes=action.enabled===true;return true;
    case 'world':
      if(!Number.isInteger(action.index)||action.index<0||action.index>state.unlocked)return false;
      if(state.pending)state.destination=action.index;else travel(state,action.index);
      return true;
    case 'area': {
      const area=Number.isInteger(action.area)&&worldOf(state).areas[action.area];
      if(!area||maxLevel(state)<area.unlock||(!state.autoRoutes&&state.area===action.area))return false;
      state.autoRoutes=false;state.area=action.area;state.streak=0;return true;
    }
    case 'leader':
      if(!state.team.includes(action.uid)||state.leader===action.uid)return false;
      state.leader=action.uid;return true;
    case 'remove': return removeMember(state,action.uid);
    case 'equip': {
      const empty=!state.team.length;
      const changed=equip(state,action.uid,action.replaced,action.slot);
      if(changed&&empty&&!state.pending)state.nextAt=now;
      return changed;
    }
    case 'boss': return challenge(state,now);
    case 'upgrade': return buyUpgrade(state,action.id);
    case 'position': {
      if(!state.team.includes(action.uid))return false;
      const coords=action.coords;
      if(!Array.isArray(coords)||coords.length!==2||!coords.every(Number.isFinite))return false;
      state.positions[action.uid]=coords.map(value=>Math.max(8,Math.min(92,Math.round(value))));
      return true;
    }
    default: return false;
  }
}
