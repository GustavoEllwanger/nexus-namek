// A daily period is keyed by the local calendar date on which its noon began.
export const DAILY_ZONE='America/Sao_Paulo';
export const GIFT_GOLD=10;
export const PROFILE_OPTIONS={
  background:{namek:'Costa de Namek',noite:'Noite violeta',aurora:'Aurora turquesa'},
  icon:{estrela:'Estrela',cometa:'Cometa',escudo:'Escudo'},
  border:{menta:'Menta',violeta:'Violeta',ouro:'Ouro'},
};
export const DEFAULT_PROFILE={background:'namek',icon:'estrela',border:'menta'};
const localParts=new Intl.DateTimeFormat('en-GB',{
  timeZone:DAILY_ZONE,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',
  minute:'2-digit',second:'2-digit',hourCycle:'h23',
});
function localFields(time){
  return Object.fromEntries(localParts.formatToParts(time).filter(p=>p.type!=='literal').map(p=>[p.type,Number(p.value)]));
}
function localNoon(plainDate){
  const desired=plainDate+12*3600000;
  let time=desired;
  for(let attempt=0;attempt<3;attempt++){
    const f=localFields(time);
    const actual=Date.UTC(f.year,f.month-1,f.day,f.hour,f.minute,f.second);
    if(actual===desired)return time;
    time+=desired-actual;
  }
  return time;
}
export function dailyCycle(now=Date.now()){
  const f=localFields(now);
  const today=Date.UTC(f.year,f.month-1,f.day);
  const startDate=today-(f.hour<12?86400000:0);
  return {day:new Date(startDate).toISOString().slice(0,10),nextAt:localNoon(startDate+86400000)};
}

export function rarityLabel(odds){
  const format=new Intl.NumberFormat('pt-BR',{maximumFractionDigits:2});
  for(const [divisor,suffix] of [[1e9,'B'],[1e6,'M'],[1e3,' mil']]){
    if(odds>=divisor)return '1/'+format.format(odds/divisor)+suffix;
  }
  return '1/'+format.format(odds);
}
