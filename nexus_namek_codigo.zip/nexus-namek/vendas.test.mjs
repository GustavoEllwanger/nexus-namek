import test from 'node:test';
import assert from 'node:assert/strict';
import {fresh,advance,makeBattle,applyGameAction,SALE_PRICES,CHARACTERS,advanceWithPresence,challenge,readyAt} from './public/game.js';

function encounter(s,recruit,fallen=[],lost=false){
  const b=makeBattle(s,s.clock+1);
  b.recruit=recruit;
  b.result.winner=lost?1:0;b.result.reason='eliminação';
  b.result.events=fallen.map(i=>({type:'cai',actor:'0:'+i,time:b.result.seconds*1000}));
  s.pending=b;
  return b;
}
test('só vende novas cópias iguais, contabiliza ouro AFK e mantém seriais distintos',()=>{
  const s=fresh(0,3);
  for(const [group,value] of [['enabled',null],['characters','yamcha']])applyGameAction(s,{type:'saleSetting',group,value,checked:true},0);
  applyGameAction(s,{type:'saleTrait',tier:1,name:'Ten',checked:true},0);
  let next=1;
  for(const [shiny,trait,sell] of [[false,null,true],[true,null,false],[true,'Ten',false],[true,'Ten',true]]){
    const count=s.collection.length;
    const b=encounter(s,{id:'yamcha',shiny,trait,odds:200});
    const [e]=advanceWithPresence(s,b.end,null);
    assert.equal(!!e.sold,sell);assert.equal(s.collection.length,count+(sell?0:1));
    if(sell)assert.equal(e.saleGold,SALE_PRICES[CHARACTERS.yamcha.tier-1]);
    if(shiny)assert.equal((e.recruit??e.sold).serial,next++);
  }
  assert.equal(s.awayWindow.sold,2);
  assert.equal(s.awayWindow.gold,s.gold);
  assert.ok(s.team.includes('initial-yamcha'));
  const b=encounter(s,{id:'usopp',shiny:false,trait:null});
  applyGameAction(s,{type:'saleSetting',group:'tiers',value:1,checked:true},s.clock);
  const [first]=advance(s,b.end);assert.ok(first.recruit);
  const repeat=encounter(s,b.recruit);assert.ok(advance(s,repeat.end)[0].sold);
});
test('queda individual só afasta a cópia derrotada, e eliminação bloqueia a equipe por 20 s',()=>{
  const s=fresh(0,18);
  const b=encounter(s,null,[0]);advance(s,b.end);
  const uid=b.team[0].uid;
  assert.equal(readyAt(s,uid),b.end+20000);
  advance(s,s.nextAt);
  assert.equal(s.pending.team.length,3);assert.ok(s.pending.team.every(f=>f.uid!==uid));
  const wipe=s.pending;
  wipe.result.events=wipe.team.map((_,i)=>({time:1000,type:'cai',actor:'0:'+i}));
  wipe.result.winner=1;wipe.result.reason='eliminação';
  advance(s,wipe.end);
  const restored=JSON.parse(JSON.stringify(s));
  restored.finalWins=12;
  assert.equal(challenge(restored,wipe.end+19999),false);
  advance(restored,wipe.end+19999);assert.equal(restored.pending,null);
  advance(restored,wipe.end+20000);assert.equal(restored.pending.team.length,4);
});

test('exceções respeitam raridade do personagem, limite estrito, nome e cópia única',()=>{
  const s=fresh(0,22);
  s.autoSell={enabled:true,tiers:[1,3],characters:[]};
  const capture=(id,trait)=>{
    const battle=encounter(s,{id,trait,shiny:false,odds:150});
    return !!advance(s,battle.end)[0].sold;
  };
  assert.equal(capture('yamcha','Ten'),false);
  assert.equal(capture('yamcha','Ten'),false);
  applyGameAction(s,{type:'saleTrait',tier:1,below:30},0);
  assert.equal(capture('yamcha','Ten'),true);
  assert.equal(capture('tenshinhan','Ten'),false);
  assert.equal(capture('tenshinhan','Ten'),false);
  assert.equal(capture('yamcha','Haki do Rei'),false);
  assert.equal(capture('yamcha','Haki do Rei'),false);
  applyGameAction(s,{type:'saleTrait',tier:1,below:50},0);
  assert.equal(capture('yamcha','Haki do Rei'),false);
  applyGameAction(s,{type:'saleTrait',tier:1,name:'Haki do Rei',checked:true},0);
  assert.equal(capture('yamcha','Haki do Rei'),true);
  applyGameAction(s,{type:'saleTrait',tier:1,name:'Haki do Rei',checked:false},0);
  assert.equal(capture('yamcha','Haki do Rei'),false);
});
