import assert from 'node:assert/strict';
import test from 'node:test';
import { Combate } from './public/engine.js';

const near = (left, right) => assert.ok(Math.abs(left-right)<1e-8, `${left} ≈ ${right}`);
const setup = (a,b,mode) => {
  const fight = new Combate([a,b],{mode});
  const [left,right] = fight.teams;
  return {fight,left,right};
};

test('Accelerator usa até dois reflexos e compartilha a recarga entre reserva e arena',()=>{
  const {fight,left,right} = setup([{}, {kind:'accelerator'}],[{attack:100}]);
  fight.hit(right[0],left[0]);
  assert.equal(right[0].hp,900);
  fight.time=7999;
  fight.hit(right[0],left[0],{damage:1000});
  assert.equal(fight.active(0),left[1]);
  assert.equal(left[1].vector,1);
  fight.time=8000;
  fight.hit(right[0],left[1]);
  fight.time=16000;
  fight.hit(right[0],left[1]);
  assert.equal(left[1].vector,0);
  assert.equal(left[1].hp,900);
  assert.equal(right[0].hp,800);
});

test('um reflexo não gera outro reflexo, inclusive entre dois Accelerators',()=>{
  const {fight,left,right} = setup([{kind:'accelerator'}],[{kind:'accelerator'}]);
  fight.hit(left[0],right[0]);
  assert.equal(left[0].hp,900);
  assert.equal(left[0].vector,2);
  assert.equal(right[0].vector,1);
  assert.equal(fight.log.filter(e=>e.type==='reflete').length,1);
});

test('interceptação acontece antes da esquiva, sem gastar cargas de reflexo',()=>{
  const {fight,left,right} = setup([{}],[{}, {intercept:1, evade:1, kind:'accelerator'}],'equipe');
  fight.hit(left[0],right[0]);
  assert.deepEqual(fight.log.map(x=>x.type),['intercepta','esquiva']);
  assert.equal(right[1].vector,2);
  assert.equal(right[0].hp,1000);
});

test('ataque em área e ataque básico não acionam Controle Vetorial',()=>{
  const {fight,left,right} = setup([{}],[{kind:'accelerator'}]);
  fight.hit(left[0],right[0],{area:true});
  fight.hit(left[0],right[0],{skill:false});
  assert.equal(right[0].vector,2);
  assert.equal(right[0].hp,800);
});

test('retorno do reflexo ainda encontra um escudo e não gera nova reação',()=>{
  const {fight,left,right} = setup([{shield:60,evade:1}],[{kind:'accelerator'}]);
  fight.hit(left[0],right[0]);
  assert.equal(left[0].shield,0);
  assert.equal(left[0].hp,960);
  assert.equal(left[0].evade,1);
});

test('assistências ofensivas causam dano quando o alvo não tem escudo',()=>{
  for (const [kind,damage] of [['beerus',125],['barba-branca',135],['zoro',110],['polnareff',100],['tetsuo',110]]) {
    const {fight,left,right} = setup([{},{}],[{}]);
    assert.equal(fight.use(left[1],right[0],kind,'reserva'),true);
    near(right[0].hp,1000-damage);
  }
});

test('dano extra a escudo multiplica só a absorção e conserva excedente',()=>{
  const {fight,left,right} = setup([{}],[{shield:120}]);
  fight.use(left[0],right[0],'zoro','reserva');
  assert.equal(right[0].shield,0);
  near(right[0].hp,950);
  assert.equal(fight.log.filter(e=>e.type==='escudo rompe').length,1);
});

test('estocadas e bônus de controle respondem ao escudo atual, inclusive quando quebra',()=>{
  const {fight,left,right} = setup([{},{}],[{shield:80}]);
  fight.use(left[0],right[0],'polnareff');
  near(right[0].hp,915);
  left[0].resistedUntil=5000;
  right[0].shield=150;
  fight.use(left[1],right[0],'tetsuo','reserva');
  near(right[0].hp,750);
  assert.equal(right[0].shield,0);
});

test('tremor só adia o ataque quando realmente rompe um escudo',()=>{
  const {fight,left,right} = setup([{}],[{shield:75}]);
  fight.use(left[0],right[0],'barba-branca','reserva');
  fight.use(left[0],right[0],'barba-branca','reserva');
  assert.equal(right[0].nextBasic,4000);
  assert.equal(right[0].hp,730);
});

test('Hakai bloqueia ressurreição, preserva proteção fatal e passa a vez uma só vez',()=>{
  const {fight,left,right} = setup([{magic:1000}],[{revive:1,survive:1},{hp:500}]);
  fight.use(left[0],right[0],'beerus');
  assert.equal(right[0].hp,400);
  assert.equal(fight.use(left[0],right[0],'beerus'),false);
  fight.time=9000;
  fight.use(left[0],right[0],'beerus');
  assert.equal(fight.active(1),right[1]);
  assert.equal(fight.log.filter(e=>e.type==='ressurge').length,0);
  assert.equal(fight.log.filter(e=>e.type==='entra').length,1);
});

test('ressurreição finita e cura fora de hora não trazem o derrotado de volta',()=>{
  const {fight,left,right} = setup([{}],[{revive:1},{}]);
  fight.hit(left[0],right[0],{damage:1500});
  assert.equal(right[0].hp,700);
  assert.equal(fight.active(1),right[0]);
  fight.hit(left[0],right[0],{damage:1500});
  fight.heal(right[0],1000);
  assert.equal(right[0].hp,0);
  assert.equal(fight.active(1),right[1]);
});

test('Kaguya usa duas janelas e cada reforço é consumido por uma habilidade',()=>{
  const {fight,left,right} = setup([{},{}],[{hp:3000}],'equipe');
  assert.equal(fight.use(left[0],right[0],'kaguya'),true);
  fight.hit(right[0],left[0],{skill:false});
  assert.equal(left[0].hp,935);
  fight.hit(left[1],right[0]);
  fight.hit(left[1],right[0]);
  assert.equal(right[0].hp,2770);
  fight.time=11999;
  assert.equal(fight.use(left[0],right[0],'kaguya'),false);
  fight.time=12000;
  assert.equal(fight.use(left[0],right[0],'kaguya'),true);
  fight.time=24000;
  assert.equal(fight.use(left[0],right[0],'kaguya'),false);
});

test('Saitama precisa de ações novas e não ganha uma terceira carga ao trocar de alvo',()=>{
  const {fight,left,right} = setup([{}],[{hp:2000},{hp:2000}]);
  right[0].actions=3;
  assert.equal(fight.use(left[0],right[0],'saitama'),true);
  fight.time=10000;
  assert.equal(fight.use(left[0],right[0],'saitama'),false);
  right[0].actions=6;
  assert.equal(fight.use(left[0],right[0],'saitama'),true);
  fight.hit(left[0],right[0],{damage:3000});
  fight.time=20000;
  right[1].actions=4;
  assert.equal(fight.use(left[0],right[1],'saitama'),false);
});

test('duelo com cura dos dois lados termina aos 60 s e pode empatar',()=>{
  const result = new Combate([[{attack:0},{healer:500}],[{attack:0},{healer:500}]]).run();
  assert.equal(result.seconds,60);
  assert.equal(result.reason,'limite');
  assert.equal(result.winner,null);
});

test('tempo-limite compara porcentagem média, com derrotados contando zero',()=>{
  const {fight,left,right} = setup([{hp:500,attack:0},{hp:500,attack:0}],[{hp:800,attack:0}]);
  left[0].hp=0;
  right[0].hp=600;
  const result = fight.run();
  assert.deepEqual(result.scores,[.5,.75]);
  assert.equal(result.winner,1);
});

test('2.000 lutas variadas terminam e repetem o resultado e o replay',()=>{
  let seed=4704;
  const random = n => {
    seed ^= seed << 13;
    seed ^= seed >>> 17;
    seed ^= seed << 5;
    return (seed >>> 0) % n;
  };
  const kinds = [undefined,'accelerator','kaguya','saitama','polnareff','beerus'];
  const assists = [undefined,'barba-branca','beerus','polnareff','tetsuo','zoro'];
  for(let i=0;i<2000;i++){
    const configs = Array.from({length:2},()=>Array.from({length:1+random(4)},()=>({
      attack:25+random(190), magic:25+random(190), hp:200+random(1900), shield:random(300),
      interval:400+random(5000), survive:random(5)===0?1:0, revive:random(7)===0?1:0,
      healer:random(6)===0?65+random(150):0, kind:kinds[random(kinds.length)], assist:assists[random(assists.length)]
    })));
    const options={mode:i%2?'duelo':'equipe'};
    const first = new Combate(configs,options);
    const r=first.run();
    assert(r.seconds<=60);
    assert(r.scores.every(s=>Number.isFinite(s)&&s>=0&&s<=1));
    assert(first.teams.flat().every(u=>u.hp>=0&&u.hp<=u.maxHp&&u.shield>=0&&u.vector>=0));
    assert.deepEqual(r,new Combate(configs,options).run());
  }
});
