import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {advance,advanceWithPresence,applyGameAction,canSellUnit,CHARACTERS,formationCost,fresh,leaderApplies,makeBattle,SALE_PRICES,unitPower} from './public/game.js';
import {createCommunityStore} from './community-store.mjs';

test('autoFormation seleciona maiores stats, respeita Voto de Nen e escolhe melhor líder',()=>{
  const s=fresh(1000,77);
  s.collection.push(
    {uid:'u-goku',id:'goku',xp:2500,serial:2,shiny:true,trait:'Haki do Rei',odds:50000},
    {uid:'u-vegeta',id:'gohan',xp:1800,serial:1,shiny:false,trait:null,odds:1000},
    {uid:'u-nen',id:'broly',xp:3000,serial:1,shiny:false,trait:'Voto de Nen',nen:true,odds:100000},
    {uid:'u-supp',id:'bulma',xp:900,serial:2,shiny:false,trait:null,odds:20}
  );
  assert.equal(applyGameAction(s,{type:'autoFormation',mode:'power'},1000),true);
  assert.ok(formationCost(s)<=4);
  assert.ok(s.team.includes('u-goku'));
  assert.ok(s.team.includes(s.leader));
  // Verifica que o líder escolhido maximiza o poder total entre os selecionados
  const chosen=s.team.map(uid=>s.collection.find(u=>u.uid===uid));
  const activeTotal=chosen.reduce((sum,u)=>sum+unitPower(u,CHARACTERS[s.collection.find(x=>x.uid===s.leader).id]),0);
  for(const cand of chosen){
    const candTotal=chosen.reduce((sum,u)=>sum+unitPower(u,CHARACTERS[cand.id]),0);
    assert.ok(activeTotal>=candTotal);
  }
  assert.equal(leaderApplies(CHARACTERS.piccolo,CHARACTERS.yamcha),true);
});

test('autoFormation modo balanced e area respeitam funções e afinidade',()=>{
  const s=fresh(1000,88);
  assert.equal(applyGameAction(s,{type:'autoFormation',mode:'balanced'},1000),true);
  assert.equal(s.team.length,4);
  const roles=new Set(s.team.map(uid=>CHARACTERS[s.collection.find(u=>u.uid===uid).id].role));
  assert.equal(roles.size,4);
  assert.equal(applyGameAction(s,{type:'autoFormation',mode:'area'},1000),true);
  assert.equal(s.team.length,4);
  assert.equal(applyGameAction(s,{type:'autoFormation',mode:'invalido'},1000),false);
});

test('presets de formação posicionam de forma espalhada ou protetora',()=>{
  const s=fresh(1000,99);
  assert.equal(applyGameAction(s,{type:'formationPreset',preset:'espalhado'},1000),true);
  const pts=s.team.map(uid=>s.positions[uid]);
  for(let i=0;i<pts.length;i++){
    for(let j=i+1;j<pts.length;j++){
      assert.ok(Math.hypot(pts[i][0]-pts[j][0],pts[i][1]-pts[j][1])>28);
    }
  }
  assert.equal(applyGameAction(s,{type:'formationPreset',preset:'proteger'},1000),true);
  const guard=s.positions['initial-piccolo'];
  for(const uid of s.team){
    if(uid==='initial-piccolo')continue;
    assert.ok(Math.hypot(guard[0]-s.positions[uid][0],guard[1]-s.positions[uid][1])<=30);
  }
  assert.equal(applyGameAction(s,{type:'formationPreset',preset:'desconhecido'},1000),false);
});

test('venda manual protege equipe ativa e última cópia e credita ouro correto',()=>{
  const s=fresh(1000,55);
  assert.equal(canSellUnit(s,'initial-piccolo'),false);
  assert.equal(applyGameAction(s,{type:'sell',uid:'initial-piccolo'},1000),false);
  s.collection.push({uid:'extra-1',id:'yamcha',xp:0,serial:2,shiny:false,trait:null,odds:50});
  assert.equal(canSellUnit(s,'extra-1'),true);
  const before=s.gold;
  assert.equal(applyGameAction(s,{type:'sell',uid:'extra-1'},1000),true);
  assert.equal(s.gold,before+SALE_PRICES[CHARACTERS.yamcha.tier-1]);
  assert.equal(s.collection.some(u=>u.uid==='extra-1'),false);
  // Protege a última unidade da coleção mesmo se removida da equipe
  s.collection=[{uid:'solo',id:'piccolo',xp:0,serial:1,shiny:false,trait:null,odds:null}];
  s.team=[];s.slots=[null,null,null,null];s.leader=null;
  assert.equal(canSellUnit(s,'solo'),false);
  assert.equal(applyGameAction(s,{type:'sell',uid:'solo'},1000),false);
});

test('cache de rankings invalida em novos registros, sync e escrita externa no SQLite',async t=>{
  const folder=await mkdtemp(join(tmpdir(),'nexus-rank-cache-'));
  const file=join(folder,'cache.sqlite');
  let now=10000;
  const store=createCommunityStore(file,{now:()=>now});
  t.after(async()=>{store.close();await rm(folder,{recursive:true,force:true});});
  const a=store.register('Alpha');
  const first=store.rankings();
  const second=store.rankings();
  assert.strictEqual(first,second);
  store.register('Beta');
  const third=store.rankings();
  assert.notStrictEqual(third,second);
  assert.equal(third.power.length,2);
  // Modificação externa direta via outra conexão SQLite deve invalidar o cache via PRAGMA data_version
  const ext=new DatabaseSync(file);
  try{
    const row=ext.prepare('SELECT game FROM players WHERE id=?').get(a.player.id);
    const parsed=JSON.parse(row.game);
    parsed.collection[0].xp=50000;
    ext.prepare('UPDATE players SET game=? WHERE id=?').run(JSON.stringify(parsed),a.player.id);
  }finally{ext.close();}
  const fourth=store.rankings();
  assert.notStrictEqual(fourth,third);
  assert.equal(fourth.power[0].player.id,a.player.id);
});

test('autoFormation considera bônus de liderança na seleção dos titulares (repro Iris/Nami/Goku/Benimaru/Broly)',()=>{
  const s=fresh(1000,101);
  s.collection=[
    {uid:'u-iris',id:'iris',xp:0,serial:1,shiny:false,trait:null,odds:10},
    {uid:'u-nami',id:'nami',xp:0,serial:1,shiny:false,trait:null,odds:10},
    {uid:'u-goku',id:'goku',xp:0,serial:1,shiny:false,trait:null,odds:100},
    {uid:'u-benimaru',id:'benimaru_shinmon',xp:0,serial:1,shiny:false,trait:null,odds:1000},
    {uid:'u-broly',id:'broly',xp:0,serial:1,shiny:false,trait:null,odds:100},
  ];
  s.team=[];s.slots=[null,null,null,null];s.leader=null;
  assert.equal(applyGameAction(s,{type:'autoFormation',mode:'power'},1000),true);
  const byUid=new Map(s.collection.map(u=>[u.uid,u]));
  const leaderCard=CHARACTERS[byUid.get(s.leader).id];
  const chosenPower=s.team.reduce((sum,uid)=>sum+unitPower(byUid.get(uid),leaderCard),0);
  // Compara por força bruta com todos os subconjuntos de 4 unidades e todos os líderes possíveis
  let bruteMax=0;
  for(let skip=0;skip<s.collection.length;skip++){
    const sub=s.collection.filter((_,i)=>i!==skip);
    for(const cand of sub){
      const total=sub.reduce((sum,u)=>sum+unitPower(u,CHARACTERS[cand.id]),0);
      if(total>bruteMax)bruteMax=total;
    }
  }
  assert.equal(chosenPower,bruteMax);
  assert.ok(s.team.includes('u-iris'));
  assert.equal(s.team.includes('u-nami'),false);
});

test('vender reserva durante ou antes do fechamento da janela AFK não apaga recrutamentos do relatório',()=>{
  const s=fresh(1000,202);
  s.collection.push({uid:'old-reserve',id:'yamcha',xp:0,serial:2,shiny:false,trait:null,odds:20});
  assert.equal(s.collection.length,5);
  // Abre a janela AFK com 5 personagens na coleção
  advanceWithPresence(s,1000,1000);
  assert.equal(s.awayWindow.firstRecruit,5);
  // Jogador vende uma reserva antes de recrutar um novo personagem durante a ausência
  assert.equal(applyGameAction(s,{type:'sell',uid:'old-reserve'},1000),true);
  assert.equal(s.collection.length,4);
  // Simula encontro com recrutamento dentro do período de ausência (>10 min)
  const battle=makeBattle(s,1000+11*60000);
  battle.recruit={id:'kuririn',shiny:false,trait:null,odds:50};
  battle.result.winner=0;battle.result.reason='eliminação';battle.result.events=[];
  s.pending=battle;
  s.clock=battle.start;
  advanceWithPresence(s,battle.end,battle.end);
  assert.equal(s.collection.length,5);
  assert.equal(s.awayReports.length,1);
  const [report]=s.awayReports;
  assert.equal(report.recruitUids.length,1);
  assert.equal(report.lastRecruit-report.firstRecruit,1);
  const recruited=s.collection.find(u=>u.uid===report.recruitUids[0]);
  assert.ok(recruited);
  assert.equal(recruited.id,'kuririn');
});

test('relatório AFK hidrata recruitUids de save legado (com e sem novos recrutas e antes de vender)',()=>{
  // Caso 1: save antigo já tinha awayWindow aberto (sem recruitUids) e já havia recrutado o 5º personagem;
  // fecha o período na versão nova sem novos recrutas adicionais.
  const s1=fresh(1000,303);
  s1.paused=true;s1.running=false;
  s1.awayWindow={start:1000,encounters:4,wins:4,gold:80,teamXp:40,reserveXp:0,firstRecruit:4};
  s1.collection.push({uid:'legacy-5th',id:'yamcha',xp:0,serial:2,shiny:false,trait:null,odds:50});
  assert.equal(s1.collection.length,5);
  assert.equal('recruitUids' in s1.awayWindow,false);
  const closeAt=1000+15*60000;
  advanceWithPresence(s1,closeAt,closeAt);
  assert.equal(s1.awayReports.length,1);
  assert.deepEqual(s1.awayReports[0].recruitUids,['legacy-5th']);
  assert.equal(s1.awayReports[0].firstRecruit,4);
  assert.equal(s1.awayReports[0].lastRecruit,5);

  // Caso 2: save antigo já havia recrutado o 5º personagem e recruta o 6º antes de fechar o período.
  const s2=fresh(1000,304);
  s2.awayWindow={start:1000,encounters:4,wins:4,gold:80,teamXp:40,reserveXp:0,firstRecruit:4};
  s2.collection.push({uid:'legacy-5th',id:'yamcha',xp:0,serial:2,shiny:false,trait:null,odds:50});
  delete s2.awayWindow.recruitUids;
  const battle=makeBattle(s2,1000+12*60000);
  battle.recruit={id:'kuririn',shiny:false,trait:null,odds:50};
  battle.result.winner=0;battle.result.reason='eliminação';battle.result.events=[];
  s2.pending=battle;
  s2.clock=battle.start;
  advanceWithPresence(s2,battle.end,battle.end);
  assert.equal(s2.collection.length,6);
  assert.equal(s2.awayReports.length,1);
  assert.deepEqual(s2.awayReports[0].recruitUids,['legacy-5th',s2.collection[5].uid]);

  // Caso 3: vender uma unidade antiga antes de fechar um save legado hidrata recruitUids antes do splice.
  const s3=fresh(1000,305);
  s3.paused=true;s3.running=false;
  s3.collection.push(
    {uid:'pre-window-reserve',id:'bulma',xp:0,serial:2,shiny:false,trait:null,odds:20},
    {uid:'legacy-recruited',id:'gohan',xp:0,serial:1,shiny:false,trait:null,odds:100}
  );
  s3.awayWindow={start:1000,encounters:2,wins:2,gold:40,teamXp:20,reserveXp:0,firstRecruit:5};
  s3.awayReports=[{start:0,end:900,encounters:1,wins:1,gold:10,teamXp:10,reserveXp:0,firstRecruit:4,lastRecruit:5}];
  assert.equal(applyGameAction(s3,{type:'sell',uid:'pre-window-reserve'},1000),true);
  assert.deepEqual(s3.awayWindow.recruitUids,['legacy-recruited']);
  assert.equal(s3.awayWindow.firstRecruit,4);
  assert.deepEqual(s3.awayReports[0].recruitUids,['pre-window-reserve']);
  assert.equal(s3.awayReports[0].firstRecruit,4);
  assert.equal(s3.awayReports[0].lastRecruit,4);
  advanceWithPresence(s3,closeAt,closeAt);
  assert.deepEqual(s3.awayReports[1].recruitUids,['legacy-recruited']);
});

test('falha de armazenamento (QuotaExceededError) preserva aviso de erro e bloqueia confirmações falsas em app.js',()=>{
  const script=`
import assert from 'node:assert/strict';
import {fresh,makeBattle} from './public/game.js';
import {saveKey} from './public/save.js';

const now=Date.now();
const initial=fresh(now-5000,404);
initial.paused=true;initial.running=false;
initial.collection.push(
  {uid:'extra-1',id:'yamcha',xp:0,serial:2,shiny:false,trait:null,odds:20},
  {uid:'extra-2',id:'kuririn',xp:0,serial:2,shiny:false,trait:null,odds:20},
  {uid:'extra-3',id:'bulma',xp:0,serial:2,shiny:false,trait:null,odds:20}
);
// Luta pendente com recrutamento que será concluída logo na primeira transação sob QuotaExceededError
const pendingBattle=makeBattle(initial,now-4000);
pendingBattle.recruit={id:'yamcha',shiny:false,trait:null,odds:20};
pendingBattle.result.winner=0;pendingBattle.result.reason='eliminação';pendingBattle.result.events=[];
pendingBattle.end=now-1000;
initial.pending=pendingBattle;

const backing=new Map([[saveKey,JSON.stringify(initial)]]);
let failQuota=true;
globalThis.localStorage={
  getItem:k=>backing.get(k)??null,
  setItem:(k,v)=>{
    if(failQuota){const err=new Error('Quota exceeded');err.name='QuotaExceededError';throw err;}
    backing.set(k,String(v));
  },
  removeItem:k=>backing.delete(k)
};

const elements=new Map();
function makeEl(){
  return {
    textContent:'',innerHTML:'',hidden:false,disabled:false,open:false,
    dataset:{},style:{},
    classList:{toggle(){},add(){},remove(){}},
    addEventListener(){},removeEventListener(){},
    querySelector(){return null;},querySelectorAll(){return [];},
    setAttribute(){},removeAttribute(){},
    replaceChildren(){},append(){},click(){},focus(){},close(){this.open=false;},showModal(){this.open=true;}
  };
}
const listeners=new Map();
globalThis.document={
  hidden:false,
  hasFocus:()=>true,
  documentElement:{dataset:{}},
  querySelector(sel){
    if(sel==='#community-panel'||sel==='#player-profile'||sel.startsWith('#panel '))return null;
    if(!elements.has(sel))elements.set(sel,makeEl());
    return elements.get(sel);
  },
  querySelectorAll(){return [];},
  createElement(){return makeEl();},
  addEventListener(type,fn){(listeners.get(type)??listeners.set(type,[]).get(type)).push(fn);}
};
globalThis.location={hash:'#colecao',protocol:'http:'};
globalThis.history={replaceState(_s,_t,url){globalThis.location.hash=url;}};
globalThis.addEventListener=()=>{};
globalThis.requestAnimationFrame=()=>{};
globalThis.setInterval=()=>0;
globalThis.confirm=()=>true;
Object.defineProperty(globalThis,'navigator',{value:{},configurable:true});

const clickButton=btn=>{
  const target={closest:sel=>sel==='button'?btn:null};
  for(const fn of listeners.get('click')??[])fn({target,detail:1});
};
const flush=()=>new Promise(r=>setTimeout(r,25));

await import('./public/app.js');
await flush();

const notice=document.querySelector('#notice');
const saveError='Não foi possível salvar neste navegador. Exporte seu progresso em Configurações.';

// 1. Luta encerrada com recruta sob QuotaExceededError: receive() não sobrescreve o aviso de erro.
assert.equal(notice.textContent,saveError);
assert.equal(notice.hidden,false);

// 2. Venda com QuotaExceededError: aviso de falha prevalece e confirmação de venda não é emitida.
clickButton({id:'',dataset:{sell:'extra-1'}});
await flush();
assert.equal(notice.textContent,saveError);
assert.equal(notice.hidden,false);

// 3. Auto-formação com QuotaExceededError: não sobrescreve com "Formação atualizada."
clickButton({id:'auto-form-btn',dataset:{}});
await flush();
assert.equal(notice.textContent,saveError);

// 4. Equipar com QuotaExceededError: não troca de aba como confirmado e mantém aviso de erro.
assert.equal(location.hash,'#colecao');
clickButton({id:'',dataset:{equip:'extra-2',slot:'0',occupant:'initial-piccolo'}});
await flush();
assert.equal(location.hash,'#colecao');
assert.equal(notice.textContent,saveError);

// 5. Quando o armazenamento volta a funcionar, venda e auto-formação emitem confirmação normalmente.
failQuota=false;
clickButton({id:'',dataset:{sell:'extra-3'}});
await flush();
assert.equal(notice.textContent,'Bulma #002 vendido por +8 ouro.');
clickButton({id:'auto-form-btn',dataset:{}});
await flush();
assert.equal(notice.textContent,'Formação atualizada.');
`;
  const run=spawnSync(process.execPath,['--input-type=module','-e',script],{
    cwd:new URL('.',import.meta.url),
    encoding:'utf8'
  });
  assert.equal(run.status,0,`app.js storage failure test failed:\n${run.stderr}\n${run.stdout}`);
});

test('resume durante luta de chefe retorna true quando estava pausado e false na segunda chamada',()=>{
  const s=fresh(1000,505);
  s.finalWins=12;
  assert.equal(applyGameAction(s,{type:'boss'},1000),true);
  assert.equal(s.pending.boss,true);
  assert.equal(applyGameAction(s,{type:'pause'},1000),true);
  assert.equal(s.paused,true);
  assert.equal(s.running,false);
  // Retomar durante luta de chefe deve reportar mudança (true) e limpar paused
  assert.equal(applyGameAction(s,{type:'resume'},1000),true);
  assert.equal(s.paused,false);
  // Chamar resume novamente enquanto já retomado durante o chefe é no-op
  assert.equal(applyGameAction(s,{type:'resume'},1000),false);
  // Ao concluir o chefe, a exploração volta a rodar automaticamente
  advance(s,s.pending.end);
  assert.equal(s.running,true);
});

test('autoFormation modo balanced escolhe 4 funções distintas mesmo com 2+ unidades Voto de Nen mais fortes',()=>{
  const s=fresh(1000,606);
  s.collection=[
    {uid:'g1',id:'piccolo',xp:0,serial:1,shiny:false,trait:null,odds:null},
    {uid:'c1',id:'yamcha',xp:0,serial:1,shiny:false,trait:null,odds:null},
    {uid:'c-nen',id:'goku',xp:5000,serial:1,shiny:true,trait:'Voto de Nen',nen:true,odds:50000},
    {uid:'m1',id:'kuririn',xp:0,serial:1,shiny:false,trait:null,odds:null},
    {uid:'m-nen',id:'gojo',xp:5000,serial:1,shiny:true,trait:'Voto de Nen',nen:true,odds:50000},
    {uid:'s1',id:'bulma',xp:0,serial:1,shiny:false,trait:null,odds:null},
  ];
  s.team=[];s.slots=[null,null,null,null];s.leader=null;
  assert.equal(applyGameAction(s,{type:'autoFormation',mode:'balanced'},1000),true);
  assert.equal(s.team.length,4);
  assert.ok(formationCost(s)<=4);
  const roles=new Set(s.team.map(uid=>CHARACTERS[s.collection.find(u=>u.uid===uid).id].role));
  assert.equal(roles.size,4);
  assert.equal(s.team.includes('c-nen'),false);
  assert.equal(s.team.includes('m-nen'),false);

  // Quando não existe alternativa cost=1 para completar mais funções, permite usar a unidade nen=true
  s.collection=[
    {uid:'g1',id:'piccolo',xp:0,serial:1,shiny:false,trait:null,odds:null},
    {uid:'c-nen',id:'goku',xp:5000,serial:1,shiny:true,trait:'Voto de Nen',nen:true,odds:50000},
    {uid:'s1',id:'bulma',xp:0,serial:1,shiny:false,trait:null,odds:null},
  ];
  s.team=[];s.slots=[null,null,null,null];s.leader=null;
  assert.equal(applyGameAction(s,{type:'autoFormation',mode:'balanced'},1000),true);
  assert.equal(s.team.length,3);
  assert.equal(formationCost(s),4);
  assert.ok(s.team.includes('c-nen'));
});

test('app.js sincroniza pausa em save legado (paused undefined) e preserva #col-search com escape de & e "',()=>{
  const script=`
import assert from 'node:assert/strict';
import {fresh} from './public/game.js';
import {saveKey} from './public/save.js';

const now=Date.now();
const initial=fresh(now,707);
delete initial.paused;
initial.running=false;
initial.collection.push({uid:'extra-1',id:'yamcha',xp:0,serial:2,shiny:false,trait:null,odds:20});

const backing=new Map([[saveKey,JSON.stringify(initial)]]);
globalThis.localStorage={
  getItem:k=>backing.get(k)??null,
  setItem:(k,v)=>backing.set(k,String(v)),
  removeItem:k=>backing.delete(k)
};

const elements=new Map();
let panelWrites=0;
let panelHasCollection=false;
const swapTarget={innerHTML:'',value:''};
function makeEl(sel){
  let html='';
  const el={
    textContent:'',hidden:false,disabled:false,open:false,
    dataset:{},style:{},
    classList:{toggle(){},add(){},remove(){}},
    addEventListener(){},removeEventListener(){},
    querySelector(q){
      if(sel==='#panel'&&q==='#collection-list')return panelHasCollection?elements.get('#collection-list'):null;
      if(sel==='#panel'&&q==='#swap-target')return panelHasCollection?swapTarget:null;
      return null;
    },
    querySelectorAll(){return [];},
    setAttribute(){},removeAttribute(){},
    replaceChildren(){},append(){},click(){},focus(){},close(){this.open=false;},showModal(){this.open=true;},
    get innerHTML(){return html;},
    set innerHTML(v){
      html=v;
      if(sel==='#panel'){
        panelWrites++;
        panelHasCollection=v.includes('id="collection-list"');
      }
    }
  };
  return el;
}
const listeners=new Map();
globalThis.document={
  hidden:false,
  hasFocus:()=>true,
  documentElement:{dataset:{}},
  querySelector(sel){
    if(sel==='#community-panel'||sel==='#player-profile'||sel.startsWith('#panel '))return null;
    if(!elements.has(sel))elements.set(sel,makeEl(sel));
    return elements.get(sel);
  },
  querySelectorAll(){return [];},
  createElement(){return makeEl('');},
  addEventListener(type,fn){(listeners.get(type)??listeners.set(type,[]).get(type)).push(fn);}
};
globalThis.location={hash:'#exploracao',protocol:'http:'};
globalThis.history={replaceState(_s,_t,url){globalThis.location.hash=url;}};
globalThis.addEventListener=()=>{};
globalThis.requestAnimationFrame=()=>{};
globalThis.setInterval=()=>0;
globalThis.confirm=()=>true;
Object.defineProperty(globalThis,'navigator',{value:{},configurable:true});

const clickButton=btn=>{
  const target={closest:sel=>sel==='button'?btn:null};
  for(const fn of listeners.get('click')??[])fn({target,detail:1});
};
const fireInput=(id,value)=>{
  for(const fn of listeners.get('input')??[])fn({target:{id,value}});
};
const flush=()=>new Promise(r=>setTimeout(r,25));

await import('./public/app.js');
await flush();

// 1. Save legado com paused === undefined e running === false deve exibir "Explorar" e modo "resume"
const toggle=document.querySelector('#explore-toggle');
assert.equal(toggle.textContent,'Explorar');
assert.equal(toggle.dataset.mode,'resume');

// Aba configurações deve mostrar #auto-play desmarcado
clickButton({id:'',dataset:{tab:'configuracoes'}});
assert.equal(document.querySelector('#panel').innerHTML.includes('id="auto-play" checked'),false);

// Clicar em #explore-toggle deve disparar resume e ativar exploração
clickButton({id:'',dataset:{tab:'exploracao'}});
clickButton({id:'explore-toggle',dataset:{}});
await flush();
const savedAfterResume=JSON.parse(backing.get(saveKey));
assert.equal(savedAfterResume.paused,false);
assert.equal(savedAfterResume.running,true);

// 2. Aba coleção preserva #col-search em re-renderizações e escapa & antes de "
clickButton({id:'',dataset:{tab:'colecao'}});
const writesAfterMount=panelWrites;
fireInput('col-search','&quot;"piccolo');

// Vender reserva dispara renderPanel() na aba coleção; panel.innerHTML NÃO deve ser recriado
clickButton({id:'',dataset:{sell:'extra-1'}});
await flush();
assert.equal(panelWrites,writesAfterMount);
assert.ok(swapTarget.innerHTML.includes('Piccolo'));

// Trocar de aba e voltar para coleção remonta o input escapando & antes de "
clickButton({id:'',dataset:{tab:'formacao'}});
clickButton({id:'',dataset:{tab:'colecao'}});
assert.ok(document.querySelector('#panel').innerHTML.includes('value="&amp;quot;&quot;piccolo"'));
`;
  const run=spawnSync(process.execPath,['--input-type=module','-e',script],{
    cwd:new URL('.',import.meta.url),
    encoding:'utf8'
  });
  assert.equal(run.status,0,`app.js pause/search test failed:\n${run.stderr}\n${run.stdout}`);
});
