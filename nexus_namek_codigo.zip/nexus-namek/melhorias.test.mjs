import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {advanceWithPresence,applyGameAction,canSellUnit,CHARACTERS,formationCost,fresh,leaderApplies,makeBattle,SALE_PRICES,unitPower} from './public/game.js';
import {createCommunityStore} from './community-store.mjs';

test('autoFormation seleciona maiores stats, respeita Voto de Nen e escolhe melhor líder',()=>{
  const s=fresh(1000,77);
  s.collection.push(
    {uid:'u-goku',id:'goku',xp:2500,serial:2,shiny:true,trait:'Haki do Rei',odds:50000},
    {uid:'u-vegeta',id:'gohan',xp:1800,serial:1,shiny:false,trait:null,odds:1000},
    {uid:'u-nen',id:'broly',xp:3000,serial:1,shiny:false,trait:'Voto de Nen',nen:true,odds:100000},
    {uid:'u-supp',id:'bulma',xp:900,serial:2,shiny:false,trait:null,odds:20}
  );
  assert.equal(applyGameAction(s,{type:'autoFormation',mode:'power'},1000),true);
  assert.ok(formationCost(s)<=4);
  assert.ok(s.team.includes('u-goku'));
  assert.ok(s.team.includes(s.leader));
  // Verifica que o líder escolhido maximiza o poder total entre os selecionados
  const chosen=s.team.map(uid=>s.collection.find(u=>u.uid===uid));
  const activeTotal=chosen.reduce((sum,u)=>sum+unitPower(u,CHARACTERS[s.collection.find(x=>x.uid===s.leader).id]),0);
  for(const cand of chosen){
    const candTotal=chosen.reduce((sum,u)=>sum+unitPower(u,CHARACTERS[cand.id]),0);
    assert.ok(activeTotal>=candTotal);
  }
  assert.equal(leaderApplies(CHARACTERS.piccolo,CHARACTERS.yamcha),true);
});

test('autoFormation modo balanced e area respeitam funções e afinidade',()=>{
  const s=fresh(1000,88);
  assert.equal(applyGameAction(s,{type:'autoFormation',mode:'balanced'},1000),true);
  assert.equal(s.team.length,4);
  const roles=new Set(s.team.map(uid=>CHARACTERS[s.collection.find(u=>u.uid===uid).id].role));
  assert.equal(roles.size,4);
  assert.equal(applyGameAction(s,{type:'autoFormation',mode:'area'},1000),true);
  assert.equal(s.team.length,4);
  assert.equal(applyGameAction(s,{type:'autoFormation',mode:'invalido'},1000),false);
});

test('presets de formação posicionam de forma espalhada ou protetora',()=>{
  const s=fresh(1000,99);
  assert.equal(applyGameAction(s,{type:'formationPreset',preset:'espalhado'},1000),true);
  const pts=s.team.map(uid=>s.positions[uid]);
  for(let i=0;i<pts.length;i++){
    for(let j=i+1;j<pts.length;j++){
      assert.ok(Math.hypot(pts[i][0]-pts[j][0],pts[i][1]-pts[j][1])>28);
    }
  }
  assert.equal(applyGameAction(s,{type:'formationPreset',preset:'proteger'},1000),true);
  const guard=s.positions['initial-piccolo'];
  for(const uid of s.team){
    if(uid==='initial-piccolo')continue;
    assert.ok(Math.hypot(guard[0]-s.positions[uid][0],guard[1]-s.positions[uid][1])<=30);
  }
  assert.equal(applyGameAction(s,{type:'formationPreset',preset:'desconhecido'},1000),false);
});

test('venda manual protege equipe ativa e última cópia e credita ouro correto',()=>{
  const s=fresh(1000,55);
  assert.equal(canSellUnit(s,'initial-piccolo'),false);
  assert.equal(applyGameAction(s,{type:'sell',uid:'initial-piccolo'},1000),false);
  s.collection.push({uid:'extra-1',id:'yamcha',xp:0,serial:2,shiny:false,trait:null,odds:50});
  assert.equal(canSellUnit(s,'extra-1'),true);
  const before=s.gold;
  assert.equal(applyGameAction(s,{type:'sell',uid:'extra-1'},1000),true);
  assert.equal(s.gold,before+SALE_PRICES[CHARACTERS.yamcha.tier-1]);
  assert.equal(s.collection.some(u=>u.uid==='extra-1'),false);
  // Protege a última unidade da coleção mesmo se removida da equipe
  s.collection=[{uid:'solo',id:'piccolo',xp:0,serial:1,shiny:false,trait:null,odds:null}];
  s.team=[];s.slots=[null,null,null,null];s.leader=null;
  assert.equal(canSellUnit(s,'solo'),false);
  assert.equal(applyGameAction(s,{type:'sell',uid:'solo'},1000),false);
});

test('cache de rankings invalida em novos registros, sync e escrita externa no SQLite',async t=>{
  const folder=await mkdtemp(join(tmpdir(),'nexus-rank-cache-'));
  const file=join(folder,'cache.sqlite');
  let now=10000;
  const store=createCommunityStore(file,{now:()=>now});
  t.after(async()=>{store.close();await rm(folder,{recursive:true,force:true});});
  const a=store.register('Alpha');
  const first=store.rankings();
  const second=store.rankings();
  assert.strictEqual(first,second);
  store.register('Beta');
  const third=store.rankings();
  assert.notStrictEqual(third,second);
  assert.equal(third.power.length,2);
  // Modificação externa direta via outra conexão SQLite deve invalidar o cache via PRAGMA data_version
  const ext=new DatabaseSync(file);
  try{
    const row=ext.prepare('SELECT game FROM players WHERE id=?').get(a.player.id);
    const parsed=JSON.parse(row.game);
    parsed.collection[0].xp=50000;
    ext.prepare('UPDATE players SET game=? WHERE id=?').run(JSON.stringify(parsed),a.player.id);
  }finally{ext.close();}
  const fourth=store.rankings();
  assert.notStrictEqual(fourth,third);
  assert.equal(fourth.power[0].player.id,a.player.id);
});

test('autoFormation considera bônus de liderança na seleção dos titulares (repro Iris/Nami/Goku/Benimaru/Broly)',()=>{
  const s=fresh(1000,101);
  s.collection=[
    {uid:'u-iris',id:'iris',xp:0,serial:1,shiny:false,trait:null,odds:10},
    {uid:'u-nami',id:'nami',xp:0,serial:1,shiny:false,trait:null,odds:10},
    {uid:'u-goku',id:'goku',xp:0,serial:1,shiny:false,trait:null,odds:100},
    {uid:'u-benimaru',id:'benimaru_shinmon',xp:0,serial:1,shiny:false,trait:null,odds:1000},
    {uid:'u-broly',id:'broly',xp:0,serial:1,shiny:false,trait:null,odds:100},
  ];
  s.team=[];s.slots=[null,null,null,null];s.leader=null;
  assert.equal(applyGameAction(s,{type:'autoFormation',mode:'power'},1000),true);
  const byUid=new Map(s.collection.map(u=>[u.uid,u]));
  const leaderCard=CHARACTERS[byUid.get(s.leader).id];
  const chosenPower=s.team.reduce((sum,uid)=>sum+unitPower(byUid.get(uid),leaderCard),0);
  // Compara por força bruta com todos os subconjuntos de 4 unidades e todos os líderes possíveis
  let bruteMax=0;
  for(let skip=0;skip<s.collection.length;skip++){
    const sub=s.collection.filter((_,i)=>i!==skip);
    for(const cand of sub){
      const total=sub.reduce((sum,u)=>sum+unitPower(u,CHARACTERS[cand.id]),0);
      if(total>bruteMax)bruteMax=total;
    }
  }
  assert.equal(chosenPower,bruteMax);
  assert.ok(s.team.includes('u-iris'));
  assert.equal(s.team.includes('u-nami'),false);
});

test('vender reserva durante ou antes do fechamento da janela AFK não apaga recrutamentos do relatório',()=>{
  const s=fresh(1000,202);
  s.collection.push({uid:'old-reserve',id:'yamcha',xp:0,serial:2,shiny:false,trait:null,odds:20});
  assert.equal(s.collection.length,5);
  // Abre a janela AFK com 5 personagens na coleção
  advanceWithPresence(s,1000,1000);
  assert.equal(s.awayWindow.firstRecruit,5);
  // Jogador vende uma reserva antes de recrutar um novo personagem durante a ausência
  assert.equal(applyGameAction(s,{type:'sell',uid:'old-reserve'},1000),true);
  assert.equal(s.collection.length,4);
  // Simula encontro com recrutamento dentro do período de ausência (>10 min)
  const battle=makeBattle(s,1000+11*60000);
  battle.recruit={id:'kuririn',shiny:false,trait:null,odds:50};
  battle.result.winner=0;battle.result.reason='eliminação';battle.result.events=[];
  s.pending=battle;
  s.clock=battle.start;
  advanceWithPresence(s,battle.end,battle.end);
  assert.equal(s.collection.length,5);
  assert.equal(s.awayReports.length,1);
  const [report]=s.awayReports;
  assert.equal(report.recruitUids.length,1);
  assert.equal(report.lastRecruit-report.firstRecruit,1);
  const recruited=s.collection.find(u=>u.uid===report.recruitUids[0]);
  assert.ok(recruited);
  assert.equal(recruited.id,'kuririn');
});
