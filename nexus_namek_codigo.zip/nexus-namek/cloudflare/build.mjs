import {readFile,writeFile} from 'node:fs/promises';
const root=new URL('../',import.meta.url);
const read=file=>readFile(new URL(file,root),'utf8');
function moduleBody(name,src,imports=''){
  const exports=[...src.matchAll(/^export (?:const|class|function) (\w+)/gm)].map(m=>m[1]);
  const body=src.replace(/^import .*;\n/gm,'').replace(/^export /gm,'');
  return `const ${name}=(()=>{\n${imports}\n${body}\nreturn {${exports.join(',')}};\n})();\n`;
}
const worker=(await read('cloudflare/community.mjs')).replace("from '../serials.mjs'","=serials").replace("from '../public/game.js'","=game").replace("from '../public/community-rules.js'","=communityRules").replace(/^import /gm,'const ');
const source=moduleBody('serials',await read('serials.mjs'))+moduleBody('engine',await read('public/engine.js'))+
  moduleBody('game',await read('public/game.js'),'const {Combate,affinity}=engine;')+
  moduleBody('communityRules',await read('public/community-rules.js'))+worker;
await writeFile(new URL('public/_worker.js',root),source);
await writeFile(new URL('public/_routes.json',root),JSON.stringify({version:1,include:['/api/*'],exclude:[]},null,2)+'\n');
