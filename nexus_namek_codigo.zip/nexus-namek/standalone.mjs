import {readFile,writeFile,readdir} from 'node:fs/promises';

const root=new URL('./public/',import.meta.url);
const read=async file=>readFile(new URL(file,root),'utf8');
const uri=async (file,mime)=>`data:${mime};base64,${(await readFile(new URL(file,root))).toString('base64')}`;
const exportsOf=source=>[...source.matchAll(/^export (?:function|class|const) (\w+)/gm)].map(m=>m[1]);
const strip=source=>source.replace(/^import .*;\n/gm,'').replace(/^export /gm,'');
const moduleBody=(name,source,imports='')=>`const ${name} = (()=>{\n${imports}\n${strip(source)}\nreturn {${exportsOf(source).join(',')}};\n})();`;
const sprites=Object.fromEntries(await Promise.all((await readdir(new URL('art/',root))).filter(f=>f.endsWith('.png')).map(async f=>[f.slice(0,-4),await uri(`art/${f}`,'image/png')])));
let css=(await read('style.css')).replaceAll('art/namek.webp',await uri('art/namek.webp','image/webp'));
for(const file of await readdir(new URL('art/worlds/',root))){
  const path=`art/worlds/${file}`;
  css=css.replaceAll(path,await uri(path,'image/webp'));
}
const engine=await read('engine.js'), game=await read('game.js');
const app=strip(await read('app.js')).replace('const spriteURL = name => `art/${name}.png`;',`const sprites = ${JSON.stringify(sprites)}; const spriteURL = name => sprites[name];`);
const communityRules=await read('community-rules.js'), community=await read('community.js');
const duelSource=await read('duel.js');
const script=moduleBody('engine',engine)+'\n'+moduleBody('duelModule',duelSource,'const {Combate}=engine;')+'\nconst {collisionBonus,collisionPower,createDuel,stepDuel}=duelModule;\n'+'\n'+moduleBody('game',game,'const {Combate,affinity}=engine;')+`\nconst {${exportsOf(game).join(',')}}=game;\n`+moduleBody('communityRules',communityRules)+'\n'+moduleBody('communityModule',community,'const {CHARACTERS,COLORS,spriteFor}=game; const {DAILY_ZONE,GIFT_GOLD,PROFILE_OPTIONS,PROFILE_WORLDS,AVATAR_SIZE,rarityLabel}=communityRules;')+moduleBody('saveModule',await read('save.js'))+'\nconst {isUnreadableCampaign,saveKey,readCampaign,writeCampaign,packCampaign,unpackCampaign}=saveModule; const {affinity}=engine; const {createCommunity}=communityModule;\n'+app;
const template=await read('index.html');
const result=template.replace(/<link rel="manifest"[^>]+>/,'')
  .replace('icons/icon-192.png',await uri('icons/icon-192.png','image/png'))
  .replace('<link rel="stylesheet" href="style.css">',()=>`<style>${css}</style>`)
  .replace('<script type="module" src="app.js"></script>',()=>`<script type="module">${script}</script>`);
const path=process.argv[2]??new URL('./jogar.html',import.meta.url);
await writeFile(path,result);
