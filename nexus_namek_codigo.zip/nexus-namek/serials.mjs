// Reserve the old per-account numbering ranges once, including gaps left by sales.
export function serialSchema(players,hasRanks){
  const kind="json_extract(u.value,'$.id') || CASE WHEN json_extract(u.value,'$.shiny') THEN '-shiny' ELSE '' END";
  const base=(value)=>`coalesce((SELECT offset FROM nexus_legacy_ranges WHERE owner=p.id AND kind=json_extract(${value},'$.id') || CASE WHEN json_extract(${value},'$.shiny') THEN '-shiny' ELSE '' END),0)`;
  const mapped=(value)=>`json_set(${value},'$.serial',json_extract(${value},'$.serial')+${base(value)})`;
  const array=(source)=>`(SELECT json_group_array(json(${mapped('u.value')})) FROM json_each(${source}) u)`;
  let entry='u.value';
  for(const field of ['recruit','sold']){
    const obj=`json_extract(u.value,'$.${field}')`;
    entry=`json_set(${entry},'$.${field}',json(CASE WHEN json_type(u.value,'$.${field}')='object' THEN ${mapped(obj)} ELSE NULL END))`;
  }
  return [
    'CREATE TABLE IF NOT EXISTS nexus_serials(id INTEGER PRIMARY KEY, revision INTEGER NOT NULL, counts TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS nexus_legacy_ranges(owner TEXT,kind TEXT,offset INTEGER,amount INTEGER,PRIMARY KEY(owner,kind))',
    `INSERT INTO nexus_legacy_ranges
     WITH source AS (
       SELECT p.id owner,${kind} kind,json_extract(u.value,'$.serial') n,json_extract(p.game,'$.created') created FROM ${players} p,json_each(p.game,'$.collection') u WHERE NOT EXISTS(SELECT 1 FROM nexus_serials)
       UNION ALL SELECT p.id,u.key,u.value,json_extract(p.game,'$.created') FROM ${players} p,json_each(p.game,'$.serials') u WHERE NOT EXISTS(SELECT 1 FROM nexus_serials)
     ), limits AS (SELECT owner,kind,max(n) amount,created FROM source GROUP BY owner,kind)
     SELECT owner,kind,coalesce(sum(amount) OVER(PARTITION BY kind ORDER BY created,owner ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0),amount FROM limits`,
    `UPDATE ${players} AS p SET game=json_set(game,'$.collection',json(${array("p.game,'$.collection'")}),'$.log',json((SELECT json_group_array(json(${entry})) FROM json_each(p.game,'$.log') u)))${hasRanks?`,top_units=${array('p.top_units')},rare_units=${array('p.rare_units')}`:''} WHERE NOT EXISTS(SELECT 1 FROM nexus_serials)`,
    "INSERT OR IGNORE INTO nexus_serials SELECT 1,0,json_group_object(kind,n) FROM (SELECT kind,sum(amount) n FROM nexus_legacy_ranges GROUP BY kind)",
    ...['INSERT','UPDATE OF game'].map((event,i)=>`CREATE TRIGGER IF NOT EXISTS nexus_issue_${i} AFTER ${event} ON ${players}
      WHEN json_extract(NEW.game,'$.issuance.revision')=(SELECT revision+1 FROM nexus_serials WHERE id=1)
      BEGIN UPDATE nexus_serials SET revision=revision+1,counts=json_patch(counts,json_extract(NEW.game,'$.issuance.counts')) WHERE id=1; END`)
  ];
}
export function issueSerials(state,units,counter){
  delete state.issuance;
  if(!units.length)return;
  const previous=JSON.parse(counter.counts),counts={};
  for(const unit of units){
    const key=unit.id+(unit.shiny?'-shiny':'');
    unit.serial=counts[key]=(counts[key]??previous[key]??0)+1;
  }
  state.issuance={revision:counter.revision+1,counts};
}
