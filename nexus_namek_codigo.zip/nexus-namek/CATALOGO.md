# Catálogo do Nexus

Dados da build incluída, extraídos de public/game.js. Os nomes dos sprites correspondem a arquivos em public/art/.

## Personagens

| Personagem | ID | Universo | Raridade | Cor | Função | Liderança | Normal | Shiny |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Accelerator | accelerator | Toaru | Transcendente | Branco | Guardião | Resistência dos Brancos +22% | ap-accelerator.png | ap-accelerator-shiny.png |
| Android 17 | android17 | Dragon Ball | Divina | Verde | Guardião | Defesa dos Verdes +15% | ap-android-17-torneio-do-poder.png | ap-android-17-torneio-do-poder-shiny.png |
| Arthur Boyle | arthur | Fire Force | Épica | Azul | Combatente | Ataque dos Azuis +12% | ap-arthur-boyle.png | ap-arthur-boyle-shiny.png |
| Beerus | beerus | Dragon Ball | Transcendente | Roxo | Mágico | Magia de Mágicos +22% | ap-beerus.png | ap-beerus-shiny.png |
| Benimaru Shinmon | benimaru_shinmon | Fire Force | Secreta | Vermelho | Combatente | Ataque dos Vermelhos +18% | ap-benimaru-shinmon.png | ap-benimaru-shinmon-shiny.png |
| Broly · Super | broly | Dragon Ball | Secreta | Verde | Combatente | Ataque de Combatentes +18% | ap-broly-super.png | ap-broly-super-shiny.png |
| Bulma | bulma | Dragon Ball | Comum | Azul | Suporte | PV dos Azuis +8% | ap-bulma.png | ap-bulma-shiny.png |
| Coyote Starrk | starrk | Bleach | Divina | Azul | Mágico | Magia dos Azuis +15% | ap-coyote-starrk.png | ap-coyote-starrk-shiny.png |
| Freeza · Forma Final | freeza | Dragon Ball | Mítica | Roxo | Mágico | Magia dos Roxos +15% | ap-freeza-forma-final.png | ap-freeza-forma-final-shiny.png |
| Gohan · Namek | gohan | Dragon Ball | Épica | Amarelo | Combatente | Ataque dos Amarelos +10% | ap-gohan-namek.png | ap-gohan-namek-shiny.png |
| Gojo | gojo | Jujutsu Kaisen | Transcendente | Azul | Mágico | Magia dos Azuis +22% | ap-gojo.png | ap-gojo-shiny.png |
| Goku · Instinto Superior | goku | Dragon Ball | Transcendente | Branco | Combatente | Ataque de Dragon Ball +22% | ap-goku-instinto-superior.png | ap-goku-instinto-superior-shiny.png |
| Iris | iris | Fire Force | Incomum | Branco | Suporte | PV dos Brancos +10% | ap-iris.png | ap-iris-shiny.png |
| Kisuke Urahara | urahara | Bleach | Divina | Verde | Suporte | PV dos Verdes +15% | ap-kisuke-urahara.png | ap-kisuke-urahara-shiny.png |
| Kuririn | kuririn | Dragon Ball | Incomum | Amarelo | Mágico | Magia dos Amarelos +10% | ap-kuririn.png | ap-kuririn-shiny.png |
| Luminous Valentine | luminous | Tensei Shitara Slime Datta Ken | Secreta | Rosa | Suporte | PV dos Rosas +18% | ap-luminous-valentine.png | ap-luminous-valentine-shiny.png |
| Maki Oze | maki_oze | Fire Force | Rara | Laranja | Guardião | PV dos Laranjas +10% | ap-maki-oze.png | ap-maki-oze-shiny.png |
| Mayuri Kurotsuchi | mayuri | Bleach | Mítica | Roxo | Mágico | Magia dos Roxos +15% | ap-mayuri-kurotsuchi.png | ap-mayuri-kurotsuchi-shiny.png |
| Mob · ???% | mob | Mob Psycho 100 | Secreta | Preto | Mágico | Magia dos Pretos +18% | ap-mob-por-cento.png | ap-mob-por-cento-shiny.png |
| Nami | nami | One Piece | Incomum | Turquesa | Mágico | Magia dos Turquesas +10% | ap-nami.png | ap-nami-shiny.png |
| Netero | netero | Hunter × Hunter | Divina | Dourado | Combatente | Ataque dos Dourados +15% | ap-netero.png | ap-netero-shiny.png |
| Piccolo | piccolo | Dragon Ball | Épica | Verde | Guardião | Defesa e Resistência de Dragon Ball +12% | ap-piccolo.png | ap-piccolo-shiny.png |
| Rock Lee | rocklee | Naruto | Rara | Verde | Combatente | Velocidade dos Verdes +10% | ap-rock-lee.png | ap-rock-lee-shiny.png |
| Shinra Banshōman | shinra_banshoman | Fire Force | Transcendente | Dourado | Combatente | Ataque dos Dourados +22% | ap-shinra-banshoman.png | ap-shinra-banshoman-shiny.png |
| Shinra Kusakabe | shinra | Fire Force | Épica | Vermelho | Combatente | Ataque dos Vermelhos +12% | ap-shinra-kusakabe.png | ap-shinra-kusakabe-shiny.png |
| Tenshinhan | tenshinhan | Dragon Ball | Rara | Branco | Suporte | Velocidade dos Brancos +10% | ap-tenshinhan.png | ap-tenshinhan-shiny.png |
| Trafalgar Law | law | One Piece | Mítica | Azul | Suporte | PV dos Azuis +12% | ap-trafalgar-law.png | ap-trafalgar-law-shiny.png |
| Usopp | usopp | One Piece | Comum | Amarelo | Suporte | PV dos Amarelos +8% | ap-usopp.png | ap-usopp-shiny.png |
| Vegeta · Blue | vegeta | Dragon Ball | Secreta | Azul | Combatente | Ataque dos Azuis +18% | ap-vegeta-super-saiyajin-blue.png | ap-vegeta-super-saiyajin-blue-shiny.png |
| Veldora Tempest | veldora | Tensei Shitara Slime Datta Ken | Secreta | Turquesa | Mágico | Magia dos Turquesas +18% | ap-veldora-tempest.png | ap-veldora-tempest-shiny.png |
| Yamcha | yamcha | Dragon Ball | Comum | Laranja | Combatente | Ataque de Combatentes +8% | ap-yamcha.png | ap-yamcha-shiny.png |
| Yoruichi Shihōin | yoruichi | Bleach | Mítica | Amarelo | Combatente | Ataque dos Amarelos +15% | ap-yoruichi-shihoin.png | ap-yoruichi-shihoin-shiny.png |
| Zoro | zoro | One Piece | Épica | Verde | Combatente | Ataque dos Verdes +12% | ap-zoro.png | ap-zoro-shiny.png |

## Habilidades especiais

| Personagem | Habilidade | Efeito na campanha |
| --- | --- | --- |
| Accelerator | Controle Vetorial | Reflete até duas habilidades de alvo único por luta, com recarga de 8 s e alcance de um espaço na ordem da formação. |
| Android 17 | Barreira Contínua | Cria um escudo de 110% da Magia e pode interceptar um golpe contra um aliado próximo nos 4,5 s seguintes. |
| Arthur Boyle | Excalibur | O corte de plasma causa 145% do Ataque e ignora 35% da Defesa do alvo. Recarga de 7 s. |
| Beerus | Hakai | Remove o escudo, causa dano mágico equivalente a 240% da Magia e bloqueia a ressurreição se o golpe for fatal. |
| Benimaru Shinmon | Nichirin | Atinge o alvo com 180% do Ataque e os demais inimigos a até 28 unidades dele com 85% do Ataque. Recarga de 10 s. |
| Broly · Super | Fúria Crescente | Causa dano físico equivalente a 160% do Ataque. |
| Bulma | Cápsula de Proteção | Aplica um escudo de 200% da Magia ao aliado com a menor porcentagem de PV, quando ele tem 95% de PV ou menos. |
| Coyote Starrk | Cero Metralleta | Dispara três tiros de 60% da Magia contra o mesmo alvo. Recarga de 9 s. |
| Freeza · Forma Final | Raio da Morte | Causa dano mágico equivalente a 165% da Magia. |
| Gohan · Namek | Explosão de Raiva | Causa dano físico equivalente a 160% do Ataque. |
| Gojo | Vazio Ilimitado | Causa dano mágico equivalente a 165% da Magia. |
| Goku · Instinto Superior | Resposta Instintiva | Causa dano físico equivalente a 160% do Ataque. |
| Iris | Prece da Companhia 8 | Cura o aliado com a menor porcentagem de PV em 130% da Magia, quando ele tem 95% de PV ou menos. |
| Kisuke Urahara | Benihime · Escudo de Sangue | Aplica um escudo de 200% da Magia ao aliado com a menor porcentagem de PV, quando ele tem 95% de PV ou menos. |
| Kuririn | Disco Cortante | Causa dano mágico equivalente a 165% da Magia ao inimigo com menos PV. |
| Luminous Valentine | Ciclo de Vida e Morte | Cura em 200% da Magia o aliado em campo com a menor porcentagem de PV e atinge o adversário com 105% da Magia. Recarga de 9 s. |
| Maki Oze | Guarda das Chamas | Cria um escudo de 110% da Magia e pode interceptar um golpe contra um aliado próximo nos 4,5 s seguintes. |
| Mayuri Kurotsuchi | Ashisogi Jizō | Enfraquece os ataques básicos do alvo em 35% por 4 s e causa dano mágico de 130% da Magia. Recarga de 9 s. |
| Mob · ???% | Despertar Psíquico | Causa dano mágico equivalente a 165% da Magia. |
| Nami | Nuvem de Tempestade | Causa dano mágico equivalente a 165% da Magia. |
| Netero | Mãos do Bodisatva | Causa dano físico equivalente a 160% do Ataque. |
| Piccolo | Proteção Namekuseijin | Cria um escudo de 110% da Magia e pode interceptar um golpe contra um aliado próximo nos 4,5 s seguintes. |
| Rock Lee | Lótus Primária | Causa dano físico equivalente a 160% do Ataque. |
| Shinra Banshōman | Reescrita da Realidade | Golpeia com 190% do Ataque. Uma vez por luta, se um aliado em campo estiver com até 40% de PV, usa a ação para restaurar metade dos PV máximos do mais ferido. Recarga de 9 s. |
| Shinra Kusakabe | Chute de Ignição | Causa dano físico equivalente a 160% do Ataque. |
| Tenshinhan | Taiyōken | Cria um escudo de 110% da Magia e pode interceptar um golpe contra um aliado próximo nos 4,5 s seguintes. |
| Trafalgar Law | ROOM | Aplica um escudo de 200% da Magia ao aliado com a menor porcentagem de PV, quando ele tem 95% de PV ou menos. |
| Usopp | Estilingue | Cura o aliado com a menor porcentagem de PV em 130% da Magia, quando ele tem 95% de PV ou menos. |
| Vegeta · Blue | Final Flash | Causa dano físico equivalente a 160% do Ataque. |
| Veldora Tempest | Tempestade do Dragão | Desfere um raio de 185% da Magia que ignora 30% da Resistência. Um arco secundário de 75% da Magia atinge outro inimigo em campo, se houver. Recarga de 10 s. |
| Yamcha | Punho do Lobo | Causa dano físico equivalente a 160% do Ataque. |
| Yoruichi Shihōin | Shunkō | Golpeia com 140% do Ataque e ganha uma carga de esquiva contra um golpe de alvo único. Recarga de 12 s. |
| Zoro | Santōryū | Causa dano físico equivalente a 160% do Ataque. |

## Traits

| Trait | Raridade | Chance | Atributos | Passiva |
| --- | --- | --- | --- | --- |
| Concentração Total | Comum | 1/4 | +30% PV | — |
| Reforço Amaldiçoado | Comum | 1/5 | +25% Ataque, +25% Magia | — |
| Haki do Armamento | Incomum | 1/10 | +40% Defesa | — |
| Ten | Incomum | 1/10 | +40% Resistência | — |
| Kaidō | Rara | 1/20 | +35% Magia, +20% Resistência | — |
| Shunpo | Rara | 1/20 | +20% Ataque, +35% Velocidade | — |
| Modo Sábio | Rara | 1/25 | +35% PV, +25% Defesa, +25% Resistência | — |
| Respiração do Trovão | Rara | 1/25 | +40% Ataque, +25% Velocidade | — |
| Haki do Rei | Épica | 1/50 | +30% PV, +50% Ataque, +50% Magia | Ao iniciar a luta, trava as ações inimigas por 2 s. Durante esse período, os inimigos recebem 30% mais dano. Uma ativação por equipe. |
| Instinto Superior | Mítica | 1/100 | +40% Ataque, +40% Magia, +50% Velocidade | Esquiva dos três primeiros golpes diretos de alvo único e contra-ataca o agressor se ele estiver em campo e o portador puder agir. |
| Restrição Celestial | Mítica | 1/125 | +60% PV, +50% Defesa, +50% Resistência | Intercepta os dois primeiros golpes de alvo único contra aliados próximos e sofre metade do dano. Na Arena, pode proteger o titular da reserva. |
| Haki da Observação | Mítica | 1/125 | +40% Ataque, +40% Defesa | Até duas vezes por luta, antecipa uma habilidade de alvo único com um golpe de 200% do dano básico. Eliminar o atacante cancela a habilidade. |
| Zenkai | Divina | 1/200 | +45% PV, +35% Defesa | Uma vez por luta, sobrevive a um golpe fatal com 40% dos PV máximos e ganha +75% de Ataque e Magia até o fim do combate. |
| Full Counter | Divina | 1/250 | +60% Defesa, +60% Resistência | Reflete a primeira habilidade mágica de alvo único que atingir o portador ou um aliado próximo. Devolve o dobro do dano-base da habilidade. |
| The World | Secreta | 1/500 | +60% Ataque, +60% Magia, +40% Velocidade | Após a primeira habilidade principal bem-sucedida, para o tempo por 3 s. Só o portador pode agir e sua habilidade fica pronta outra vez. |
| Voto de Nen | Secreta | 1/1000 | +60% PV, +40% Defesa, +40% Resistência | Última Aposta é opcional. Ative na ficha para causar 4× o dano e ocupar duas vagas. Desative para voltar a usar uma vaga e conservar os bônus de atributos. |
| Made in Heaven | Transcendente | 1/2000 | +50% Resistência | Causa 4× o dano durante toda a luta e ocupa uma vaga. Na primeira ação ofensiva, ativa Aceleração do Tempo por 5 s. O intervalo de ações cai 80% para o portador e 40% para aliados. A aceleração coletiva não acumula. |

## Cores

| Cor | Código |
| --- | --- |
| Verde | #71dd9f |
| Laranja | #ffab68 |
| Amarelo | #f5d66c |
| Azul | #83baff |
| Branco | #ecebff |
| Roxo | #cc95ff |
| Rosa | #f592bc |
| Preto | #a8a2be |
| Vermelho | #ff8290 |
| Turquesa | #70e1da |
| Dourado | #ffe28a |

## Inimigos da campanha

| Mundo | Encontro | Inimigo | Nível | Sprite |
| --- | --- | --- | --- | --- |
| Namek | Costa de Namek | Soldado da Tropa Freeza | 1–3 | enemy-1-1.png |
| Namek | Planícies Verdes | Veterano da Tropa Freeza | 4–6 | enemy-1-2.png |
| Namek | Base de Freeza | Oficial da Tropa Freeza | 7–10 | enemy-1-3.png |
| Namek | Elite | Capitão Ginyu | 11 | enemy-1-4.png |
| Namek | Chefe | Freeza · forma final | 12 | enemy-1-5.png |
| Arlong Park | Costa de Cocoyasi | Vigia dos Piratas Arlong | 11–13 | enemy-2-1.png |
| Arlong Park | Vila de Cocoyasi | Homem-peixe dos Piratas Arlong | 14–16 | enemy-2-2.png |
| Arlong Park | Fortaleza de Arlong | Veterano dos Piratas Arlong | 17–20 | enemy-2-3.png |
| Arlong Park | Elite | Kuroobi | 21 | enemy-2-4.png |
| Arlong Park | Chefe | Arlong | 22 | enemy-2-5.png |
| Exames Chūnin | Portões da Folha | Genin rival | 21–23 | enemy-3-1.png |
| Exames Chūnin | Floresta da Morte | Genin da Vila do Som | 24–26 | enemy-3-2.png |
| Exames Chūnin | Arena dos Exames | Genin da Vila da Areia | 27–30 | enemy-3-3.png |
| Exames Chūnin | Elite | Neji Hyūga | 31 | enemy-3-4.png |
| Exames Chūnin | Chefe | Gaara · transformação parcial | 32 | enemy-3-5.png |
| Soul Society | Rukongai | Shinigami em patrulha | 31–33 | enemy-4-1.png |
| Soul Society | Muralhas do Seireitei | Soldado da guarda do Seireitei | 34–36 | enemy-4-2.png |
| Soul Society | Colina de Sōkyoku | Oficial de esquadrão | 37–40 | enemy-4-3.png |
| Soul Society | Elite | Renji Abarai | 41 | enemy-4-4.png |
| Soul Society | Chefe | Byakuya Kuchiki | 42 | enemy-4-5.png |
| Jujutsu Kaisen | Escola de Jujutsu | Maldição menor | 41–43 | enemy-5-1.png |
| Jujutsu Kaisen | Distrito amaldiçoado | Maldição de distrito | 44–46 | enemy-5-2.png |
| Jujutsu Kaisen | Domínio vulcânico | Maldição de grau 2 | 47–50 | enemy-5-3.png |
| Jujutsu Kaisen | Elite | Portador de Dedo | 51 | enemy-5-4.png |
| Jujutsu Kaisen | Chefe | Jogo | 52 | enemy-5-5.png |
| Black Clover | Vila de Hage | Recruta do Olho do Sol da Meia-Noite | 51–53 | enemy-6-1.png |
| Black Clover | Floresta encantada | Mago do Olho do Sol da Meia-Noite | 54–56 | enemy-6-2.png |
| Black Clover | Templo submerso | Veterano do Olho do Sol da Meia-Noite | 57–60 | enemy-6-3.png |
| Black Clover | Elite | Fana | 61 | enemy-6-4.png |
| Black Clover | Chefe | Vetto | 62 | enemy-6-5.png |
| Nanatsu no Taizai | Arredores de Liones | Recruta de Liones | 61–63 | enemy-7-1.png |
| Nanatsu no Taizai | Cidade de Liones | Cavaleiro de Liones | 64–66 | enemy-7-2.png |
| Nanatsu no Taizai | Castelo real | Cavaleiro Sagrado | 67–70 | enemy-7-3.png |
| Nanatsu no Taizai | Elite | Dreyfus | 71 | enemy-7-4.png |
| Nanatsu no Taizai | Chefe | Hendrickson · forma demoníaca | 72 | enemy-7-5.png |
| JoJo | Ruas do Cairo | Capanga de DIO | 71–73 | enemy-8-1.png |
| JoJo | Distrito antigo | Usuário de Stand a serviço de DIO | 74–76 | enemy-8-2.png |
| JoJo | Mansão de DIO | Usuário de Stand veterano | 77–80 | enemy-8-3.png |
| JoJo | Elite | Vanilla Ice | 81 | enemy-8-4.png |
| JoJo | Chefe | DIO · The World | 82 | enemy-8-5.png |
| Hunter × Hunter | Fronteira de NGL | Formiga Quimera operária | 81–83 | enemy-9-1.png |
| Hunter × Hunter | Território das formigas | Formiga Quimera soldado | 84–86 | enemy-9-2.png |
| Hunter × Hunter | Palácio Real | Formiga Quimera capitã | 87–90 | enemy-9-3.png |
| Hunter × Hunter | Elite | Neferpitou | 91 | enemy-9-4.png |
| Hunter × Hunter | Chefe | Meruem | 92 | enemy-9-5.png |
| One Punch Man | Periferia da Cidade Z | Monstro nível Lobo | 91–93 | enemy-10-1.png |
| One Punch Man | Zona evacuada | Monstro nível Tigre | 94–96 | enemy-10-2.png |
| One Punch Man | Covil dos monstros | Monstro nível Demônio | 97–100 | enemy-10-3.png |
| One Punch Man | Elite | Rei do Mar Profundo | 101 | enemy-10-4.png |
| One Punch Man | Chefe | Boros | 102 | enemy-10-5.png |

## Upgrades

| Upgrade | Efeito | Valores do nível zero ao máximo | Preços sucessivos em ouro | Mundos exigidos |
| --- | --- | --- | --- | --- |
| Ritmo de expedição | Reduz a espera entre encontros. | 10 s → 9 s → 8 s → 7 s → 6 s → 5 s | 120 / 1800 / 15000 / 80000 / 240000 | 1 / 2 / 4 / 6 / 8 |
| Sorte | Até 50% de chance de encontrar um recruta. Cada ponto de Sorte excedente aumenta em 1% relativo a chance de Raro ou superior entre os recrutas. | 10% → 20% → 30% → 40% → 50% → 60% → 70% → 80% → 90% → 100% | 50 / 125 / 300 / 1000 / 3500 / 12000 / 36000 / 90000 / 200000 | 1 / 1 / 1 / 2 / 3 / 5 / 7 / 8 / 10 |
| Bônus de ouro | Acrescenta ouro às vitórias em encontros comuns e de elite. | 0% → 10% → 20% → 30% → 35% → 40% → 45% → 50% | 75 / 180 / 400 / 2000 / 18000 / 90000 / 250000 | 1 / 1 / 1 / 2 / 4 / 6 / 8 |
| Experiência compartilhada | Distribui entre os reservas uma fração da XP que um titular recebe por vitória. Cada titular mantém sua recompensa integral. | 0% → 25% → 40% → 60% → 70% → 80% → 90% → 100% | 60 / 150 / 325 / 1600 / 14000 / 75000 / 210000 | 1 / 1 / 1 / 2 / 4 / 6 / 8 |
| Rastreio de raros | Chance de um recruta ser de raridade Rara ou superior. Cada uma dessas raridades recebe o mesmo aumento proporcional. | 18% → 20% → 24% → 28% → 32% → 36% | 100 / 600 / 4500 / 24000 / 100000 | 1 / 2 / 4 / 6 / 9 |
| Treino de combate | Aumenta a XP por vitória na campanha. O bônus também entra no cálculo da experiência compartilhada. | 0% → 10% → 20% → 30% → 40% | 80 / 700 / 5000 / 30000 | 1 / 2 / 4 / 7 |
| Enfermaria | Reduz o tempo de recuperação de titulares derrotados na exploração, inclusive quando a equipe inteira cai. | 20 s → 18 s → 16 s → 14 s → 12 s | 90 / 1000 / 6500 / 45000 | 1 / 3 / 5 / 8 |

## Venda de cópias

| Raridade | Ouro |
| --- | --- |
| Comum | 8 |
| Incomum | 20 |
| Rara | 50 |
| Épica | 125 |
| Mítica | 350 |
| Divina | 1000 |
| Secreta | 3500 |
| Transcendente | 12000 |
