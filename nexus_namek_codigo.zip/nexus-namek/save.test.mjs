import test from 'node:test';
import assert from 'node:assert/strict';
import {fresh, advance, CHARACTERS, WORLDS} from './public/game.js';
import {saveKey, readCampaign, writeCampaign, packCampaign, unpackCampaign} from './public/save.js';

function browserStorage(){
  const entries=new Map();
  return {getItem:k=>entries.get(k)??null,setItem:(k,v)=>entries.set(k,v),removeItem:k=>entries.delete(k)};
}

test('atualização lê o save da build anterior e recupera o último checkpoint íntegro',()=>{
  const storage=browserStorage(), old=fresh(1234,42);
  old.gold=850;
  storage.setItem(saveKey,JSON.stringify(old));
  assert.deepEqual(readCampaign(storage),old);
  writeCampaign(storage,{...old,gold:900});
  assert.equal(readCampaign(storage).gold,900);
  storage.setItem(saveKey,'incompleto');
  assert.deepEqual(readCampaign(storage),old);
  storage.setItem(saveKey,'{"version":2}');
  assert.throws(()=>readCampaign(storage),/recente/);
});

test('backup transporta a campanha e o combate pendente para outro navegador',()=>{
  const old=fresh(1234,42);
  old.gold=850;
  advance(old,old.clock);
  assert.ok(old.pending);
  const backup=packCampaign(old);
  const restored=unpackCampaign(backup,CHARACTERS,WORLDS);
  assert.deepEqual(restored,JSON.parse(JSON.stringify(old)));
  const other=browserStorage();
  writeCampaign(other,restored);
  assert.deepEqual(readCampaign(other),restored);
  assert.throws(()=>unpackCampaign('{"game":"outro"}',CHARACTERS,WORLDS));
});
