const serials=(()=>{

// Reserve the old per-account numbering ranges once, including gaps left by sales.
function serialSchema(players,hasRanks){
  const kind="json_extract(u.value,'$.id') || CASE WHEN json_extract(u.value,'$.shiny') THEN '-shiny' ELSE '' END";
  const base=(value)=>`coalesce((SELECT offset FROM nexus_legacy_ranges WHERE owner=p.id AND kind=json_extract(${value},'$.id') || CASE WHEN json_extract(${value},'$.shiny') THEN '-shiny' ELSE '' END),0)`;
  const mapped=(value)=>`json_set(${value},'$.serial',json_extract(${value},'$.serial')+${base(value)})`;
  const array=(source)=>`(SELECT json_group_array(json(${mapped('u.value')})) FROM json_each(${source}) u)`;
  let entry='u.value';
  for(const field of ['recruit','sold']){
    const obj=`json_extract(u.value,'$.${field}')`;
    entry=`json_set(${entry},'$.${field}',json(CASE WHEN json_type(u.value,'$.${field}')='object' THEN ${mapped(obj)} ELSE NULL END))`;
  }
  return [
    'CREATE TABLE IF NOT EXISTS nexus_serials(id INTEGER PRIMARY KEY, revision INTEGER NOT NULL, counts TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS nexus_legacy_ranges(owner TEXT,kind TEXT,offset INTEGER,amount INTEGER,PRIMARY KEY(owner,kind))',
    `INSERT INTO nexus_legacy_ranges
     WITH source AS (
       SELECT p.id owner,${kind} kind,json_extract(u.value,'$.serial') n,json_extract(p.game,'$.created') created FROM ${players} p,json_each(p.game,'$.collection') u WHERE NOT EXISTS(SELECT 1 FROM nexus_serials)
       UNION ALL SELECT p.id,u.key,u.value,json_extract(p.game,'$.created') FROM ${players} p,json_each(p.game,'$.serials') u WHERE NOT EXISTS(SELECT 1 FROM nexus_serials)
     ), limits AS (SELECT owner,kind,max(n) amount,created FROM source GROUP BY owner,kind)
     SELECT owner,kind,coalesce(sum(amount) OVER(PARTITION BY kind ORDER BY created,owner ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0),amount FROM limits`,
    `UPDATE ${players} AS p SET game=json_set(game,'$.collection',json(${array("p.game,'$.collection'")}),'$.log',json((SELECT json_group_array(json(${entry})) FROM json_each(p.game,'$.log') u)))${hasRanks?`,top_units=${array('p.top_units')},rare_units=${array('p.rare_units')}`:''} WHERE NOT EXISTS(SELECT 1 FROM nexus_serials)`,
    "INSERT OR IGNORE INTO nexus_serials SELECT 1,0,json_group_object(kind,n) FROM (SELECT kind,sum(amount) n FROM nexus_legacy_ranges GROUP BY kind)",
    ...['INSERT','UPDATE OF game'].map((event,i)=>`CREATE TRIGGER IF NOT EXISTS nexus_issue_${i} AFTER ${event} ON ${players}
      WHEN json_extract(NEW.game,'$.issuance.revision')=(SELECT revision+1 FROM nexus_serials WHERE id=1)
      BEGIN UPDATE nexus_serials SET revision=revision+1,counts=json_patch(counts,json_extract(NEW.game,'$.issuance.counts')) WHERE id=1; END`)
  ];
}
function issueSerials(state,units,counter){
  delete state.issuance;
  if(!units.length)return;
  const previous=JSON.parse(counter.counts),counts={};
  for(const unit of units){
    const key=unit.id+(unit.shiny?'-shiny':'');
    unit.serial=counts[key]=(counts[key]??previous[key]??0)+1;
  }
  state.issuance={revision:counter.revision+1,counts};
}

return {serialSchema,issueSerials};
})();
const engine=(()=>{

function hasTrait(unit,name){return unit.traits?.includes(name)||unit.trait===name;}
const DEFAULT_LIMIT = 60000;
const SAMPLE_STEP = 100;
const HP_EPSILON = 1e-8;
const sum = values => values.reduce((a, b) => a + b, 0);
const COLORS = ['Vermelho','Laranja','Amarelo','Verde','Turquesa','Azul','Roxo','Rosa'];
function affinity(a, b) {
  if (!a || !b) return 1;
  if (a === 'Dourado') return b === a ? 2 : 1.5;
  if ((a === 'Branco' || a === 'Preto') && a === b) return 1.5;
  const position = COLORS.indexOf(a);
  if (position < 0) return 1;
  return b === COLORS[(position + 1) % 8] ? 1.5 : b === COLORS[(position + 7) % 8] ? .75 : 1;
}
const distance = (a, b) => Math.hypot((a.x ?? a.slot * 20) - (b.x ?? b.slot * 20), (a.y ?? 50) - (b.y ?? 50));
const MAIN_SKILLS = new Set(['piccolo','yamcha','kuririn','bulma','freeza-boss','ginyu','beam','rush','ward','heal']);

class Combate {
  constructor(rosters, { mode = 'duelo', limit = DEFAULT_LIMIT } = {}) {
    if (!['duelo', 'equipe'].includes(mode) || !Number.isInteger(limit) || limit < SAMPLE_STEP || limit > DEFAULT_LIMIT || rosters.length !== 2 || rosters.some(team => !team.length || team.length > 4)) {
      throw new RangeError('Configuração de combate inválida.');
    }
    this.mode = mode;
    this.limit = limit;
    this.time = 0;
    this.teams = rosters.map((team, side) => team.map((spec, slot) => ({
      ...spec, side, slot, id: `${side}:${slot}`, name: spec.name ?? `${side}:${slot}`,
      hp: spec.hp ?? 1000, maxHp: spec.hp ?? 1000, attack: spec.attack ?? 100, magic: spec.magic ?? 100,
      defense: spec.defense ?? 0, resistance: spec.resistance ?? 0, shield: spec.shield ?? 0,
      interval: Math.max(SAMPLE_STEP, spec.interval ?? 3000), nextBasic: Math.max(SAMPLE_STEP, spec.interval ?? 3000),
      nextAssist: 5000, evade: spec.evade ?? 0, intercept: spec.intercept ?? 0, survive: spec.survive ?? 0, protectUntil: spec.intercept ? Infinity : 0,
      revive: spec.revive ?? 0, vector: spec.kind === 'accelerator' ? 2 : 0, vectorReady: 0,
      uses: 0, skillReady: 0, actions: 0, seenId: null, seenActions: 0, graceUntil: 0,
      weakenUntil: 0, powerUntil: 0, resistedUntil: 0,
    })));
    this.log = [];
    this.hasteUntil=[0,0];
    for(const team of this.teams){
      const king=team.find(u=>hasTrait(u,'Haki do Rei'));
      if(king)for(const foe of this.teams[1-king.side]){
        foe.stunUntil=2000;foe.exposedUntil=2000;
      }
    }
  }

  record(type, actor, target, data = {}) {
    this.log.push({ time: this.time, type, actor: actor?.id, target: target?.id, ...data });
  }

  alive(u) { return u.hp > HP_EPSILON; }
  active(side) { return this.teams[side].find(u => this.alive(u)); }
  present(u) { return this.alive(u) && (this.mode === 'equipe' || this.active(u.side) === u); }

  blocked(u){return u.stunUntil>this.time||(this.freezeUntil>this.time&&this.freezeOwner!==u);}
  pace(u){
    if(u.hasteUntil>this.time)return .2;
    return this.hasteUntil[u.side]>this.time?.6:1;
  }
  beginAttack(u){
    if(!hasTrait(u,'Made in Heaven')||u.heavenUsed)return;
    const team=this.teams[u.side],before=team.map(f=>this.pace(f));
    u.heavenUsed=true;u.hasteUntil=this.time+5000;this.hasteUntil[u.side]=this.time+5000;
    team.forEach((f,i)=>{
      const ratio=this.pace(f)/before[i];
      if(f.nextBasic>this.time)f.nextBasic=this.time+(f.nextBasic-this.time)*ratio;
      if(f.ready>this.time/1000)f.ready=this.time/1000+(f.ready-this.time/1000)*ratio;
    });
    this.record('aceleração',u);
  }
  outgoingPower(source,damage,basic=false){
    const trait=Math.max(1,(hasTrait(source,'Made in Heaven')?4:0)+(source.nen?4:0));
    return damage*trait*(basic&&source.weakenUntil>this.time?.65:1);
  }

  hit(source, target, attack = {}) {
    const { damage = source.attack, magic = false, skill = true, area = false, reflected = false,
      removeShield = false, shieldMultiplier = 1, ignoreDefense = 0, blockRevive = false, delayOnBreak = 0 } = attack;
    if (!this.alive(source) || !this.present(target) || source.side === target.side) return false;
    if (!Number.isFinite(damage) || damage < 0 || !Number.isFinite(shieldMultiplier) || shieldMultiplier < 1) throw new RangeError('Dano ou multiplicador inválido.');
    if(!reflected)this.beginAttack(source);
    let victim = target,interceptFactor=1;
    if(!area&&!reflected){
      const guard=this.teams[target.side].find(u=>u!==target&&hasTrait(u,'Restrição Celestial')&&!this.blocked(u)&&this.alive(u)&&(u.guardUses??0)<2&&(this.mode==='duelo'||distance(u,target)<=30));
      if(guard){guard.guardUses=(guard.guardUses??0)+1;victim=guard;interceptFactor=.5;this.record('intercepta',guard,target);}
    }
    if (victim===target && !area && !reflected && this.mode === 'equipe') {
      const guard = this.teams[target.side].find(u => u !== target && !this.blocked(u) && this.alive(u) && u.intercept > 0 && u.protectUntil >= this.time && distance(u,target) <= 30);
      if (guard) {
        guard.intercept--;
        victim = guard;
        this.record('intercepta', guard, target);
      }
    }
    if (!area && !reflected && victim.evade > 0) {
      victim.evade--;
      this.record('esquiva', victim, source);
      if(hasTrait(victim,'Instinto Superior')&&!attack.counter&&!this.blocked(victim)&&this.present(source))this.hit(victim,source,{skill:false,counter:true,magic:!!victim.magicBasic,damage:victim.magicBasic?victim.magic:victim.attack});
      return true;
    }
    if(!area&&!reflected&&skill&&hasTrait(victim,'Haki da Observação')&&(victim.observeUses??0)<2&&!this.blocked(victim)&&this.present(source)){
      victim.observeUses=(victim.observeUses??0)+1;
      this.hit(victim,source,{skill:false,counter:true,damage:2*(victim.magicBasic?victim.magic:victim.attack),magic:!!victim.magicBasic});
      if(!this.alive(source))return true;
    }
    if (!area && !reflected && skill) {
      const mirror=magic&&this.teams[victim.side].find(u=>hasTrait(u,'Full Counter')&&!u.mirrorUsed&&this.alive(u)&&!this.blocked(u)&&(u===victim||this.mode==='duelo'||distance(u,victim)<=30));
      if(mirror){
        mirror.mirrorUsed=true;this.record('reflete',mirror,source);
        this.hit(mirror,this.present(source)?source:this.active(source.side),{...attack,damage:damage*2,reflected:true});
        return true;
      }
      const vector = this.teams[victim.side].find(u => this.alive(u) && u.vector > 0 && u.vectorReady <= this.time && (this.mode === 'duelo' || Math.abs(u.slot - victim.slot) <= 1));
      if (vector) {
        vector.vector--;
        vector.vectorReady = this.time + 8000;
        this.record('especial',vector,source,{name:vector.skill??'Controle Vetorial',role:'reação'});
        this.record('reflete', vector, source, { remaining: vector.vector });
        const returnTarget = this.present(source) ? source : this.active(source.side);
        if (returnTarget) this.hit(vector, returnTarget, { ...attack, damage, reflected: true });
        return true;
      }
    }
    const openPower = skill && !reflected && source.powerUntil > this.time;
    if (openPower) source.powerUntil = 0;
    const mitigation = (magic ? victim.resistance : victim.defense) * (1 - ignoreDefense);
    let value = this.outgoingPower(source,damage,!skill) * interceptFactor * (victim.exposedUntil>this.time?1.3:1) * affinity(source.color,victim.color) * (openPower ? 1.3 : 1) * 40 / (40 + mitigation/(source.scale || 1));
    if(source.kotoUntil>this.time && (skill || false)){
      source.kotoUntil=0;
      value*=.65;
    }
    if(attack.koto)victim.kotoUntil=Infinity;
    const priorShield = victim.shield;
    if (removeShield) victim.shield = 0;
    const absorbed = Math.min(victim.shield, value * shieldMultiplier);
    victim.shield -= absorbed;
    value -= absorbed / shieldMultiplier;
    if (priorShield > 0 && victim.shield <= HP_EPSILON) {
      victim.shield = 0;
      victim.nextBasic += delayOnBreak;
      this.record('escudo rompe', source, victim);
    }
    if(victim.kind==='fiction'&&!victim.fictionSpent&&value>=victim.hp){
      victim.fictionSpent=true;this.record('apaga',victim,source);return true;
    }
    const actual = Math.min(victim.hp, value);
    victim.hp = Math.max(0, victim.hp - value);
    this.record('dano', source, victim, { hp: actual, reflected, remaining: victim.hp, skill });
    if (!this.alive(victim)) this.defeat(victim, source, blockRevive);
    return true;
  }

  defeat(victim, source, blockRevive) {
    if (victim.survive > 0) {
      victim.survive--;
      if(hasTrait(victim,"Zenkai")){victim.attack*=1.75;victim.magic*=1.75;}
      victim.hp = victim.maxHp * .4;
      this.record('sobrevive', victim, source, { remaining: victim.hp });
    } else if (victim.revive > 0 && !blockRevive) {
      victim.revive--;
      victim.hp = victim.maxHp * .7;
      this.record('ressurge', victim, source, { remaining: victim.hp });
    } else {
      victim.hp = 0;
      victim.shield = 0;
      const successor = this.mode === 'duelo' ? this.active(victim.side) : null;
      this.record('cai', victim, source);
      if (successor) {
        successor.nextBasic = this.time + successor.interval;
        successor.graceUntil = this.time + SAMPLE_STEP;
        this.record('entra', successor);
      }
    }
  }

  heal(unit, amount) {
    if (!this.alive(unit)) return;
    unit.hp = Math.min(unit.maxHp, unit.hp + amount);
    this.record('cura', unit, undefined, { remaining: unit.hp });
  }

  use(actor,target,type,role='principal',launch){
    const used=this.cast(actor,target,type,role,launch);
    if(used&&actor.skill)this.record('especial',actor,target,{name:actor.skill,role});
    if(used&&role==='principal'&&hasTrait(actor,'The World')&&!actor.worldUsed){
      actor.worldUsed=true;this.freezeOwner=actor;this.freezeUntil=this.time+3000;
      actor.skillReady=0;actor.nextBasic=Math.min(actor.nextBasic,this.time+SAMPLE_STEP);
      actor.ready=this.time/1000;this.record('tempo parado',actor);
    }
    return used;
  }
  cast(actor, target, type, role = 'principal', launch) {
    if (!this.alive(actor) || !this.present(target)) return false;
    const deliver = launch ?? ((victim,options)=>this.hit(actor,victim,options));
    const strike = options => deliver(target,options);
    switch (type) {
      case 'koto':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+8000;
        return strike({magic:true,koto:true,damage:actor.magic*1.5});
      case 'demonSword':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+7000;
        for(let i=0;i<3&&this.alive(actor)&&this.present(target);i++)
          strike({damage:actor.attack*.65,ignoreDefense:i===2?.5:0});
        return true;
      case 'room':
      case 'benihime': {
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+8000;
        const ally=this.teams[actor.side].filter(u=>this.present(u))
          .reduce((lowest,u)=>u.hp/u.maxHp<lowest.hp/lowest.maxHp?u:lowest);
        if(type==='room'){
          this.heal(ally,1.5*actor.magic);
          return strike({magic:true,damage:1.35*actor.magic,ignoreDefense:.4});
        }
        ally.shield=Math.max(ally.shield,2.2*actor.magic);
        this.record('protege',actor,ally);
        return strike({magic:true,damage:1.05*actor.magic});
      }
      case 'barreira':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+9000;
        for(const ally of this.teams[actor.side].filter(u=>this.present(u))){
          ally.shield=Math.max(ally.shield,actor.defense*(ally===actor?1.8:1));
          this.record('protege',actor,ally);
        }
        return true;
      case 'death_ray':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+7000;
        return strike({magic:true,damage:actor.magic*(target.hp<target.maxHp*.35?2.35:1.75),ignoreDefense:.25});
      case 'final_flash':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+8000;
        return strike({damage:actor.attack*2.15,shieldMultiplier:2});
      case 'furia':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+6000;
        return strike({damage:actor.attack*(1.65+.25*Math.min(actor.uses++,3))});
      case 'instinto':
      case 'bodisatva': {
        if(actor.skillReady>this.time)return false;
        const instinct=type==='instinto';
        actor.skillReady=this.time+(instinct?8000:7000);
        if(instinct)actor.evade=Math.max(actor.evade,1);
        for(let i=0;i<(instinct?2:3)&&this.alive(actor)&&this.present(target);i++)
          strike({damage:actor.attack*(instinct?1:.65),ignoreDefense:i===2?.5:0});
        return true;
      }
      case 'dominio':
      case 'despertar': {
        if(actor.skillReady>this.time)return false;
        const domain=type==='dominio';
        actor.skillReady=this.time+(domain?12000:9000);
        const damage=actor.magic*(domain?1.55:actor.hp<=actor.maxHp*.5?2.25:1.65);
        for(const foe of this.teams[target.side].filter(u=>this.present(u))){
          deliver(foe,{magic:true,area:true,damage});
          if(domain&&!launch)foe.stunUntil=Math.max(foe.stunUntil??0,this.time+1500);
        }
        return true;
      }
      case 'reescrita':
      case 'ciclo_vital': {
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+9000;
        const ally=this.teams[actor.side].filter(unit=>this.present(unit))
          .reduce((lowest,unit)=>unit.hp/unit.maxHp<lowest.hp/lowest.maxHp?unit:lowest);
        if(type==='ciclo_vital'){
          this.heal(ally,actor.magic*2);
          return strike({damage:actor.magic*1.05,magic:true});
        }
        if(actor.uses===0&&ally.hp<=ally.maxHp*.4){
          actor.uses++;
          this.heal(ally,ally.maxHp*.5);
          return true;
        }
        return strike({damage:actor.attack*1.9});
      }
      case 'nichirin': {
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+10000;
        const victims=this.teams[target.side].filter(unit=>this.present(unit)&&distance(unit,target)<=28);
        this.record('onda',actor,target,{targets:victims.map(unit=>unit.id)});
        for(const unit of victims)deliver(unit,{damage:actor.attack*(unit===target?1.8:.85),area:true});
        return true;
      }
      case 'tempestade': {
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+10000;
        const other=this.teams[target.side].find(unit=>unit!==target&&this.present(unit));
        strike({damage:actor.magic*1.85,magic:true,ignoreDefense:.3});
        if(other)deliver(other,{damage:actor.magic*.75,magic:true});
        return true;
      }
      case 'ashisogi':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+9000;
        if(!launch)target.weakenUntil=Math.max(target.weakenUntil,this.time+4000);
        return strike({damage:actor.magic*1.3,magic:true});
      case 'metralleta':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+9000;
        for(let i=0;i<3&&this.alive(actor)&&this.present(target);i++)strike({damage:actor.magic*.6,magic:true});
        return true;
      case 'shunko':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+12000;
        actor.evade++;
        return strike({damage:actor.attack*1.4});
      case 'excalibur':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+7000;
        return strike({damage:actor.attack*1.45,ignoreDefense:.35});
      case 'piccolo':
      case 'ward': {
        if (actor.skillReady > this.time) return false;
        actor.skillReady = this.time + 10000;
        actor.intercept = 1;
        actor.protectUntil = this.time + 4500;
        actor.shield = Math.max(actor.shield,actor.magic * 1.1);
        this.record('protege',actor);
        return true;
      }
      case 'bulma':
      case 'heal': {
        if (actor.skillReady > this.time) return false;
        const ally = this.teams[actor.side].filter(u=>this.present(u)).sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp)[0];
        if (!ally || ally.hp/ally.maxHp > .95) return false;
        actor.skillReady = this.time + 7000;
        if (type === 'heal') this.heal(ally,actor.magic * 1.3);
        else { ally.shield=Math.max(ally.shield,actor.magic*2);this.record('protege',actor,ally); }
        return true;
      }
      case 'yamcha':
      case 'kuririn':
      case 'rush':
      case 'beam': {
        if (actor.skillReady > this.time) return false;
        const magic = ['kuririn','beam'].includes(type);
        const victim = type === 'kuririn' ? this.teams[target.side].filter(u=>this.present(u)).sort((a,b)=>a.hp-b.hp)[0] : target;
        actor.skillReady = this.time + (magic ? 7000 : 6000);
        return deliver(victim,{ damage: magic ? actor.magic*1.65 : actor.attack*1.6, magic });
      }
      case 'freeza-boss':
      case 'ginyu': {
        if (actor.skillReady > this.time) return false;
        actor.skillReady = this.time + 12000;
        const anchor = this.teams[target.side].filter(u=>this.present(u)).sort((a,b)=>b.hp-a.hp)[0];
        const victims = this.teams[target.side].filter(u=>this.present(u)&&distance(u,anchor)<=28);
        this.record('onda',actor,anchor,{ targets: victims.map(u=>u.id) });
        for (const victim of victims) deliver(victim,{damage:actor.magic * (type === 'freeza-boss' ? .82 : .7),magic:true,area:true});
        return true;
      }
      case 'beerus': {
        if (role === 'principal' && actor.skillReady > this.time) return false;
        if (role === 'principal') actor.skillReady = this.time + 9000;
        return strike({ damage: actor.magic * (role === 'reserva' ? 1.25 : 2.4), magic: true, removeShield: true, blockRevive: role !== 'reserva' });
      }
      case 'zoro': return strike({ damage: actor.attack * 1.1, shieldMultiplier: 2 });
      case 'barba-branca': return strike({ damage: actor.attack * 1.35, removeShield: true, delayOnBreak: 1000 });
      case 'polnareff': {
        if (role === 'reserva') return strike({ damage: actor.attack, shieldMultiplier: 2 });
        for (let i=0; i<3 && this.alive(actor) && this.present(target); i++) {
          strike({ damage: actor.attack * (i === 2 && !target.shield ? .75 : .45), shieldMultiplier: i === 2 ? 2 : 1 });
        }
        return true;
      }
      case 'tetsuo': {
        const boosted = (this.active(actor.side)?.resistedUntil ?? 0) > this.time;
        return strike({ damage: actor.magic * (boosted ? 1.65 : 1.1), magic: true, removeShield: boosted });
      }
      case 'kaguya': {
        if (actor.uses >= 2 || actor.skillReady > this.time) return false;
        actor.uses++;
        actor.skillReady = this.time + 12000;
        this.teams[target.side].filter(u=>this.alive(u)).forEach(u=>{u.weakenUntil = this.time + 4000;});
        this.teams[actor.side].filter(u=>this.alive(u)).forEach(u=>{u.powerUntil = this.time + 4000;});
        this.record('dimensão', actor, target);
        return true;
      }
      case 'saitama': {
        if (actor.uses >= 2 || actor.skillReady > this.time || target.actions - (actor.seenId === target.id ? actor.seenActions : 0) < 3) return false;
        actor.uses++;
        actor.skillReady = this.time + 10000;
        actor.seenId = target.id;
        actor.seenActions = target.actions;
        return strike({ damage: actor.attack * 2.8, removeShield: true, ignoreDefense: .5 });
      }
      default: return false;
    }
  }

  nextSample() {
    let next = this.limit + SAMPLE_STEP;
    for (const team of this.teams) {
      const active = this.mode === 'duelo' ? this.active(team[0].side) : null;
      for (const unit of team) {
        if (!this.alive(unit)) continue;
        const reserve = active && unit !== active;
        const ready = reserve ? unit.nextAssist : Math.max(unit.nextBasic, unit.graceUntil);
        const unfrozen = this.freezeOwner === unit ? 0 : (this.freezeUntil ?? 0);
        next = Math.min(next, Math.max(ready, unit.stunUntil ?? 0, unfrozen));
      }
    }
    // Keep the existing 100 ms event grid and never revisit a processed tick.
    return Math.max(this.time + SAMPLE_STEP, Math.ceil(next / SAMPLE_STEP) * SAMPLE_STEP);
  }

  run() {
    for (this.time = SAMPLE_STEP; this.time <= this.limit; this.time = this.nextSample()) {
      if (!this.active(0) || !this.active(1)) break;
      const order = (this.time / SAMPLE_STEP) % 2 ? [0, 1] : [1, 0];
      for (const side of order) {
        const own = this.active(side);
        if (!own) continue;
        for (const actor of this.mode === 'duelo' ? [own] : this.teams[side]) {
          if (actor.nextBasic > this.time || actor.graceUntil > this.time || !this.present(actor) || this.blocked(actor)) continue;
          let target = this.active(1-side);
          if (this.mode === 'equipe' && target) {
            for (const enemy of this.teams[1-side])
              if (this.alive(enemy) && (enemy.x ?? -enemy.slot) > (target.x ?? -target.slot)) target = enemy;
          }
          if (!target) continue;
          this.beginAttack(actor);
          actor.nextBasic = this.time + actor.interval*this.pace(actor);
          actor.actions++;
          if (!this.use(actor, target, actor.kind) || MAIN_SKILLS.has(actor.kind) && ['piccolo','ward','bulma','heal'].includes(actor.kind)) this.hit(actor, target, { skill: false, damage: actor.magicBasic ? actor.magic : actor.attack, magic: !!actor.magicBasic });
        }
        if (this.mode === 'duelo') for (const reserve of this.teams[side]) {
          const ally = this.active(side);
          const target = this.active(1-side);
          if (!ally || !target || !this.alive(reserve) || reserve === ally || this.blocked(reserve) || reserve.nextAssist > this.time) continue;
          reserve.nextAssist = this.time + 7000;
          if (reserve.healer) this.heal(ally, reserve.healer);
          else if (reserve.assist) this.use(reserve, target, reserve.assist, 'reserva');
        }
      }
      if (!this.active(0) || !this.active(1)) break;
    }
    const live = this.teams.map(t=>t.some(u=>this.alive(u)));
    const scores = this.teams.map(t=>sum(t.map(u=>u.hp/u.maxHp))/t.length);
    const timeout = live.every(Boolean);
    const scoreDiff = scores[0]-scores[1];
    const winner = timeout ? (Math.abs(scoreDiff)<HP_EPSILON ? null : scoreDiff>0?0:1) : live[0]===live[1]?null:live[0]?0:1;
    return { winner, seconds: Math.min(this.time,this.limit)/1000, reason: timeout?'limite':'eliminação', scores, events: this.log };
  }
}


return {affinity,Combate};
})();
const communityRules=(()=>{

// A daily period is keyed by the local calendar date on which its noon began.
const DAILY_ZONE='America/Sao_Paulo';
const GIFT_GOLD=10;
const PROFILE_OPTIONS={
  background:{hoova:'Hoova · Floresta do Susanoo',zawa:'Zawa · Pátio do Demônio Celestial',careca:'Careca · Página apagada',namek:'Namek · Dragon Ball',arlong:'Arlong Park · One Piece',konoha:'Konoha · Naruto',
    seireitei:'Seireitei · Bleach',shibuya:'Shibuya · Jujutsu Kaisen',clover:'Reino Clover · Black Clover',
    britannia:'Britannia · Nanatsu no Taizai',morioh:'Morioh · JoJo',heavens:'Heavens Arena · Hunter × Hunter',
    cidadez:'Cidade Z · One Punch Man',noite:'Noite violeta',aurora:'Aurora turquesa'},
  icon:{estrela:'Estrela',cometa:'Cometa',escudo:'Escudo'},
  border:{menta:'Menta',violeta:'Violeta',ouro:'Ouro'},
};
const DEFAULT_PROFILE={background:'namek',icon:'estrela',border:'menta'};
const PROFILE_WORLDS={namek:0,arlong:1,konoha:2,seireitei:3,shibuya:4,clover:5,britannia:6,morioh:7,heavens:8,cidadez:9};
const AVATAR_SIZE=128;
const PROFILE_BODY_LIMIT=100*1024;

// The browser sends only its square canvas export, never a remote image URL.
function validAvatar(value){
  const prefix='data:image/png;base64,';
  if(typeof value!=='string'||value.length>98000||!value.startsWith(prefix))return false;
  const encoded=value.slice(prefix.length);
  if(encoded.length%4!==0||!/^[A-Za-z0-9+/]+={0,2}$/.test(encoded))return false;
  const bytes=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0));
  const signature=[137,80,78,71,13,10,26,10];
  if(bytes.length<57||!signature.every((b,i)=>bytes[i]===b))return false;
  const view=new DataView(bytes.buffer);
  let hasData=false;
  for(let pos=8;pos+12<=bytes.length;){
    const length=view.getUint32(pos);
    const kind=String.fromCharCode(...bytes.subarray(pos+4,pos+8));
    const end=pos+12+length;
    if(end>bytes.length)return false;
    if(pos===8){
      if(kind!=='IHDR'||length!==13||view.getUint32(16)!==AVATAR_SIZE||view.getUint32(20)!==AVATAR_SIZE||
          bytes[24]!==8||![2,6].includes(bytes[25])||bytes[26]||bytes[27]||bytes[28])return false;
    }else if(kind==='IDAT')hasData ||= length>0;
    else if(kind==='IEND')return hasData&&length===0&&end===bytes.length;
    else if(!['sRGB','pHYs','cHRM','gAMA','iCCP','sBIT','cICP'].includes(kind))return false;
    pos=end;
  }
  return false;
}
function canEquipBackground(key,code){
  const owners={hoova:'0DA6605BD4',zawa:'89B75CB773',careca:'4A6913795B'};
  return !Object.hasOwn(owners,key)||owners[key]===code;
}
function appearancePatch(input,code){
  if(!canEquipBackground(input?.background,code))throw Error('Este fundo pertence a outro jogador.');
  const patch={};
  for(const key of Object.keys(DEFAULT_PROFILE)){
    if(typeof input?.[key]!=='string'||!Object.hasOwn(PROFILE_OPTIONS[key],input[key]))throw Error('Escolha as opções de aparência do perfil.');
    patch[key]=input[key];
  }
  if(Object.hasOwn(input,'avatar')){
    if(input.avatar!==null&&!validAvatar(input.avatar))throw Error('A foto precisa ser uma imagem válida. Escolha o arquivo novamente.');
    patch.avatar=input.avatar;
  }
  return patch;
}
const localParts=new Intl.DateTimeFormat('en-GB',{
  timeZone:DAILY_ZONE,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',
  minute:'2-digit',second:'2-digit',hourCycle:'h23',
});
function localFields(time){
  return Object.fromEntries(localParts.formatToParts(time).filter(p=>p.type!=='literal').map(p=>[p.type,Number(p.value)]));
}
function localNoon(plainDate){
  const desired=plainDate+12*3600000;
  let time=desired;
  for(let attempt=0;attempt<3;attempt++){
    const f=localFields(time);
    const actual=Date.UTC(f.year,f.month-1,f.day,f.hour,f.minute,f.second);
    if(actual===desired)return time;
    time+=desired-actual;
  }
  return time;
}
function dailyCycle(now=Date.now()){
  const f=localFields(now);
  const today=Date.UTC(f.year,f.month-1,f.day);
  const startDate=today-(f.hour<12?86400000:0);
  return {day:new Date(startDate).toISOString().slice(0,10),nextAt:localNoon(startDate+86400000)};
}

function rarityLabel(odds){
  const format=new Intl.NumberFormat('pt-BR',{maximumFractionDigits:2});
  for(const [divisor,suffix] of [[1e9,'B'],[1e6,'M'],[1e3,' mil']]){
    if(odds>=divisor)return '1/'+format.format(odds/divisor)+suffix;
  }
  return '1/'+format.format(odds);
}

return {DAILY_ZONE,GIFT_GOLD,PROFILE_OPTIONS,DEFAULT_PROFILE,PROFILE_WORLDS,AVATAR_SIZE,PROFILE_BODY_LIMIT,appearancePatch,dailyCycle,rarityLabel};
})();
const duelEngine=(()=>{
function hasTrait(unit,name){return unit.traits?.includes(name)||unit.trait===name;}
const DEFAULT_LIMIT = 60000;
const SAMPLE_STEP = 100;
const HP_EPSILON = 1e-8;
const sum = values => values.reduce((a, b) => a + b, 0);
const COLORS = ['Vermelho','Laranja','Amarelo','Verde','Turquesa','Azul','Roxo','Rosa'];
function affinity(a, b) {
  if (!a || !b) return 1;
  if (a === 'Dourado') return b === a ? 2 : 1.5;
  if ((a === 'Branco' || a === 'Preto') && a === b) return 1.5;
  const position = COLORS.indexOf(a);
  if (position < 0) return 1;
  return b === COLORS[(position + 1) % 8] ? 1.5 : b === COLORS[(position + 7) % 8] ? .75 : 1;
}
const distance = (a, b) => Math.hypot((a.x ?? a.slot * 20) - (b.x ?? b.slot * 20), (a.y ?? 50) - (b.y ?? 50));
const MAIN_SKILLS = new Set(['piccolo','yamcha','kuririn','bulma','freeza-boss','ginyu','beam','rush','ward','heal']);

class Combate {
  constructor(rosters, { mode = 'duelo', limit = DEFAULT_LIMIT } = {}) {
    if (!['duelo', 'equipe'].includes(mode) || !Number.isInteger(limit) || limit < SAMPLE_STEP || limit > DEFAULT_LIMIT || rosters.length !== 2 || rosters.some(team => !team.length || team.length > 4)) {
      throw new RangeError('Configuração de combate inválida.');
    }
    this.mode = mode;
    this.limit = limit;
    this.time = 0;
    this.teams = rosters.map((team, side) => team.map((spec, slot) => ({
      ...spec, side, slot, id: `${side}:${slot}`, name: spec.name ?? `${side}:${slot}`,
      hp: spec.hp ?? 1000, maxHp: spec.hp ?? 1000, attack: spec.attack ?? 100, magic: spec.magic ?? 100,
      defense: spec.defense ?? 0, resistance: spec.resistance ?? 0, shield: spec.shield ?? 0,
      interval: Math.max(SAMPLE_STEP, spec.interval ?? 3000), nextBasic: Math.max(SAMPLE_STEP, spec.interval ?? 3000),
      nextAssist: 5000, evade: spec.evade ?? 0, intercept: spec.intercept ?? 0, survive: spec.survive ?? 0, protectUntil: spec.intercept ? Infinity : 0,
      revive: spec.revive ?? 0, vector: spec.kind === 'accelerator' ? 2 : 0, vectorReady: 0,
      uses: 0, skillReady: 0, actions: 0, seenId: null, seenActions: 0, graceUntil: 0,
      weakenUntil: 0, powerUntil: 0, resistedUntil: 0,
    })));
    this.log = [];
    this.hasteUntil=[0,0];
    for(const team of this.teams){
      const king=team.find(u=>hasTrait(u,'Haki do Rei'));
      if(king)for(const foe of this.teams[1-king.side]){
        applyNegative(foe,'stunUntil',2000);applyNegative(foe,'exposedUntil',2000);
      }
    }
  }

  record(type, actor, target, data = {}) {
    this.log.push({ time: this.time, type, actor: actor?.id, target: target?.id, ...data });
  }

  alive(u) { return u.hp > HP_EPSILON; }
  active(side) { return this.teams[side].find(u => this.alive(u)); }
  present(u) { return this.alive(u) && (this.mode === 'equipe' || this.active(u.side) === u); }

  blocked(u){return u.stunUntil>this.time||(this.freezeUntil>this.time&&this.freezeOwner!==u);}
  pace(u){
    if(u.hasteUntil>this.time)return .2;
    return this.hasteUntil[u.side]>this.time?.6:1;
  }
  beginAttack(u){
    if(!hasTrait(u,'Made in Heaven')||u.heavenUsed)return;
    const team=this.teams[u.side],before=team.map(f=>this.pace(f));
    u.heavenUsed=true;u.hasteUntil=this.time+5000;this.hasteUntil[u.side]=this.time+5000;
    team.forEach((f,i)=>{
      const ratio=this.pace(f)/before[i];
      if(f.nextBasic>this.time)f.nextBasic=this.time+(f.nextBasic-this.time)*ratio;
      if(f.ready>this.time/1000)f.ready=this.time/1000+(f.ready-this.time/1000)*ratio;
    });
    this.record('aceleração',u);
  }
  outgoingPower(source,damage,basic=false){
    const trait=Math.max(1,(hasTrait(source,'Made in Heaven')?4:0)+(source.nen?4:0));
    return damage*trait*(basic&&source.weakenUntil>this.time?.65:1);
  }

  hit(source, target, attack = {}) {
    const { damage = source.attack, magic = false, skill = true, area = false, reflected = false,
      removeShield = false, shieldMultiplier = 1, ignoreDefense = 0, blockRevive = false, delayOnBreak = 0 } = attack;
    if (!this.alive(source) || !this.present(target) || source.side === target.side) return false;
    if (!Number.isFinite(damage) || damage < 0 || !Number.isFinite(shieldMultiplier) || shieldMultiplier < 1) throw new RangeError('Dano ou multiplicador inválido.');
    if(!reflected)this.beginAttack(source);
    let victim = target,interceptFactor=1;
    if(!area&&!reflected){
      const guard=this.teams[target.side].find(u=>u!==target&&hasTrait(u,'Restrição Celestial')&&!this.blocked(u)&&this.alive(u)&&(u.guardUses??0)<2&&(this.mode==='duelo'||distance(u,target)<=30));
      if(guard){guard.guardUses=(guard.guardUses??0)+1;victim=guard;interceptFactor=.5;this.record('intercepta',guard,target);}
    }
    if (victim===target && !area && !reflected && this.mode === 'equipe') {
      const guard = this.teams[target.side].find(u => u !== target && !this.blocked(u) && this.alive(u) && u.intercept > 0 && u.protectUntil >= this.time && distance(u,target) <= 30);
      if (guard) {
        guard.intercept--;
        victim = guard;
        this.record('intercepta', guard, target);
      }
    }
    if(!area && victim.portalDodge){
      victim.portalDodge=false;this.record('portal',victim,source);return false;
    }
    if(!area && victim.kind==='dominio' && !victim.infinityUsed){
      victim.infinityUsed=true;this.record('ilimitado',victim,source);return false;
    }
    if(!area && victim.kind==='instinto' && victim.stanceUntil>this.time){
      this.record('instintiva',victim,source);return false;
    }
    if (!area && !reflected && victim.evade > 0) {
      victim.evade--;
      this.record('esquiva', victim, source);
      if(hasTrait(victim,'Instinto Superior')&&!attack.counter&&!this.blocked(victim)&&this.present(source))this.hit(victim,source,{skill:false,counter:true,magic:!!victim.magicBasic,damage:victim.magicBasic?victim.magic:victim.attack});
      return true;
    }
    if(!area&&!reflected&&skill&&hasTrait(victim,'Haki da Observação')&&(victim.observeUses??0)<2&&!this.blocked(victim)&&this.present(source)){
      victim.observeUses=(victim.observeUses??0)+1;
      this.hit(victim,source,{skill:false,counter:true,damage:2*(victim.magicBasic?victim.magic:victim.attack),magic:!!victim.magicBasic});
      if(!this.alive(source))return true;
    }
    if (!area && !reflected && skill) {
      const mirror=magic&&this.teams[victim.side].find(u=>hasTrait(u,'Full Counter')&&!u.mirrorUsed&&this.alive(u)&&!this.blocked(u)&&(u===victim||this.mode==='duelo'||distance(u,victim)<=30));
      if(mirror){
        mirror.mirrorUsed=true;this.record('reflete',mirror,source);
        this.hit(mirror,this.present(source)?source:this.active(source.side),{...attack,damage:damage*2,reflected:true});
        return true;
      }
      const vector = this.teams[victim.side].find(u => this.alive(u) && u.vector > 0 && u.vectorReady <= this.time && (this.mode === 'duelo' || Math.abs(u.slot - victim.slot) <= 1));
      if (vector) {
        vector.vector--;
        vector.vectorReady = this.time + 8000;
        this.record('especial',vector,source,{name:vector.skill??'Controle Vetorial',role:'reação'});
        this.record('reflete', vector, source, { remaining: vector.vector });
        const returnTarget = this.present(source) ? source : this.active(source.side);
        if (returnTarget) this.hit(vector, returnTarget, { ...attack, damage, reflected: true });
        return true;
      }
    }
    const openPower = skill && !reflected && source.powerUntil > this.time;
    if (openPower) source.powerUntil = 0;
    const mitigation = (magic ? victim.resistance : victim.defense) * (1 - ignoreDefense);
    let value = this.outgoingPower(source,damage,!skill) * interceptFactor * (victim.exposedUntil>this.time?1.3:1) * affinity(source.color,victim.color) * (openPower ? 1.3 : 1) * 40 / (40 + mitigation/(source.scale || 1));
    const element=magic?'magico':'fisico';
    source.lastDamageType=element;
    if(victim.kind==='meruem_rei'){
      const learned=victim.learned??=new Set();
      if(learned.has(element))value*=.72;
      else learned.add(element);
      this.record('carapaca',victim,source);
    }
    if(victim.adaptiveUntil>this.time&&victim.adaptiveType===element)value*=.72;
    if(magic&&skill&&victim.moonGuard){
      victim.moonGuard=false;this.record('lunar',victim,source);return false;
    }
    if(magic && victim.moonShield>0){
      const spent=Math.min(victim.moonShield,value);victim.moonShield-=spent;value-=spent;
      this.record('lunar',victim,source);
    }
    if(source.kotoUntil>this.time && (skill || true)){
      source.kotoUntil=0;
      value*=.60;
    }
    if(attack.koto)victim.kotoUntil=this.time+4000;
    if(victim.fictionUntil>this.time){
      value-=Math.min(value,victim.fictionWard);
      victim.fictionUntil=0;
      this.record('apaga',victim,source);
    }
    const available=removeShield||attack.pierceFirst?0:victim.shield/shieldMultiplier;
    if(skill && value-available>=victim.hp && (victim.zeroGuard||this.active(victim.side)?.kind==='giorno') && !this.zeroUsed?.[victim.side]){
      const main=this.active(victim.side)?.kind==='giorno';
      (this.zeroUsed??={})[victim.side]=true;victim.zeroGuard=false;
      if(main){this.heal(victim,victim.maxHp*.25);source.loseAction=true}
      this.record('zero',victim,source,{main});return false;
    }
    const priorShield = victim.shield;
    if (removeShield) victim.shield = 0;
    const absorbed = attack.pierceFirst ? 0 : Math.min(victim.shield, value * shieldMultiplier);
    victim.shield -= absorbed;
    value -= absorbed / shieldMultiplier;
    if (priorShield > 0 && victim.shield <= HP_EPSILON) {
      victim.shield = 0;
      victim.nextBasic += delayOnBreak;
      this.record('escudo rompe', source, victim);
    }
    const actual = Math.min(victim.hp, value);
    victim.hp = Math.max(0, victim.hp - value);
    if(actual>0){
      if(skill&&!attack.reflected){
        const key=dotKinds[source.characterId];
        if(key)applyDot({t:this.time/1000},source,victim,key,Math.min(victim.maxHp*.025,Math.max(source.attack,source.magic)*.2),.6,5);
      }
      if(victim.kind==='meliodas_v')victim.demonCharge=(victim.demonCharge??0)+actual;
      victim.recentImpact=(victim.recentImpact??[]).filter(e=>this.time-e.t<=4000);
      victim.recentImpact.push({t:this.time,n:actual});
      if(attack.crack)applyNegative(victim,'crackedShield',true);
    }
    this.record('dano', source, victim, { hp: actual, reflected, remaining: victim.hp, skill });
    if(!this.alive(victim)&&victim.timeMark?.until>this.time){
      const mark=victim.timeMark;victim.timeMark=null;victim.hp=mark.hp;
      if(mark.main){victim.skillReady=this.time;victim.ready=this.time/1000;mark.owner.timeSpent=true}
      this.record('reverte',victim,source);return true;
    }
    if(!this.alive(victim)){
      const main=!!(victim.kind==='yhwach'&&!victim.almightySpent);
      if(main||victim.futureUntil>this.time){
        victim.futureUntil=0;victim.hp=victim.maxHp*(main?.35:.20);
        if(main){victim.almightySpent=true;victim.skillReady=this.time;victim.ready=this.time/1000}
        this.record('futuro',victim,source);return true;
      }
      const madoka=this.teams[victim.side].find(u=>u.kind==='madoka' && (u===victim||this.present(u)));
      if(!blockRevive && madoka && !madoka.cycleSpent && negativeKeys(victim,this.time).length){
        madoka.cycleSpent=true;cleanse(victim,this.time,false);victim.hp=victim.maxHp*.35;
        this.record('ciclos',victim,source);return true;
      }
    }
    if (!this.alive(victim)) this.defeat(victim, source, blockRevive);
    return true;
  }

  defeat(victim, source, blockRevive) {
    if (victim.survive > 0) {
      victim.survive--;
      if(hasTrait(victim,"Zenkai")){victim.attack*=1.75;victim.magic*=1.75;}
      victim.hp = victim.maxHp * .4;
      this.record('sobrevive', victim, source, { remaining: victim.hp });
    } else if (victim.revive > 0 && !blockRevive) {
      victim.revive--;
      victim.hp = victim.maxHp * .7;
      this.record('ressurge', victim, source, { remaining: victim.hp });
    } else {
      victim.hp = 0;
      victim.shield = 0;
      const successor = this.mode === 'duelo' ? this.active(victim.side) : null;
      this.record('cai', victim, source);
      if(source?.kind==='rei'&&!source.kingAdvance){
        source.kingAdvance=true;
        source.skillReady=Math.max(this.time,source.skillReady-3000);
        source.ready=Math.min(source.ready,source.skillReady/1000);
      }
      if (successor) {
        successor.nextBasic = this.time + successor.interval;
        successor.graceUntil = this.time + SAMPLE_STEP;
        this.record('entra', successor);
      }
    }
  }

  heal(unit, amount) {
    if (!this.alive(unit)) return;
    unit.hp = Math.min(unit.maxHp, unit.hp + amount);
    this.record('cura', unit, undefined, { remaining: unit.hp });
  }

  use(actor,target,type,role='principal',launch){
    const used=this.cast(actor,target,type,role,launch);
    if(used&&actor.skill)this.record('especial',actor,target,{name:actor.skill,role});
    if(used&&role==='principal'&&hasTrait(actor,'The World')&&!actor.worldUsed){
      actor.worldUsed=true;this.freezeOwner=actor;this.freezeUntil=this.time+3000;
      actor.skillReady=0;actor.nextBasic=Math.min(actor.nextBasic,this.time+SAMPLE_STEP);
      actor.ready=this.time/1000;this.record('tempo parado',actor);
    }
    return used;
  }
  cast(actor, target, type, role = 'principal', launch) {
    if (!this.alive(actor) || !this.present(target)) return false;
    const deliver = launch ?? ((victim,options)=>this.hit(actor,victim,options));
    const strike = options => deliver(target,options);
    if(role==='reserva'){
      const active=this.active(actor.side);
      if(type==='reescrita'){
        if(!active||active.hp>active.maxHp*.4)return false;
        this.heal(active,active.maxHp*.30);return true;
      }
      if(type==='kaguya'){
        if(!active||active.portalDodge)return false;
        active.portalDodge=true;return true;
      }
      if(type==='tremor')return strike({area:true,damage:actor.attack*1.35,removeShield:true,delayOnBreak:1000});
    }
    switch (type) {
      case 'rei':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+8000;
        return strike({damage:actor.attack,magic:false,pierceFirst:true});
      case 'koto':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+8000;
        return strike({magic:true,koto:true,damage:actor.magic*1.75});
      case 'demonSword':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+7000;
        strike({damage:actor.attack*.7,bladeIndex:0});
        return strike({damage:actor.attack*.7,bladeIndex:1});
      case 'fiction': {
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+10000;
        const ally=this.active(actor.side);
        ally.fictionUntil=this.time+4000;ally.fictionWard=actor.magic*1.8;
        this.record('protege',actor,ally);
        return strike({magic:true,damage:actor.magic*1.3});
      }
      case 'room':
      case 'benihime': {
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+8000;
        const ally=this.teams[actor.side].filter(u=>this.present(u))
          .reduce((lowest,u)=>u.hp/u.maxHp<lowest.hp/lowest.maxHp?u:lowest);
        if(type==='room'){
          this.heal(ally,1.5*actor.magic);
          return strike({magic:true,damage:1.35*actor.magic,ignoreDefense:.4});
        }
        grantShield(ally,2.2*actor.magic);
        this.record('protege',actor,ally);
        return strike({magic:true,damage:1.05*actor.magic});
      }
      case 'barreira':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+9000;
        for(const ally of this.teams[actor.side].filter(u=>this.present(u))){
          grantShield(ally,actor.defense*(ally===actor?1.8:1));
          this.record('protege',actor,ally);
        }
        return true;
      case 'death_ray':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+7000;
        return strike({magic:true,damage:actor.magic*(target.hp<target.maxHp*.35?2.35:1.75),ignoreDefense:.25});
      case 'final_flash':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+8000;
        return strike({damage:actor.attack*2.15,shieldMultiplier:2});
      case 'furia':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+6000;
        return strike({damage:actor.attack*(1.65+.25*Math.min(actor.uses++,3))});
      case 'santuario':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+10000;
        return strike({area:true,magic:true,damage:actor.magic*.45,shieldMultiplier:2});
      case 'instinto':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+8000;actor.stanceUntil=this.time+2000;
        return true;
      case 'bodisatva': {
        if(actor.skillReady>this.time)return false;
        const instinct=type==='instinto';
        actor.skillReady=this.time+(instinct?8000:7000);
        if(instinct)actor.evade=Math.max(actor.evade,1);
        for(let i=0;i<(instinct?2:3)&&this.alive(actor)&&this.present(target);i++)
          strike({damage:actor.attack*(instinct?1:.65),ignoreDefense:i===2?.5:0});
        return true;
      }
      case 'dominio':
      case 'despertar': {
        if(actor.skillReady>this.time)return false;
        const domain=type==='dominio';
        actor.skillReady=this.time+(domain?12000:9000);
        const damage=actor.magic*(domain?1.55:actor.hp<=actor.maxHp*.5?2.25:1.65);
        for(const foe of this.teams[target.side].filter(u=>this.present(u))){
          deliver(foe,{magic:true,area:true,damage});
          if(domain&&!launch)applyNegative(foe,'stunUntil',Math.max(foe.stunUntil??0,this.time+1500));
        }
        return true;
      }
      case 'reescrita':
      case 'ciclo_vital': {
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+9000;
        const ally=this.teams[actor.side].filter(unit=>this.present(unit))
          .reduce((lowest,unit)=>unit.hp/unit.maxHp<lowest.hp/lowest.maxHp?unit:lowest);
        if(type==='ciclo_vital'){
          this.heal(ally,actor.magic*2);
          return strike({damage:actor.magic*1.05,magic:true});
        }
        if(actor.uses===0&&ally.hp<=ally.maxHp*.4){
          actor.uses++;
          this.heal(ally,ally.maxHp*.5);
          return true;
        }
        return strike({damage:actor.attack*1.9});
      }
      case 'nichirin': {
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+10000;
        const victims=this.teams[target.side].filter(unit=>this.present(unit)&&distance(unit,target)<=28);
        this.record('onda',actor,target,{targets:victims.map(unit=>unit.id)});
        for(const unit of victims)deliver(unit,{damage:actor.attack*(unit===target?1.8:.85),area:true});
        return true;
      }
      case 'tempestade': {
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+10000;
        const other=this.teams[target.side].find(unit=>unit!==target&&this.present(unit));
        strike({damage:actor.magic*1.85,magic:true,ignoreDefense:.3});
        if(other)deliver(other,{damage:actor.magic*.75,magic:true});
        return true;
      }
      case 'ashisogi':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+9000;
        if(!launch)applyNegative(target,'weakenUntil',Math.max(target.weakenUntil,this.time+4000));
        return strike({damage:actor.magic*1.3,magic:true});
      case 'metralleta':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+9000;
        for(let i=0;i<3&&this.alive(actor)&&this.present(target);i++)strike({damage:actor.magic*.6,magic:true});
        return true;
      case 'shunko':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+12000;
        actor.evade++;
        return strike({damage:actor.attack*1.4});
      case 'excalibur':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+7000;
        return strike({damage:actor.attack*1.45,ignoreDefense:.35});
      case 'piccolo':
      case 'ward': {
        if (actor.skillReady > this.time) return false;
        actor.skillReady = this.time + 10000;
        actor.intercept = 1;
        actor.protectUntil = this.time + 4500;
        grantShield(actor,actor.magic * 1.1);
        this.record('protege',actor);
        return true;
      }
      case 'bulma':
      case 'heal': {
        if (actor.skillReady > this.time) return false;
        const ally = this.teams[actor.side].filter(u=>this.present(u)).sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp)[0];
        if (!ally || ally.hp/ally.maxHp > .95) return false;
        actor.skillReady = this.time + 7000;
        if (type === 'heal') this.heal(ally,actor.magic * 1.3);
        else { grantShield(ally,actor.magic*2);this.record('protege',actor,ally); }
        return true;
      }
      case 'yamcha':
      case 'kuririn':
      case 'rush':
      case 'beam': {
        if (actor.skillReady > this.time) return false;
        const magic = ['kuririn','beam'].includes(type);
        const victim = type === 'kuririn' ? this.teams[target.side].filter(u=>this.present(u)).sort((a,b)=>a.hp-b.hp)[0] : target;
        actor.skillReady = this.time + (magic ? 7000 : 6000);
        return deliver(victim,{ damage: magic ? actor.magic*1.65 : actor.attack*1.6, magic });
      }
      case 'freeza-boss':
      case 'ginyu': {
        if (actor.skillReady > this.time) return false;
        actor.skillReady = this.time + 12000;
        const anchor = this.teams[target.side].filter(u=>this.present(u)).sort((a,b)=>b.hp-a.hp)[0];
        const victims = this.teams[target.side].filter(u=>this.present(u)&&distance(u,anchor)<=28);
        this.record('onda',actor,anchor,{ targets: victims.map(u=>u.id) });
        for (const victim of victims) deliver(victim,{damage:actor.magic * (type === 'freeza-boss' ? .82 : .7),magic:true,area:true});
        return true;
      }
      case 'beerus': {
        if (role === 'principal' && actor.skillReady > this.time) return false;
        if (role === 'principal') actor.skillReady = this.time + 9000;
        return strike({ damage: actor.magic * (role === 'reserva' ? 1.25 : 2.4), magic: true, removeShield: true, blockRevive: role !== 'reserva' });
      }
      case 'zoro': return strike({ damage: actor.attack * 1.1, shieldMultiplier: 2 });
      case 'tremor':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+8000;
        return strike({damage:actor.attack*1.35,area:true});
      case 'barba-branca': return strike({ damage: actor.attack * 1.35, removeShield: true, delayOnBreak: 1000 });
      case 'polnareff': {
        if (role === 'reserva') return strike({ damage: actor.attack, shieldMultiplier: 2 });
        for (let i=0; i<3 && this.alive(actor) && this.present(target); i++) {
          strike({ damage: actor.attack * (i === 2 && !target.shield ? .75 : .45), shieldMultiplier: i === 2 ? 2 : 1 });
        }
        return true;
      }
      case 'tetsuo': {
        const boosted = (this.active(actor.side)?.resistedUntil ?? 0) > this.time;
        return strike({ damage: actor.magic * (boosted ? 1.65 : 1.1), magic: true, removeShield: boosted });
      }
      case 'kaguya': {
        if (actor.uses >= 2 || actor.skillReady > this.time) return false;
        actor.uses++;
        actor.skillReady = this.time + 12000;
        this.teams[target.side].filter(u=>this.alive(u)).forEach(u=>{applyNegative(u,'weakenUntil',this.time + 4000);});
        this.teams[actor.side].filter(u=>this.alive(u)).forEach(u=>{u.powerUntil = this.time + 4000;});
        this.record('dimensão', actor, target);
        return true;
      }
      case 'saitama': {
        if (actor.uses >= 2 || actor.skillReady > this.time || target.actions - (actor.seenId === target.id ? actor.seenActions : 0) < 3) return false;
        actor.uses++;
        actor.skillReady = this.time + 10000;
        actor.seenId = target.id;
        actor.seenActions = target.actions;
        return strike({ damage: actor.attack * 2.8, removeShield: true, ignoreDefense: .5 });
      }
      default: return false;
    }
  }

  run() {
    for (this.time = SAMPLE_STEP; this.time <= this.limit; this.time += SAMPLE_STEP) {
      if (!this.active(0) || !this.active(1)) break;
      const order = [0, 1].sort((a,b) => (this.time / SAMPLE_STEP) % 2 ? a-b : b-a);
      for (const side of order) {
        const own = this.active(side);
        if (!own) continue;
        for (const actor of this.mode === 'duelo' ? [own] : this.teams[side]) {
          const target = this.mode === 'equipe' ? this.teams[1-side].filter(u=>this.present(u)).sort((a,b)=>(b.x??-b.slot)-(a.x??-a.slot))[0] : this.active(1-side);
          if (!target || !this.present(actor) || actor.nextBasic > this.time || actor.graceUntil > this.time) continue;
          if(this.blocked(actor))continue;
          this.beginAttack(actor);
          actor.nextBasic = this.time + actor.interval*this.pace(actor);
          actor.actions++;
          if (!this.use(actor, target, actor.kind) || MAIN_SKILLS.has(actor.kind) && ['piccolo','ward','bulma','heal'].includes(actor.kind)) this.hit(actor, target, { skill: false, damage: actor.magicBasic ? actor.magic : actor.attack, magic: !!actor.magicBasic });
        }
        if (this.mode === 'duelo') for (const reserve of this.teams[side]) {
          const ally = this.active(side);
          const target = this.active(1-side);
          if (!ally || !target || !this.alive(reserve) || reserve === ally || this.blocked(reserve) || reserve.nextAssist > this.time) continue;
          reserve.nextAssist = this.time + 7000;
          if (reserve.healer) this.heal(ally, reserve.healer);
          else if (reserve.assist) this.use(reserve, target, reserve.assist, 'reserva');
        }
      }
      if (!this.active(0) || !this.active(1)) break;
    }
    const live = this.teams.map(t=>t.some(u=>this.alive(u)));
    const scores = this.teams.map(t=>sum(t.map(u=>u.hp/u.maxHp))/t.length);
    const timeout = live.every(Boolean);
    const scoreDiff = scores[0]-scores[1];
    const winner = timeout ? (Math.abs(scoreDiff)<HP_EPSILON ? null : scoreDiff>0?0:1) : live[0]===live[1]?null:live[0]?0:1;
    return { winner, seconds: Math.min(this.time,this.limit)/1000, reason: timeout?'limite':'eliminação', scores, events: this.log };
  }
}



// Fixed-step simulation in a 100 × 50 arena.
const DT=1/60;
function collisionBonus(hits){return Math.min(40,12*hits);}

function rawCollision(f){
  return (f.magicBasic?f.magic:f.attack)*(1+collisionBonus(f.hits)/100);
}
function collisionPower(m,f){
  return m.combat.outgoingPower(f,rawCollision(f),true);
}
const arenaKinds={
  "sukuna-forma-original": "santuario",
  "saitama": "saitama",
  "kaguya-otsutsuki": "kaguya",
  "barba-branca-auge": "tremor",
  "gol-d-roger": "rei",
  "simon-tengen-toppa": "simon",
  "meruem-pos-rosa": "meruem_rei",
  "eternal-sailor-moon": "sailor",
  "lucius-zogratis": "lucius",
  "ultimate-madoka": "madoka",
  "yhwach": "yhwach",
  "giorno-gold-experience-requiem": "giorno",
  "meliodas-magia-verdadeira": "meliodas_v"
};
function arenaUnit(f){return {...f,characterId:f.id,kind:arenaKinds[f.id]??f.kind};}
function createDuel(left,right,limit=120){
  const combat=new Combate([left.map(arenaUnit),right.map(arenaUnit)]);
  const sides=combat.teams.map((team,i)=>({
    team:team.map((f,slot)=>Object.assign(f,{hits:0,ready:2+slot*1.2})),
    slot:0,x:i?80:20,y:i?30:20,vx:i?-26:26,vy:i?-12:12
  }));
  return {combat,sides,limit,skills:[],shots:[],flashes:[],t:0,result:null,events:[],damageFeed:[],contact:0,contacts:0};
}
function note(m,text){m.events.unshift(text);m.events.length=Math.min(5,m.events.length);}
function announce(m,f,name,role){
  const text=f.name+' · '+name+(role==='reserva'?' (assistência)':'');
  m.skills.unshift({side:f.side,slot:f.slot,name,role,text,time:m.t});
  m.skills.length=Math.min(m.skills.length,12);
  note(m,text);
}
function finishDuel(match){
  while(match.result===null)stepDuel(match);
  return match;
}
const R=4, ROOM=18;
function move(s,unit){
  const speed=Math.min(48,26+unit.speed*.065);
  const factor=speed/(Math.hypot(s.vx,s.vy)||1);
  s.vx*=factor;s.vy*=factor;
  s.x+=s.vx*DT;s.y+=s.vy*DT;
  // Reflect the overshoot so distance is conserved at walls and corners.
  if(s.x<R||s.x>100-R){s.x=2*(s.x<R?R:100-R)-s.x;s.vx*=-1;}
  if(s.y<R||s.y>50-R){s.y=2*(s.y<R?R:50-R)-s.y;s.vy*=-1;}
}
const areaSkills=new Set(['dominio','despertar','nichirin','freeza-boss','ginyu']);
const meleeSkills=new Set(['furia','instinto','bodisatva','shunko','excalibur','rush','yamcha','reescrita','benihime']);
function arenaCast(m,f,enemy,role){
  const origin=m.sides[f.side],other=m.sides[1-f.side];
  const swordCombo={triggered:false};
  let shot, ceroIndex=0;
  const launch=(target,attack)=>{
    if(attack.bladeIndex!==undefined){
      const angle=Math.atan2(other.y-origin.y,other.x-origin.x)+(attack.bladeIndex?1:-1)*.055;
      m.shots.push({kind:'blade',f,side:f.side,x:origin.x,y:origin.y,angle,born:m.t,attacks:[attack],radius:2,range:110,speed:88,combo:swordCombo});
      return true;
    }
    if(attack.skill!==false && ['santuario','dominio'].includes(f.kind)){
      if(!shot){
        shot={kind:f.kind,f,side:f.side,born:m.t,x:origin.x,y:origin.y,radius:f.kind==='dominio'?25.5:22,attack,pulse:0};
        m.shots.push(shot);
      }
      return true;
    }
    if(f.kind==='reescrita'&&attack.skill!==false){
      origin.ignition={born:m.t,attack};return true;
    }
    if(attack.skill!==false && f.kind==='beerus'){
      fireBatch(m,f,'beerus_hakai',attack,110,65);
      return true;
    }
    if(f.kind==='tremor'&&attack.area){
      const angle=Math.atan2(other.y-origin.y,other.x-origin.x);
      const q={kind:'tremor',f,side:f.side,x:origin.x+R*Math.cos(angle),y:origin.y+R*Math.sin(angle),born:m.t,angle,attack,struck:new Set(),support:role==='reserva'};
      m.shots.push(q);

      return true;
    }
    if(f.kind==='saitama' && attack.skill!==false){
      fireBatch(m,f,'saitama_soco',attack,30,108);return true;
    }
    if(f.kind==='rei' && attack.pierceFirst){
      origin.dash={angle:Math.atan2(other.y-origin.y,other.x-origin.x),born:m.t,attack};
      return true;
    }
    if(f.kind==='metralleta' && attack.skill!==false){
      const spread=[-3,0,3][ceroIndex++]*Math.PI/180;
      const angle=Math.atan2(other.y-origin.y,other.x-origin.x)+spread;
      m.shots.push({kind:'cero',f,side:f.side,x:origin.x+R*Math.cos(angle),
        y:origin.y+R*Math.sin(angle),angle,born:m.t,attacks:[attack],radius:.32,range:120,speed:78});
      return true;
    }
    if(!shot){
      const kind=f.kind==='room'?'room':areaSkills.has(f.kind)?'zone':meleeSkills.has(f.kind)?'blade':'bolt';
      const angle=Math.atan2(other.y-origin.y,other.x-origin.x);
      shot={kind,f,side:f.side,x:origin.x,y:origin.y,angle,born:m.t,attacks:[],
        radius:kind==='room'?ROOM:kind==='zone'?23:kind==='blade'?3:2,
        range:kind==='blade'?25:110,speed:kind==='blade'?90:78};
      m.shots.push(shot);
    }
    shot.attacks.push(attack);
    return true;
  };
  const logStart=m.combat.log.length;
  const fromThird=['simon','meruem_rei','sailor','lucius'].includes(f.kind);
  const fourth=['madoka','yhwach','giorno','meliodas_v'].includes(f.kind);
  const used=fourth?castFourth(m,f,enemy,role):fromThird?castThird(m,f,enemy,role):m.combat.use(f,enemy,f.kind,role,launch);
  if((fromThird||fourth) && used)m.combat.record('especial',f,enemy,{name:f.skill,role});
  if(used && f.kind==='kaguya')m.flashes.push({art:'kaguya_fenda',x:origin.x,y:origin.y,time:m.t});
  if(used && f.kind==='reescrita' && m.combat.log.slice(logStart).some(e=>e.type==='cura')){
    const event=m.combat.log.slice(logStart).find(e=>e.type==='cura');
    const side=Number(event.actor.split(':')[0]);
    m.flashes.push({art:'shinra_cura',follow:side,time:m.t});
  }
  if(used && role==='principal')f.actions++;
  if(!used&&role==='principal'&&!fromThird&&!fourth&&m.combat.pace(f)<1){
    // Accelerated basic attacks also need a spatial hit.
    launch(enemy,{skill:false,magic:f.magicBasic,damage:f.magicBasic?f.magic:f.attack});
    if(!shot)return;
    shot.kind=f.magicBasic?'bolt':'blade';shot.radius=f.magicBasic?2:3;
    shot.speed=f.magicBasic?78:90;shot.range=f.magicBasic?110:25;shot.basic=true;
  }
}
function negativeKeys(unit,time){
  return [...(unit.dots?.keys()??[]),...['weakenUntil','stunUntil','exposedUntil'].filter(k=>unit[k]>time),...(unit.crackedShield?['crackedShield']:[])];
}
function interceptNegative(unit,key){
  if(!unit.cleanSeal?.has(key))return false;
  unit.cleanSeal=null;return true;
}
function applyNegative(unit,key,value){
  if(!interceptNegative(unit,key))unit[key]=value;
}
function cleanse(unit,time,seal){
  const keys=negativeKeys(unit,time);
  for(const k of keys){if(unit.dots?.has(k))unit.dots.delete(k);else unit[k]=0}
  if(seal&&keys.length)unit.cleanSeal=new Set(keys);
  return keys.length;
}
function grantShield(unit,amount){
  if(unit.crackedShield){amount*=.5;unit.crackedShield=false}
  unit.shield=Math.max(unit.shield,amount);
}
function spendLostAction(m,f){
  if(!f.loseAction)return false;
  f.loseAction=false;note(m,f.name+' · ação anulada');return true;
}
function castFourth(m,f,enemy,role){
  const c=m.combat,bench=role==='reserva',active=c.active(f.side),t=c.time;
  if(!active||(!bench&&f.skillReady>t))return false;
  const flash=(art)=>m.flashes.push({art,follow:f.side,time:m.t});
  if(f.kind==='madoka'){
    if(bench){if(!cleanse(active,t,true))return false}
    else for(const ally of c.teams[f.side])if(c.alive(ally))cleanse(ally,t,false);
    flash('madoka_purifica');
  }else if(f.kind==='yhwach'){
    if(bench){if(f.benchFutureSpent)return false;f.benchFutureSpent=true;active.futureUntil=t+4000}
    else if(f.almightySpent)return false;
    flash('yhwach_visao');
  }else if(f.kind==='giorno'){
    if(c.zeroUsed?.[f.side]||active.zeroGuard)return false;
    if(bench)active.zeroGuard=true;
    flash('giorno_selo');
  }else{
    const energy=bench?(active.recentImpact??[]).filter(e=>t-e.t<=4000).reduce((n,e)=>n+e.n,0):(f.demonCharge??0);
    if(!energy)return false;
    fireBatch(m,f,'meliodas_corte',{damage:energy,crack:!bench},60,97);
    if(!bench)f.demonCharge=0;
    flash('meliodas_reserva');
  }
  if(!bench)f.skillReady=t+8000;
  return true;
}
function castThird(m,f,enemy,role){
  const combat=m.combat,t=combat.time,side=m.sides[f.side],ally=side.team[side.slot],bench=role==='reserva';
  if(!bench && f.skillReady>t)return false;
  const flash=(art,follow=f.side)=>m.flashes.push({art,follow,time:m.t});
  if(f.kind==='simon'){
    const events=combat.log.filter(e=>bench?e.type==='entra'&&e.actor.startsWith(f.side+':'):e.type==='cai'&&e.actor.startsWith(f.side+':')&&e.actor!==f.id);
    const stacks=bench?events.length:new Set(events.map(e=>e.actor)).size;
    const factor=1+.25*stacks;
    fireBatch(m,f,'simon_broca',{damage:f.attack*1.5*factor},110,90);
    const drill=m.shots.at(-1);drill.size=21+Math.min(stacks,8)*2;drill.radius=drill.size*.12;
    flash('simon_espiral');
  }else if(f.kind==='meruem_rei'){
    if(bench){
      if(!enemy.lastDamageType)return false;
      ally.adaptiveType=enemy.lastDamageType;ally.adaptiveUntil=t+4000;flash('meruem_carapaca');
    }else{
      const magic=enemy.resistance<enemy.defense;
      fireBatch(m,f,magic?'meruem_esfera':'meruem_lamina',{damage:f.attack*1.5,magic},65,92);
    }
  }else if(f.kind==='sailor'){
    const team=bench?[ally]:side.team.filter(u=>combat.alive(u));
    let excess=0;
    for(const u of team){
      const heal=f.magic*(bench?.8:1.25);excess+=Math.max(0,heal-(u.maxHp-u.hp));combat.heal(u,heal);
    }
    if(bench)ally.moonGuard=true;
    else for(const u of team)u.moonShield=(u.moonShield??0)+excess/team.length;
    if(!bench)m.flashes.push({art:'sailor_onda',x:side.x,y:side.y,time:m.t});
    flash('sailor_cura');
  }else{
    if((!bench&&f.timeSpent)||ally.timeMark?.until>t)return false;
    ally.timeMark={hp:ally.hp,until:bench?t+5000:Infinity,main:!bench,owner:f};
  }
  if(!bench)f.skillReady=t+8000;
  return true;
}
function fireBatch(m,f,art,attack,range,speed){
  const from=m.sides[f.side],to=m.sides[1-f.side],angle=Math.atan2(to.y-from.y,to.x-from.x);
  m.shots.push({kind:'batch',art,angle,side:f.side,f,born:m.t,speed,range,radius:projectileRadius[art]??(art==='saitama_soco'?3.2:1),
    x:from.x+R*Math.cos(angle),y:from.y+R*Math.sin(angle),attacks:[attack]});
}
const mageShots={dominio:'gojo_basico',santuario:'sukuna_basico',beerus:'beerus_basico',kaguya:'kaguya_basico'};
const projectileRadius={meliodas_corte:3,meruem_esfera:2.4,meruem_lamina:2,beerus_hakai:5.2,beerus_basico:1.1,kaguya_basico:1.0,shinra_golpe:2.3};
function quakeRadius(age){return [3,8,14,18][Math.min(3,Math.floor(Math.max(0,age)/.06))]}
function quakeContact(m,q,victim,position){
  if(q.struck.has(victim.id))return;
  q.struck.add(victim.id);
  if(m.combat.hit(q.f,victim,q.attack))m.flashes.push({art:'barba_fratura',x:position.x,y:position.y,time:m.t});
}
function traceHit(x,y,dx,dy,radius){
  const len=dx*dx+dy*dy;
  const u=len?Math.max(0,Math.min(1,-(x*dx+y*dy)/len)):0;
  return Math.hypot(x+u*dx,y+u*dy)<=radius;
}
const ceroMaxLength=26;
const ceroProfile=[1,3,5,7,11,13,15,16,16,15,13,11,9,7,4,1];
function ceroLength(age,speed){return Math.min(ceroMaxLength,Math.max(.6,age*speed));}
function resolveShots(m,previous){
  m.flashes=m.flashes.filter(e=>m.t-e.time<(e.art==='shinra_fratura'?.28:e.art==='saitama_onda'?.32:e.art?.16:(e.kind==='cero'||e.kind==='rei')?.16:.23));
  const followUps=[];
  m.shots=m.shots.filter(s=>{
    const caster=m.sides[s.side],other=m.sides[1-s.side],victim=other.team[other.slot];
    if(!m.combat.alive(s.f)||!victim||!m.combat.present(victim))return false;
    if(s.kind==='muda'){
      const ux=Math.cos(s.angle),uy=Math.sin(s.angle),remaining=s.range-(s.traveled??0);
      const distance=Math.min(remaining,s.speed*DT);
      const [ox,oy]=previous[1-s.side],rx=s.x-ox,ry=s.y-oy;
      const dx=ux*distance-(other.x-ox),dy=uy*distance-(other.y-oy);
      const a=dx*dx+dy*dy,b=rx*dx+ry*dy,c=rx*rx+ry*ry-(R+s.radius)**2;
      const disc=b*b-a*c,t=c<=0?0:a>0&&disc>=0?(-b-Math.sqrt(disc))/a:Infinity;
      if(t>=0&&t<=1){
        const nx=rx+t*dx,ny=ry+t*dy,len=Math.hypot(nx,ny)||1;
        const before=m.combat.log.length;
        m.combat.hit(s.f,victim,{skill:true,magic:false,damage:s.f.attack*MUDA_HIT_RATIO});
        const landed=m.combat.log.slice(before).some(e=>e.type==='dano'&&e.actor===s.f.id&&e.target===victim.id);
        if(landed)m.flashes.push({art:'giorno_impacto',x:ox+(other.x-ox)*t+R*nx/len,y:oy+(other.y-oy)*t+R*ny/len,time:m.t});
        return false;
      }
      s.x+=ux*distance;s.y+=uy*distance;s.traveled=(s.traveled??0)+distance;
      return s.traveled<s.range&&s.x>=0&&s.x<=100&&s.y>=0&&s.y<=50;
    }
    const age=m.t-s.born,zone=s.kind==='room'||s.kind==='zone';
    if(s.kind==='tremor'){
      if(age<.24){
        if(!s.support&&Math.hypot(other.x-s.x,other.y-s.y)<=quakeRadius(age)+R)quakeContact(m,s,victim,other);
        return true;
      }
      const ux=Math.cos(s.angle),uy=Math.sin(s.angle);
      const start=s.support?0:18;
      const front=start+84*(age-.24),oldFront=Math.max(start,front-84*DT);
      const [ox,oy]=previous[1-s.side];
      const oldAlong=(ox-s.x)*ux+(oy-s.y)*uy-oldFront;
      const along=(other.x-s.x)*ux+(other.y-s.y)*uy-front;
      const lateral=Math.abs(-(other.x-s.x)*uy+(other.y-s.y)*ux);
      if(Math.min(oldAlong,along)<=R+1 && Math.max(oldAlong,along)>=-R-1 && lateral<=R+10)
        quakeContact(m,s,victim,other);
      const cx=s.x+ux*front,cy=s.y+uy*front;
      return cx>=-12&&cx<=112&&cy>=-12&&cy<=62;
    }
    if(s.kind==='dominio'||s.kind==='santuario'){
      const gojo=s.kind==='dominio',charge=gojo?.36:0;
      if(gojo && age<charge){s.x=caster.x;s.y=caster.y;return true}
      if(gojo&&!s.open){s.x=caster.x;s.y=caster.y;s.open=true}
      const end=charge+(gojo?1.5:1.6);
      if(age>=end)return false;
      const inside=Math.hypot(other.x-s.x,other.y-s.y)<=R+s.radius;
      if(gojo){
        if(inside){applyNegative(victim,'stunUntil',Math.max(victim.stunUntil??0,m.combat.time+18));
          if(!s.applied){m.combat.hit(s.f,victim,s.attack);s.applied=true}}
      }else if(age>=s.pulse*.4){
        s.pulse++;
        if(inside){m.combat.hit(s.f,victim,s.attack);m.flashes.push({art:'sukuna_corte',x:other.x,y:other.y,time:m.t})}
      }
      return true;
    }
    let hit=false;
    if(zone){
      // Activate after the ring has opened. ROOM remains armed for one cut.
      if(age<.3)return true;
      hit=Math.hypot(other.x-s.x,other.y-s.y)<=s.radius+R;
      if(!hit && age<(s.kind==='room'?1.5:.45))return true;
    }else{
      const [ox,oy]=previous[1-s.side],vx=Math.cos(s.angle)*s.speed*DT,vy=Math.sin(s.angle)*s.speed*DT;
      if(s.kind==='cero'){
        const before=ceroLength(age-DT,s.speed),after=ceroLength(age,s.speed);
        const ux=Math.cos(s.angle),uy=Math.sin(s.angle);
        let first=Infinity;
        for(let i=0;i<ceroProfile.length;i++){
          const offset=i*5/80,radius=after*ceroProfile[i]/160;
          const rx=s.x-before*offset*ux-ox,ry=s.y-before*offset*uy-oy;
          const dx=vx-(after-before)*offset*ux-(other.x-ox);
          const dy=vy-(after-before)*offset*uy-(other.y-oy);
          const a=dx*dx+dy*dy,b=rx*dx+ry*dy,c=rx*rx+ry*ry-(radius+R)**2;
          const disc=b*b-a*c;
          const t=c<=0?0:a>0&&disc>=0?(-b-Math.sqrt(disc))/a:Infinity;
          if(t<0||t>1||t>=first)continue;
          const x=s.x+t*vx,y=s.y+t*vy;
          if(x<0||x>100||y<0||y>50)continue;
          first=t;hit=true;
          const nx=rx+t*dx,ny=ry+t*dy,len=Math.hypot(nx,ny)||1;
          s.contactX=ox+t*(other.x-ox)+R*nx/len;
          s.contactY=oy+t*(other.y-oy)+R*ny/len;
        }
      }else hit=traceHit(s.x-ox,s.y-oy,vx-(other.x-ox),vy-(other.y-oy),s.radius+R);
      s.x+=vx;s.y+=vy;
      if(!hit&&age*s.speed<s.range&&s.x>=0&&s.x<=100&&s.y>=0&&s.y<=50)return true;
    }
    if(s.art==='saitama_soco'){
      const direction=Math.atan2(s.y-other.y,s.x-other.x);
      const x=hit?other.x+R*Math.cos(direction):s.x;
      const y=hit?other.y+R*Math.sin(direction):s.y;
      m.flashes.push({art:'saitama_onda',x,y,angle:s.angle,time:m.t+.045});
    }
    if(!hit){note(m,(s.basic?'Ataque básico':s.f.skill)+' · errou');return false;}
    if(s.kind==='batch'){
      const last=m.combat.log.length;
      const resolved=m.combat.hit(s.f,victim,s.attacks[0]);
      if(resolved && m.combat.log.slice(last).some(e=>e.type==='dano'&&e.actor===s.f.id&&e.target===victim.id)){
        const a=Math.atan2(s.y-other.y,s.x-other.x);
        m.flashes.push({art:({meliodas_corte:'meliodas_contato',simon_broca:'simon_impacto',meruem_esfera:'meruem_impacto',meruem_lamina:'meruem_impacto',beerus_hakai:'beerus_dissipacao',beerus_basico:'beerus_dissipacao',kaguya_basico:'kaguya_fragmentos',shinra_golpe:'contato_dourado'})[s.art]??(s.art==='saitama_soco'?'saitama_impacto':s.art==='sukuna_basico'?'sukuna_corte':'contato_azul'),x:other.x+R*Math.cos(a),y:other.y+R*Math.sin(a),time:m.t});
      }
      return false;
    }
    m.flashes.push({kind:s.kind,side:s.side,x:s.contactX??other.x,y:s.contactY??other.y,fromX:caster.x,fromY:caster.y,time:m.t});
    for(const attack of s.attacks){
      if(!m.combat.alive(s.f)||!m.combat.present(victim))break;
      if(!s.basic&&s.f.kind==='ashisogi')applyNegative(victim,'weakenUntil',Math.max(victim.weakenUntil,m.combat.time+4000));
      const logStart=m.combat.log.length;
      m.combat.hit(s.f,victim,attack);
      if(s.combo&&!s.combo.triggered&&m.combat.log.slice(logStart).some(e=>e.type==='dano'&&e.actor===s.f.id&&e.target===victim.id)){
        s.combo.triggered=true;
        followUps.push({kind:'blade',f:s.f,side:s.side,x:caster.x,y:caster.y,angle:Math.atan2(other.y-caster.y,other.x-caster.x),born:m.t,attacks:[{damage:s.f.attack,ignoreDefense:.5}],radius:2.5,range:110,speed:96});
      }
      if(!s.basic&&s.f.kind==='dominio')applyNegative(victim,'stunUntil',Math.max(victim.stunUntil??0,m.combat.time+1500));
    }
    return false;
  });
  m.shots.push(...followUps);
}
const passiveEvents={'aceleração':'Made in Heaven · Aceleração do Tempo','tempo parado':'The World','ressurge':'Ressurgimento'};
const dotKinds={'portgas-d-ace':'dot_fogo','meliodas-magia-verdadeira':'dot_chamas_negras','shinra_banshoman':'dot_chamas_azuis','sukuna-forma-original':'dot_sangramento'};
function applyDot(m,source,target,key,damage,period,count){
  if(interceptNegative(target,key))return;
  const states=target.dots??=new Map();
  states.set(key,{key,source,damage,period,count,start:m.t,next:m.t+period,lastTick:null});
}
function stepDots(m,target){
  for(const [key,state] of target.dots??[]){
    if(!m.combat.present(target)||!m.combat.alive(state.source)){target.dots.delete(key);continue}
    if(m.t+1e-8<state.next)continue;
    m.combat.hit(state.source,target,{area:true,skill:false,magic:key!=='dot_sangramento',damage:state.damage});
    state.lastTick=m.t;state.next+=state.period;
    if(--state.count===0||!m.combat.present(target))target.dots.delete(key);
  }
}
const MUDA_HIT_RATIO=0.20;
function updateBarrage(m,f){
  if(f.kind!=='giorno')return;
  const side=m.sides[f.side],other=m.sides[1-f.side];
  const d=Math.hypot(other.x-side.x,other.y-side.y);
  if(d>22)f.barrageInside=false;
  if(!m.combat.present(f)||m.combat.blocked(f)||!m.combat.present(other.team[other.slot])){
    f.punchesLeft=0;return;
  }
  if(!f.barrageInside&&d<=18&&!f.punchesLeft){
    f.barrageInside=true;f.punchesLeft=6;f.nextPunch=m.t;
    note(m,'Gold Experience Requiem · Muda Barrage');
  }
  if(!f.punchesLeft||m.t+1e-8<f.nextPunch)return;
  const index=6-f.punchesLeft,angle=Math.atan2(other.y-side.y,other.x-side.x);
  const ux=Math.cos(angle),uy=Math.sin(angle),offset=[-2.4,1.8,-1,2.6,-2,0][index];
  m.shots.push({kind:'muda',f,side:f.side,angle,born:m.t,x:side.x+3.3*ux-offset*uy,
    y:side.y+3.3*uy+offset*ux,speed:97,range:17,radius:1.1});
  f.punchesLeft--;f.nextPunch+=.075;
}
function stepDuel(m){
  if(m.result!==null)return;
  m.t+=DT;
  const combat=m.combat;
  const firstEvent=combat.log.length;
  combat.time=Math.round(m.t*1000);
  const [a,b]=m.sides, active=m.sides.map(s=>s.team[s.slot]);
  const previous=m.sides.map(s=>[s.x,s.y]);
  m.sides.forEach((s,i)=>{
    if(!s.ignition)return;
    if(!combat.present(active[i])||combat.blocked(active[i])){delete s.ignition;return}
    if(m.t-s.ignition.born<.20)return;
    const target=m.sides[1-i];
    s.dash={art:'shinra_golpe',born:m.t,angle:Math.atan2(target.y-s.y,target.x-s.x),attack:s.ignition.attack};
    delete s.ignition;
  });
  const charging=m.sides.map(s=>s.dash);
  m.sides.forEach((s,i)=>{
    if(!combat.present(active[i])||combat.blocked(active[i])){delete s.dash;return}
    if(!s.dash){move(s,active[i]);return}
    const ux=Math.cos(s.dash.angle),uy=Math.sin(s.dash.angle);
    const wallX=ux>0?(100-R-s.x)/ux:ux<0?(R-s.x)/ux:Infinity;
    const wallY=uy>0?(50-R-s.y)/uy:uy<0?(R-s.y)/uy:Infinity;
    const dist=Math.min(110*DT,wallX,wallY);
    s.x+=dist*ux;s.y+=dist*uy;
    if(dist<110*DT||m.t-s.dash.born>=.4)delete s.dash;
  });
  charging.forEach((dash,i)=>{
    if(!dash||!combat.present(active[i])||combat.blocked(active[i]))return;
    const enemy=active[1-i],s=m.sides[i],o=m.sides[1-i];
    const [x,y]=previous[i],[ox,oy]=previous[1-i];
    const rx=x-ox,ry=y-oy,dx=s.x-x-(o.x-ox),dy=s.y-y-(o.y-oy);
    const a=dx*dx+dy*dy,b=rx*dx+ry*dy,c=rx*rx+ry*ry-4*R*R;
    const d=b*b-a*c,t=c<=0?0:a&&d>=0?(-b-Math.sqrt(d))/a:Infinity;
    if(t<0||t>1||!combat.present(enemy))return;
    s.x=x+t*(s.x-x);s.y=y+t*(s.y-y);
    delete s.dash;
    const flash={kind:'rei',x:(s.x+ox+t*(o.x-ox))/2,y:(s.y+oy+t*(o.y-oy))/2,time:m.t,angle:dash.angle};
    const start=combat.log.length;
    combat.hit(active[i],enemy,dash.attack);
    if(!dash.art)m.flashes.push(flash);
    else if(combat.log.slice(start).some(e=>e.type==='dano'&&e.target===enemy.id))
      m.flashes.push({...flash,art:'shinra_fratura',kind:'fratura'});
    m.contact=Math.max(m.contact,m.t+.45);
  });
  const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);
  if(d<=2*R){
    const nx=d?dx/d:1,ny=d?dy/d:0,push=(2*R-d)/2;
    a.x=Math.max(R,Math.min(100-R,a.x-nx*push));a.y=Math.max(R,Math.min(50-R,a.y-ny*push));
    b.x=Math.max(R,Math.min(100-R,b.x+nx*push));b.y=Math.max(R,Math.min(50-R,b.y+ny*push));
    const closing=(a.vx-b.vx)*nx+(a.vy-b.vy)*ny;
    if(closing>0){a.vx-=closing*nx;a.vy-=closing*ny;b.vx+=closing*nx;b.vy+=closing*ny;}
  }
  if(d<=2*R&&m.t>=m.contact){
    // Alternate initiative on contact. A defeated or stunned fighter cannot counter.
    const order=m.contacts%2===1?[1,0]:[0,1];
    m.contacts++;
    for(const i of order){
      const f=active[i],g=active[1-i];
      if(!combat.present(f)||!combat.present(g)||combat.blocked(f))continue;
      if(mageShots[f.kind])continue;
      if(spendLostAction(m,f))continue;
      f.actions++;
      if(combat.hit(f,g,{damage:rawCollision(f),skill:false,magic:!!f.magicBasic}))f.hits++;
    }
    note(m,'Colisão · '+active.map(f=>f.name).join(' × '));m.contact=m.t+.45;
  }
  for(const f of active){
    if(!combat.present(f)||combat.blocked(f)||!mageShots[f.kind]||f.nextBasic>combat.time)continue;
    f.nextBasic=combat.time+f.interval;if(spendLostAction(m,f))continue;f.actions++;
    fireBatch(m,f,mageShots[f.kind],{magic:true,skill:false,damage:f.magic},110,78);
  }
  for(const unit of active)stepDots(m,unit);
  resolveShots(m,previous);
  for(const f of active)updateBarrage(m,f);
  m.sides.forEach((side,i)=>{
    const ally=active[i],enemy=active[1-i];
    for(const f of side.team.slice(side.slot)){
      if(f.ready>m.t||!combat.present(ally)||!combat.present(enemy)||combat.blocked(f))continue;
      const reserve=f!==ally;
      if(!reserve)combat.beginAttack(f);
      f.ready=m.t+(reserve?8:2)*combat.pace(f);
      if(spendLostAction(m,f))continue;
      if(reserve && f.role==='Suporte' && !f.signatureAssist){
        combat.heal(ally,Math.round(f.magic*.8));announce(m,f,'Cura de apoio','reserva');
      }else{
        arenaCast(m,f,enemy,reserve?'reserva':'principal');
        if(['koto','demonSword','fiction'].includes(f.kind)&&f.skillReady>combat.time)
          f.ready=m.t+(f.skillReady-combat.time)/1000;

      }
    }
  });
  m.sides.forEach((side,i)=>{
    if(!combat.alive(active[i])){
      side.slot++;
      if(side.slot<side.team.length){
        side.x=i?80:20;side.y=i?30:20;side.vx=i?-26:26;side.vy=i?-12:12;
        side.team[side.slot].ready=m.t+2;
        note(m,side.team[side.slot].name+' entra na arena.');
      }
    }
  });
  for(let i=firstEvent;i<combat.log.length;i++){
    const e=combat.log[i];
    if(['carapaca','lunar','reverte'].includes(e.type)){
      const side=Number(e.actor.split(':')[0]);m.flashes.push({art:{carapaca:'meruem_carapaca',lunar:'sailor_barreira',reverte:'lucius_reversao'}[e.type],follow:side,time:m.t});
    }
    if(['zero','futuro','ciclos'].includes(e.type)){
      const side=Number(e.actor.split(':')[0]);m.flashes.push({art:{zero:'giorno_zero',futuro:'yhwach_futuro',ciclos:'madoka_retorno'}[e.type],follow:side,time:m.t});
      if(e.type==='zero'&&e.main)m.flashes.push({art:'giorno_acao',follow:1-side,time:m.t});
    }
    if(e.type==='portal'){
      const side=Number(e.actor.split(':')[0]);
      m.flashes.push({art:'kaguya_fenda',follow:side,time:m.t});
    }
    if(e.type==='instintiva'||e.type==='ilimitado'){
      const [side,slot]=e.actor.split(':').map(Number),s=m.sides[side],f=s.team[slot];
      if(e.type==='instintiva')fireBatch(m,f,'goku_contra',{damage:f.attack,skill:false,counter:true},110,125);
      else m.flashes.push({art:'gojo_ilimitado',follow:side,x:s.x,y:s.y,time:m.t});
      note(m,f.name+(e.type==='instintiva'?' · esquiva e contra-ataca':' · Ilimitado'));
    }
    if(e.type==='especial'){
      const [side,slot]=e.actor.split(':').map(Number);
      announce(m,m.sides[side].team[slot],e.name,e.role);
    }
    if(passiveEvents[e.type] && e.actor){
      const [side,slot]=e.actor.split(':').map(Number);
      const actor=m.sides[side].team[slot];
      const combo=e.type==='aceleração'&&actor.nen?' · Última Aposta 8×':'';
      announce(m,actor,passiveEvents[e.type]+combo,'passiva');
    }
    if(e.type!=='dano'||e.hp<=0)continue;
    const [side,slot]=e.actor.split(':').map(Number);
    const [other,targetSlot]=e.target.split(':').map(Number);
    m.damageFeed.unshift({seq:i,side,source:m.sides[side].team[slot].name,target:m.sides[other].team[targetSlot].name,amount:e.hp});
  }
  if(m.damageFeed.length>12)m.damageFeed.length=12;
  const out=m.sides.map(s=>s.slot===s.team.length);
  if(out.some(Boolean))m.result=out[0]===out[1]?'Empate':out[0]?'Derrota':'Vitória';
  else if(m.t+1e-8>=m.limit){
    const score=m.sides.map(s=>s.team.reduce((n,f)=>n+f.hp/f.maxHp,0)/s.team.length);
    m.result= Math.abs(score[0]-score[1])<.00001?'Empate':score[0]>score[1]?'Vitória':'Derrota';
    note(m,'Tempo esgotado · decisão pela média das frações de PV restantes.');
  }
}
return {collisionBonus,collisionPower,createDuel,finishDuel,stepDuel};})();
const game=(()=>{
const {Combate,affinity}=engine;
const {createDuel,finishDuel}=duelEngine;
const {dailyCycle}=communityRules;


const AREAS = [
  { id:'entrada', name:'Costa de Namek', description:'Patrulhas do império rondam o litoral.', levels:[1,3], unlock:1, enemy:'Soldado da Tropa Freeza', base:[150,18,9,9], color:'Roxo' },
  { id:'meio', name:'Planícies Verdes', description:'O terreno aberto favorece as tropas de elite.', levels:[4,6], unlock:4, enemy:'Veterano da Tropa Freeza', base:[220,23,12,12], color:'Amarelo' },
  { id:'final', name:'Base de Freeza', description:'Vença 12 encontros nesta área para liberar Freeza.', levels:[7,10], unlock:7, enemy:'Oficial da Tropa Freeza', base:[300,28,14,14], color:'Vermelho' },
];
const BOSS = {name:'Freeza · Forma Final',base:[520,38,18,18], color:'Roxo'};
const WORLDS = [
  {
    name:"Namek", universe:"Dragon Ball",
    areas:AREAS,
    elite:{"name": "Capitão Ginyu", "level": 11, "base": [380, 33, 16, 16]},
    boss:{"name": "Freeza · forma final", "level": 12, "base": [520, 38, 18, 18], "kind": "freeza-boss", "color": "Roxo"},
  },
  {
    name:"Arlong Park", universe:"One Piece",
    areas:[
      {"name": "Costa de Cocoyasi", "enemy": "Vigia dos Piratas Arlong", "levels": [11, 13], "unlock": 1, "base": [150, 18, 9, 9], "color": "Amarelo", "description": "Vigia dos Piratas Arlong"},
      {"name": "Vila de Cocoyasi", "enemy": "Homem-peixe dos Piratas Arlong", "levels": [14, 16], "unlock": 14, "base": [220, 23, 12, 12], "color": "Vermelho", "description": "Homem-peixe dos Piratas Arlong"},
      {"name": "Fortaleza de Arlong", "enemy": "Veterano dos Piratas Arlong", "levels": [17, 20], "unlock": 17, "base": [300, 28, 14, 14], "color": "Azul", "description": "Veterano dos Piratas Arlong"}
    ],
    elite:{"name": "Kuroobi", "level": 21, "base": [385, 33, 16, 16]},
    boss:{"name": "Arlong", "level": 22, "base": [532, 38, 18, 18], "kind": "rush", "color": "Azul"},
  },
  {
    name:"Exames Chūnin", universe:"Naruto",
    areas:[
      {"name": "Portões da Folha", "enemy": "Genin rival", "levels": [21, 23], "unlock": 1, "base": [150, 18, 9, 9], "color": "Vermelho", "description": "Genin rival"},
      {"name": "Floresta da Morte", "enemy": "Genin da Vila do Som", "levels": [24, 26], "unlock": 24, "base": [220, 23, 12, 12], "color": "Azul", "description": "Genin da Vila do Som"},
      {"name": "Arena dos Exames", "enemy": "Genin da Vila da Areia", "levels": [27, 30], "unlock": 27, "base": [300, 28, 14, 14], "color": "Verde", "description": "Genin da Vila da Areia"}
    ],
    elite:{"name": "Neji Hyūga", "level": 31, "base": [390, 33, 16, 16]},
    boss:{"name": "Gaara · transformação parcial", "level": 32, "base": [544, 38, 18, 18], "kind": "ward", "color": "Laranja"},
  },
  {
    name:"Soul Society", universe:"Bleach",
    areas:[
      {"name": "Rukongai", "enemy": "Shinigami em patrulha", "levels": [31, 33], "unlock": 1, "base": [150, 18, 9, 9], "color": "Azul", "description": "Shinigami em patrulha"},
      {"name": "Muralhas do Seireitei", "enemy": "Soldado da guarda do Seireitei", "levels": [34, 36], "unlock": 34, "base": [220, 23, 12, 12], "color": "Verde", "description": "Soldado da guarda do Seireitei"},
      {"name": "Colina de Sōkyoku", "enemy": "Oficial de esquadrão", "levels": [37, 40], "unlock": 37, "base": [300, 28, 14, 14], "color": "Turquesa", "description": "Oficial de esquadrão"}
    ],
    elite:{"name": "Renji Abarai", "level": 41, "base": [395, 33, 16, 16]},
    boss:{"name": "Byakuya Kuchiki", "level": 42, "base": [556, 38, 18, 18], "kind": "beam", "color": "Rosa"},
  },
  {
    name:"Jujutsu Kaisen", universe:"Jujutsu Kaisen",
    areas:[
      {"name": "Escola de Jujutsu", "enemy": "Maldição menor", "levels": [41, 43], "unlock": 1, "base": [150, 18, 9, 9], "color": "Verde", "description": "Maldição menor"},
      {"name": "Distrito amaldiçoado", "enemy": "Maldição de distrito", "levels": [44, 46], "unlock": 44, "base": [220, 23, 12, 12], "color": "Turquesa", "description": "Maldição de distrito"},
      {"name": "Domínio vulcânico", "enemy": "Maldição de grau 2", "levels": [47, 50], "unlock": 47, "base": [300, 28, 14, 14], "color": "Rosa", "description": "Maldição de grau 2"}
    ],
    elite:{"name": "Portador de Dedo", "level": 51, "base": [400, 33, 16, 16]},
    boss:{"name": "Jogo", "level": 52, "base": [568, 38, 18, 18], "kind": "ginyu", "color": "Vermelho"},
  },
  {
    name:"Black Clover", universe:"Black Clover",
    areas:[
      {"name": "Vila de Hage", "enemy": "Recruta do Olho do Sol da Meia-Noite", "levels": [51, 53], "unlock": 1, "base": [150, 18, 9, 9], "color": "Turquesa", "description": "Recruta do Olho do Sol da Meia-Noite"},
      {"name": "Floresta encantada", "enemy": "Mago do Olho do Sol da Meia-Noite", "levels": [54, 56], "unlock": 54, "base": [220, 23, 12, 12], "color": "Rosa", "description": "Mago do Olho do Sol da Meia-Noite"},
      {"name": "Templo submerso", "enemy": "Veterano do Olho do Sol da Meia-Noite", "levels": [57, 60], "unlock": 57, "base": [300, 28, 14, 14], "color": "Laranja", "description": "Veterano do Olho do Sol da Meia-Noite"}
    ],
    elite:{"name": "Fana", "level": 61, "base": [405, 33, 16, 16]},
    boss:{"name": "Vetto", "level": 62, "base": [580, 38, 18, 18], "kind": "rush", "color": "Verde"},
  },
  {
    name:"Nanatsu no Taizai", universe:"Nanatsu no Taizai",
    areas:[
      {"name": "Arredores de Liones", "enemy": "Recruta de Liones", "levels": [61, 63], "unlock": 1, "base": [150, 18, 9, 9], "color": "Rosa", "description": "Recruta de Liones"},
      {"name": "Cidade de Liones", "enemy": "Cavaleiro de Liones", "levels": [64, 66], "unlock": 64, "base": [220, 23, 12, 12], "color": "Laranja", "description": "Cavaleiro de Liones"},
      {"name": "Castelo real", "enemy": "Cavaleiro Sagrado", "levels": [67, 70], "unlock": 67, "base": [300, 28, 14, 14], "color": "Roxo", "description": "Cavaleiro Sagrado"}
    ],
    elite:{"name": "Dreyfus", "level": 71, "base": [410, 33, 16, 16]},
    boss:{"name": "Hendrickson · forma demoníaca", "level": 72, "base": [592, 38, 18, 18], "kind": "beam", "color": "Preto"},
  },
  {
    name:"JoJo", universe:"JoJo",
    areas:[
      {"name": "Ruas do Cairo", "enemy": "Capanga de DIO", "levels": [71, 73], "unlock": 1, "base": [150, 18, 9, 9], "color": "Laranja", "description": "Capanga de DIO"},
      {"name": "Distrito antigo", "enemy": "Usuário de Stand a serviço de DIO", "levels": [74, 76], "unlock": 74, "base": [220, 23, 12, 12], "color": "Roxo", "description": "Usuário de Stand a serviço de DIO"},
      {"name": "Mansão de DIO", "enemy": "Usuário de Stand veterano", "levels": [77, 80], "unlock": 77, "base": [300, 28, 14, 14], "color": "Amarelo", "description": "Usuário de Stand veterano"}
    ],
    elite:{"name": "Vanilla Ice", "level": 81, "base": [415, 33, 16, 16]},
    boss:{"name": "DIO · The World", "level": 82, "base": [604, 38, 18, 18], "kind": "rush", "color": "Amarelo"},
  },
  {
    name:"Hunter × Hunter", universe:"Hunter × Hunter",
    areas:[
      {"name": "Fronteira de NGL", "enemy": "Formiga Quimera operária", "levels": [81, 83], "unlock": 1, "base": [150, 18, 9, 9], "color": "Roxo", "description": "Formiga Quimera operária"},
      {"name": "Território das formigas", "enemy": "Formiga Quimera soldado", "levels": [84, 86], "unlock": 84, "base": [220, 23, 12, 12], "color": "Amarelo", "description": "Formiga Quimera soldado"},
      {"name": "Palácio Real", "enemy": "Formiga Quimera capitã", "levels": [87, 90], "unlock": 87, "base": [300, 28, 14, 14], "color": "Vermelho", "description": "Formiga Quimera capitã"}
    ],
    elite:{"name": "Neferpitou", "level": 91, "base": [420, 33, 16, 16]},
    boss:{"name": "Meruem", "level": 92, "base": [616, 38, 18, 18], "kind": "rush", "color": "Verde"},
  },
  {
    name:"One Punch Man", universe:"One Punch Man",
    areas:[
      {"name": "Periferia da Cidade Z", "enemy": "Monstro nível Lobo", "levels": [91, 93], "unlock": 1, "base": [150, 18, 9, 9], "color": "Amarelo", "description": "Monstro nível Lobo"},
      {"name": "Zona evacuada", "enemy": "Monstro nível Tigre", "levels": [94, 96], "unlock": 94, "base": [220, 23, 12, 12], "color": "Vermelho", "description": "Monstro nível Tigre"},
      {"name": "Covil dos monstros", "enemy": "Monstro nível Demônio", "levels": [97, 100], "unlock": 97, "base": [300, 28, 14, 14], "color": "Azul", "description": "Monstro nível Demônio"}
    ],
    elite:{"name": "Rei do Mar Profundo", "level": 101, "base": [425, 33, 16, 16]},
    boss:{"name": "Boros", "level": 102, "base": [628, 38, 18, 18], "kind": "freeza-boss", "color": "Vermelho"},
  }
];
const worldOf = state=>WORLDS[state.world??0];
const levelCap = state=>10*(1+(state.unlocked??0));
const COLORS = {Verde:'#71dd9f',Laranja:'#ffab68',Amarelo:'#f5d66c',Azul:'#83baff',Branco:'#ecebff',Roxo:'#cc95ff',Rosa:'#f592bc',Preto:'#a8a2be',Vermelho:'#ff8290',Turquesa:'#70e1da',Dourado:'#ffe28a'};
const TIERS = ['Comum','Incomum','Rara','Épica','Mítica','Divina','Secreta','Transcendente'];
// PV, ataque, magia, defesa, resistência e velocidade no nível 1, antes da função.
const baseStats = [
  [100, 20, 20, 12, 12, 100],
  [115, 23, 23, 14, 14, 101],
  [133, 27, 27, 16, 16, 101],
  [156, 31, 31, 19, 19, 102],
  [188, 38, 38, 23, 23, 103],
  [228, 46, 46, 28, 28, 104],
  [278, 55, 55, 33, 33, 104],
  [348, 70, 70, 42, 42, 106]
];
const roles = {Combatente:[.10,.25,-.15,0,0,0],Guardião:[.25,-.10,0,.25,.15,0],Mágico:[-.15,0,.30,0,.10,0],Suporte:[0,-.15,.15,0,.15,.05]};
const roster = [
  ["hoova-shisui","Hoova · Shisui Uchiha",6,"Verde","Mágico","koto","Kotoamatsukami",["Verde",{magic:15,speed:8}],"ap-hoova-shisui","Naruto"],
  ["zawa-cheon","Zawa · Cheon Yeo Woon",7,"Roxo","Combatente","demonSword","Espada do Demônio Celestial",["Roxo",{attack:20,speed:8}],"ap-zawa-cheon","Nano Machine"],
  ["careca-kumagawa","Careca · Kumagawa Misogi",8,"Preto","Suporte","fiction","All Fiction",["Equipe",{magic:18,resistance:10}],"ap-careca-kumagawa","Medaka Box"],
  ["shinra_banshoman", "Shinra Banshōman", 8, "Dourado", "Combatente", "reescrita", "Reescrita da Realidade", ["Equipe", {"hp": 12, "attack": 14}], "fighter", "Fire Force"],
  ["benimaru_shinmon", "Benimaru Shinmon", 7, "Vermelho", "Combatente", "nichirin", "Nichirin", ["Fire Force", {"attack": 20, "magic": 8}], "fighter", "Fire Force"],
  ["luminous", "Luminous Valentine", 7, "Rosa", "Suporte", "ciclo_vital", "Ciclo de Vida e Morte", ["Equipe", {"hp": 12, "resistance": 6}], "support", "Tensei Shitara Slime Datta Ken"],
  ["veldora", "Veldora Tempest", 7, "Turquesa", "Mágico", "tempestade", "Tempestade do Dragão", ["Turquesa", {"magic": 22, "speed": 8}], "freeza", "Tensei Shitara Slime Datta Ken"],

  ["mayuri", "Mayuri Kurotsuchi", 5, "Roxo", "Mágico", "ashisogi", "Ashisogi Jizō", ["Mágico", {"magic": 15}], "support", "Bleach"],
  ["starrk", "Coyote Starrk", 6, "Azul", "Mágico", "metralleta", "Cero Metralleta", ["Mágico", {"magic": 13, "speed": 6}], "fighter", "Bleach"],
  ["yoruichi", "Yoruichi Shihōin", 5, "Amarelo", "Combatente", "shunko", "Shunkō", ["Combatente", {"attack": 10, "speed": 8}], "fighter", "Bleach"],
  ["urahara", "Kisuke Urahara", 6, "Verde", "Suporte", "benihime", "Benihime · Escudo de Sangue", ["Suporte", {"magic": 17, "resistance": 10}], "support", "Bleach"],
  ["shinra", "Shinra Kusakabe", 4, "Vermelho", "Combatente", "rush", "Chute de Ignição", ["Vermelho", {"attack": 12}], "fighter", "Fire Force"],
  ["arthur", "Arthur Boyle", 4, "Azul", "Combatente", "excalibur", "Excalibur", ["Azul", {"attack": 12}], "fighter", "Fire Force"],
  ["maki_oze", "Maki Oze", 3, "Laranja", "Guardião", "ward", "Guarda das Chamas", ["Laranja", {"hp": 10}], "namek", "Fire Force"],
  ["iris", "Iris", 2, "Branco", "Suporte", "heal", "Prece da Companhia 8", ["Branco", {"hp": 10}], "support", "Fire Force"],
  ["piccolo", "Piccolo", 4, "Verde", "Guardião", "piccolo", "Proteção Namekuseijin", ["Dragon Ball", {"defense": 12, "resistance": 12}], "namek"],
  ["yamcha", "Yamcha", 1, "Laranja", "Combatente", "yamcha", "Punho do Lobo", ["Combatente", {"attack": 8}], "fighter"],
  ["kuririn", "Kuririn", 2, "Amarelo", "Mágico", "kuririn", "Disco Cortante", ["Amarelo", {"magic": 10}], "monk"],
  ["bulma", "Bulma", 1, "Azul", "Suporte", "bulma", "Cápsula de Proteção", ["Azul", {"hp": 8}], "support"],
  ["tenshinhan", "Tenshinhan", 3, "Branco", "Suporte", "ward", "Taiyōken", ["Branco", {"speed": 10}], "monk"],
  ["gohan", "Gohan · Namek", 4, "Amarelo", "Combatente", "rush", "Explosão de Raiva", ["Amarelo", {"attack": 10}], "fighter"],
  ["freeza", "Freeza · Forma Final", 5, "Roxo", "Mágico", "death_ray", "Raio da Morte", ["Roxo", {"magic": 17}], "freeza"],
  ["android17", "Android 17", 6, "Verde", "Guardião", "barreira", "Barreira Contínua", ["Equipe", {"defense": 10, "resistance": 10}], "fighter"],
  ["vegeta", "Vegeta · Blue", 7, "Azul", "Combatente", "final_flash", "Final Flash", ["Dragon Ball", {"attack": 18, "magic": 8}], "fighter"],
  ["broly", "Broly · Super", 7, "Verde", "Combatente", "furia", "Fúria Crescente", ["Combatente", {"attack": 18, "hp": 8}], "namek"],
  ["goku", "Goku · Instinto Superior", 8, "Branco", "Combatente", "instinto", "Resposta Instintiva", ["Equipe", {"attack": 14, "speed": 8}], "fighter"],
  ["beerus", "Beerus", 8, "Roxo", "Mágico", "beerus", "Hakai", ["Mágico", {"magic": 22}], "freeza"],
  ["usopp", "Usopp", 1, "Amarelo", "Suporte", "heal", "Estilingue", ["Amarelo", {"hp": 8}], "support", "One Piece"],
  ["nami", "Nami", 2, "Turquesa", "Mágico", "beam", "Nuvem de Tempestade", ["Turquesa", {"magic": 10}], "support", "One Piece"],
  ["rocklee", "Rock Lee", 3, "Verde", "Combatente", "rush", "Lótus Primária", ["Verde", {"speed": 10}], "fighter", "Naruto"],
  ["zoro", "Zoro", 4, "Verde", "Combatente", "rush", "Santōryū", ["Verde", {"attack": 12}], "fighter", "One Piece"],
  ["law", "Trafalgar Law", 5, "Azul", "Suporte", "room", "ROOM", ["Equipe", {"hp": 8, "magic": 8}], "support", "One Piece"],
  ["gojo", "Gojo", 8, "Azul", "Mágico", "dominio", "Vazio Ilimitado", ["Equipe", {"magic": 15, "resistance": 8}], "fighter", "Jujutsu Kaisen"],
  ["netero", "Netero", 6, "Dourado", "Combatente", "bodisatva", "Mãos do Bodisatva", ["Combatente", {"attack": 12, "speed": 8}], "monk", "Hunter × Hunter"],
  ["mob", "Mob · ???%", 7, "Preto", "Mágico", "despertar", "Despertar Psíquico", ["Mágico", {"hp": 12, "magic": 16}], "support", "Mob Psycho 100"],
  ["accelerator", "Accelerator", 8, "Branco", "Guardião", "accelerator", "Controle Vetorial", ["Guardião", {"defense": 20, "resistance": 20}], "fighter", "Toaru"],
  ["sukuna-forma-original", "Sukuna · forma original", 8, "Vermelho", "Mágico", "beam", "Santuário Malevolente", ["Mágico", {"magic": 8}], "ap-sukuna-forma-original", "Jujutsu Kaisen"],
  ["nanami", "Nanami", 4, "Amarelo", "Combatente", "rush", "Proporção 7:3", ["Combatente", {"attack": 8}], "ap-nanami", "Jujutsu Kaisen"],
  ["maki-desperta", "Maki · desperta", 5, "Verde", "Combatente", "rush", "Corte da Alma", ["Combatente", {"attack": 8}], "ap-maki-desperta", "Jujutsu Kaisen"],
  ["aoi-todo", "Aoi Todo", 4, "Turquesa", "Suporte", "ward", "Boogie Woogie", ["Suporte", {"hp": 8}], "ap-aoi-todo", "Jujutsu Kaisen"],
  ["kasumi-miwa", "Kasumi Miwa", 1, "Azul", "Guardião", "ward", "Domínio Simples", ["Azul", {"resistance": 8}], "ap-kasumi-miwa", "Jujutsu Kaisen"],
  ["kenjaku", "Kenjaku", 6, "Roxo", "Mágico", "beam", "Espíritos em Cadeia", ["Mágico", {"magic": 8}], "ap-kenjaku", "Jujutsu Kaisen"],
  ["nobara", "Nobara", 3, "Rosa", "Mágico", "beam", "Ressonância", ["Mágico", {"magic": 8}], "ap-nobara", "Jujutsu Kaisen"],
  ["mahoraga", "Mahoraga", 6, "Branco", "Guardião", "ward", "Roda da Adaptação", ["Guardião", {"defense": 8}], "ap-mahoraga", "Jujutsu Kaisen"],
  ["yuta", "Yuta", 6, "Branco", "Mágico", "beam", "Rika", ["Mágico", {"magic": 8}], "ap-yuta", "Jujutsu Kaisen"],
  ["panda", "Panda", 2, "Branco", "Guardião", "ward", "Modo Gorila", ["Guardião", {"hp": 10}], "ap-panda", "Jujutsu Kaisen"],
  ["toji", "Toji", 5, "Preto", "Combatente", "rush", "Lança Invertida", ["Combatente", {"attack": 8}], "ap-toji", "Jujutsu Kaisen"],
  ["yamamoto", "Yamamoto", 7, "Vermelho", "Mágico", "beam", "Zanka no Tachi", ["Mágico", {"magic": 8}], "ap-yamamoto", "Bleach"],
  ["renji", "Renji", 3, "Vermelho", "Combatente", "rush", "Zabimaru", ["Combatente", {"attack": 8}], "ap-renji", "Bleach"],
  ["ikkaku", "Ikkaku", 2, "Vermelho", "Combatente", "rush", "Hōzukimaru", ["Vermelho", {"attack": 10}], "ap-ikkaku", "Bleach"],
  ["orihime", "Orihime", 3, "Laranja", "Suporte", "heal", "Escudo Triplo", ["Laranja", {"hp": 10}], "ap-orihime", "Bleach"],
  ["grimmjow", "Grimmjow", 4, "Turquesa", "Combatente", "rush", "Garra de Pantera", ["Combatente", {"attack": 8}], "ap-grimmjow", "Bleach"],
  ["uryu-thousand-year-blood-war", "Uryū · Thousand-Year Blood War", 6, "Azul", "Mágico", "beam", "Antítese", ["Mágico", {"magic": 8}], "ap-uryu-thousand-year-blood-war", "Bleach"],
  ["aizen-hogyoku", "Aizen · Hōgyoku", 7, "Roxo", "Suporte", "ward", "Hipnose Completa", ["Suporte", {"hp": 8}], "ap-aizen-hogyoku", "Bleach"],
  ["byakuya", "Byakuya", 5, "Rosa", "Mágico", "beam", "Senbonzakura", ["Mágico", {"magic": 8}], "ap-byakuya", "Bleach"],
  ["rukia", "Rukia", 4, "Branco", "Mágico", "beam", "Dança da Lua Branca", ["Mágico", {"magic": 8}], "ap-rukia", "Bleach"],
  ["yhwach", "Yhwach", 8, "Preto", "Suporte", "ward", "The Almighty", ["Suporte", {"hp": 8}], "ap-yhwach", "Bleach"],
  ["ichigo-bankai-verdadeiro", "Ichigo · Bankai verdadeiro", 7, "Preto", "Combatente", "rush", "Getsuga Duplo", ["Combatente", {"attack": 8}], "ap-ichigo-bankai-verdadeiro", "Bleach"],
  ["kenpachi", "Kenpachi", 6, "Preto", "Combatente", "rush", "Corte do Desafio", ["Combatente", {"attack": 8}], "ap-kenpachi", "Bleach"],
  ["shanks", "Shanks", 7, "Vermelho", "Combatente", "rush", "Corte do Imperador", ["Combatente", {"attack": 8}], "ap-shanks", "One Piece"],
  ["portgas-d-ace", "Portgas D. Ace", 5, "Vermelho", "Mágico", "beam", "Hiken", ["Mágico", {"magic": 8}], "ap-portgas-d-ace", "One Piece"],
  ["sanji", "Sanji", 4, "Laranja", "Combatente", "rush", "Diable Jambe", ["Combatente", {"attack": 8}], "ap-sanji", "One Piece"],
  ["kaido", "Kaido", 7, "Azul", "Guardião", "ward", "Sopro do Dragão", ["Guardião", {"defense": 8}], "ap-kaido", "One Piece"],
  ["chopper", "Chopper", 2, "Rosa", "Suporte", "heal", "Primeiros Socorros", ["Suporte", {"magic": 10}], "ap-chopper", "One Piece"],
  ["barba-branca-auge", "Barba Branca · auge", 8, "Branco", "Combatente", "rush", "Tremor do Mar", ["Combatente", {"attack": 8}], "ap-barba-branca-auge", "One Piece"],
  ["luffy-gear-5", "Luffy · Gear 5", 7, "Branco", "Combatente", "rush", "Ricochete", ["Combatente", {"attack": 8}], "ap-luffy-gear-5", "One Piece"],
  ["gol-d-roger", "Gol D. Roger", 8, "Dourado", "Combatente", "rush", "Investida do Rei", ["Combatente", {"attack": 8}], "ap-gol-d-roger", "One Piece"],
  ["alucard", "Alucard", 6, "Vermelho", "Combatente", "rush", "Regeneração Sombria", ["Combatente", {"attack": 8}], "ap-alucard", "Hellsing"],
  ["ban-pos-purgatorio", "Ban · pós-Purgatório", 6, "Vermelho", "Combatente", "rush", "Snatch", ["Combatente", {"attack": 8}], "ap-ban-pos-purgatorio", "Nanatsu no Taizai"],
  ["diane", "Diane", 4, "Laranja", "Guardião", "ward", "Muralha de Gideon", ["Guardião", {"defense": 8}], "ap-diane", "Nanatsu no Taizai"],
  ["gilthunder", "Gilthunder", 3, "Amarelo", "Combatente", "rush", "Lâmina de Raio", ["Amarelo", {"attack": 10}], "ap-gilthunder", "Nanatsu no Taizai"],
  ["king-asas-completas", "King · asas completas", 6, "Verde", "Mágico", "beam", "Chastiefol", ["Mágico", {"magic": 8}], "ap-king-asas-completas", "Nanatsu no Taizai"],
  ["howzer", "Howzer", 2, "Turquesa", "Mágico", "beam", "Rajada Giratória", ["Turquesa", {"magic": 10}], "ap-howzer", "Nanatsu no Taizai"],
  ["merlin", "Merlin", 6, "Roxo", "Suporte", "ward", "Infinity", ["Suporte", {"hp": 8}], "ap-merlin", "Nanatsu no Taizai"],
  ["gowther", "Gowther", 4, "Rosa", "Suporte", "ward", "Invasão", ["Suporte", {"hp": 8}], "ap-gowther", "Nanatsu no Taizai"],
  ["hawk", "Hawk", 1, "Rosa", "Suporte", "heal", "Resgate do Capitão", ["Rosa", {"hp": 8}], "ap-hawk", "Nanatsu no Taizai"],
  ["elizabeth-poderes-de-deusa", "Elizabeth · poderes de Deusa", 5, "Branco", "Suporte", "heal", "Luz Restauradora", ["Suporte", {"hp": 8}], "ap-elizabeth-poderes-de-deusa", "Nanatsu no Taizai"],
  ["meliodas-magia-verdadeira", "Meliodas · magia verdadeira", 8, "Preto", "Combatente", "rush", "Destruição Demoníaca", ["Combatente", {"attack": 8}], "ap-meliodas-magia-verdadeira", "Nanatsu no Taizai"],
  ["rei-dos-demonios", "Rei dos Demônios", 8, "Preto", "Guardião", "ward", "O Governante", ["Guardião", {"defense": 8}], "ap-rei-dos-demonios", "Nanatsu no Taizai"],
  ["escanor-the-one-ultimate", "Escanor · The One Ultimate", 7, "Dourado", "Combatente", "rush", "Sol Definitivo", ["Combatente", {"attack": 8}], "ap-escanor-the-one-ultimate", "Nanatsu no Taizai"],
  ["metal-bat", "Metal Bat", 5, "Vermelho", "Combatente", "rush", "Espírito de Luta", ["Combatente", {"attack": 8}], "ap-metal-bat", "One Punch Man"],
  ["genos", "Genos", 5, "Laranja", "Mágico", "beam", "Canhão Incinerador", ["Mágico", {"magic": 8}], "ap-genos", "One Punch Man"],
  ["saitama", "Saitama", 8, "Amarelo", "Combatente", "rush", "Soco Sério", ["Combatente", {"attack": 8}], "ap-saitama", "One Punch Man"],
  ["snek", "Snek", 2, "Amarelo", "Combatente", "rush", "Punho da Cobra", ["Amarelo", {"attack": 10}], "ap-snek", "One Punch Man"],
  ["tatsumaki", "Tatsumaki", 6, "Verde", "Mágico", "beam", "Tornado Psíquico", ["Mágico", {"magic": 8}], "ap-tatsumaki", "One Punch Man"],
  ["fubuki", "Fubuki", 4, "Verde", "Suporte", "beam", "Barreira Psíquica", ["Suporte", {"hp": 8}], "ap-fubuki", "One Punch Man"],
  ["mumen-rider", "Mumen Rider", 1, "Verde", "Guardião", "ward", "Investida da Justiça", ["Verde", {"hp": 8}], "ap-mumen-rider", "One Punch Man"],
  ["bang", "Bang", 5, "Azul", "Guardião", "ward", "Punho da Água Corrente", ["Guardião", {"defense": 8}], "ap-bang", "One Punch Man"],
  ["tanktop-master", "Tanktop Master", 3, "Azul", "Guardião", "ward", "Arremesso Tanktop", ["Guardião", {"defense": 8}], "ap-tanktop-master", "One Punch Man"],
  ["blast", "Blast", 7, "Roxo", "Guardião", "ward", "Portais Dimensionais", ["Guardião", {"defense": 8}], "ap-blast", "One Punch Man"],
  ["flashy-flash", "Flashy Flash", 5, "Branco", "Combatente", "rush", "Corte Instantâneo", ["Combatente", {"attack": 8}], "ap-flashy-flash", "One Punch Man"],
  ["garou-cosmico", "Garou Cósmico", 8, "Preto", "Combatente", "rush", "Cópia Cósmica", ["Combatente", {"attack": 8}], "ap-garou-cosmico", "One Punch Man"],
  ["vash", "Vash", 5, "Vermelho", "Suporte", "beam", "Disparo de Desarme", ["Suporte", {"hp": 8}], "ap-vash", "Trigun"],
  ["kurapika", "Kurapika", 4, "Vermelho", "Guardião", "ward", "Corrente Restritiva", ["Guardião", {"defense": 8}], "ap-kurapika", "Hunter × Hunter"],
  ["knuckle", "Knuckle", 3, "Laranja", "Combatente", "rush", "Hakoware", ["Combatente", {"attack": 8}], "ap-knuckle", "Hunter × Hunter"],
  ["meruem-pos-rosa", "Meruem · pós-Rosa", 8, "Verde", "Combatente", "rush", "Evolução do Rei", ["Combatente", {"attack": 8}], "ap-meruem-pos-rosa", "Hunter × Hunter"],
  ["killua", "Killua", 4, "Turquesa", "Combatente", "rush", "Godspeed", ["Combatente", {"attack": 8}], "ap-killua", "Hunter × Hunter"],
  ["leorio", "Leorio", 2, "Azul", "Suporte", "heal", "Atendimento Rápido", ["Suporte", {"magic": 10}], "ap-leorio", "Hunter × Hunter"],
  ["zushi", "Zushi", 1, "Azul", "Guardião", "ward", "Ten", ["Azul", {"resistance": 8}], "ap-zushi", "Hunter × Hunter"],
  ["hisoka", "Hisoka", 5, "Roxo", "Combatente", "rush", "Bungee Gum", ["Combatente", {"attack": 8}], "ap-hisoka", "Hunter × Hunter"],
  ["neferpitou", "Neferpitou", 6, "Rosa", "Combatente", "rush", "Terpsichora", ["Combatente", {"attack": 8}], "ap-neferpitou", "Hunter × Hunter"],
  ["biscuit", "Biscuit", 5, "Rosa", "Suporte", "beam", "Cookie", ["Suporte", {"hp": 8}], "ap-biscuit", "Hunter × Hunter"],
  ["chrollo", "Chrollo", 5, "Preto", "Mágico", "beam", "Skill Hunter", ["Mágico", {"magic": 8}], "ap-chrollo", "Hunter × Hunter"],
  ["gon-transformacao-adulta", "Gon · transformação adulta", 7, "Dourado", "Combatente", "rush", "Jajanken Final", ["Combatente", {"attack": 8}], "ap-gon-transformacao-adulta", "Hunter × Hunter"],
  ["inuyasha", "Inuyasha", 4, "Vermelho", "Combatente", "rush", "Cicatriz do Vento", ["Combatente", {"attack": 8}], "ap-inuyasha", "Inuyasha"],
  ["edward-elric", "Edward Elric", 3, "Vermelho", "Guardião", "ward", "Transmutação Relâmpago", ["Guardião", {"defense": 8}], "ap-edward-elric", "Fullmetal Alchemist"],
  ["kenshin-himura", "Kenshin Himura", 3, "Vermelho", "Combatente", "rush", "Saque Relâmpago", ["Combatente", {"attack": 8}], "ap-kenshin-himura", "Rurouni Kenshin"],
  ["magna", "Magna", 1, "Vermelho", "Mágico", "beam", "Bola de Fogo", ["Vermelho", {"magic": 8}], "ap-magna", "Black Clover"],
  ["mereoleona", "Mereoleona", 6, "Laranja", "Combatente", "rush", "Calidus Brachium", ["Combatente", {"attack": 8}], "ap-mereoleona", "Black Clover"],
  ["luck", "Luck", 4, "Amarelo", "Combatente", "rush", "Salto Relâmpago", ["Combatente", {"attack": 8}], "ap-luck", "Black Clover"],
  ["finral", "Finral", 2, "Verde", "Suporte", "ward", "Portal de Retirada", ["Verde", {"resistance": 10}], "ap-finral", "Black Clover"],
  ["noelle", "Noelle", 4, "Azul", "Guardião", "ward", "Berço do Dragão Marinho", ["Guardião", {"defense": 8}], "ap-noelle", "Black Clover"],
  ["zagred", "Zagred", 6, "Roxo", "Mágico", "beam", "Palavra Manifestada", ["Mágico", {"magic": 8}], "ap-zagred", "Black Clover"],
  ["vanessa", "Vanessa", 3, "Rosa", "Suporte", "beam", "Fio de Rouge", ["Suporte", {"hp": 8}], "ap-vanessa", "Black Clover"],
  ["licht", "Licht", 6, "Branco", "Guardião", "ward", "Espada Absorvente", ["Guardião", {"defense": 8}], "ap-licht", "Black Clover"],
  ["asta-devil-union", "Asta · Devil Union", 7, "Preto", "Combatente", "rush", "Antimagia", ["Combatente", {"attack": 8}], "ap-asta-devil-union", "Black Clover"],
  ["yami", "Yami", 5, "Preto", "Combatente", "rush", "Corte Dimensional", ["Combatente", {"attack": 8}], "ap-yami", "Black Clover"],
  ["lucius-zogratis", "Lucius Zogratis", 8, "Dourado", "Suporte", "ward", "Reescrita Temporal", ["Suporte", {"hp": 8}], "ap-lucius-zogratis", "Black Clover"],
  ["yuno-star-magic", "Yuno · Star Magic", 7, "Dourado", "Mágico", "beam", "Constelação", ["Mágico", {"magic": 8}], "ap-yuno-star-magic", "Black Clover"],
  ["naruto-modo-kurama", "Naruto · Modo Kurama", 6, "Laranja", "Combatente", "rush", "Manto da Raposa", ["Combatente", {"attack": 8}], "ap-naruto-modo-kurama", "Naruto"],
  ["gaara", "Gaara", 4, "Laranja", "Guardião", "ward", "Escudo de Areia", ["Guardião", {"defense": 8}], "ap-gaara", "Naruto"],
  ["minato", "Minato", 5, "Amarelo", "Combatente", "rush", "Deus Voador do Trovão", ["Combatente", {"attack": 8}], "ap-minato", "Naruto"],
  ["tenten", "Tenten", 1, "Turquesa", "Combatente", "rush", "Chuva de Armas", ["Combatente", {"attack": 8}], "ap-tenten", "Naruto"],
  ["kakashi-mangekyo", "Kakashi · Mangekyō", 5, "Azul", "Mágico", "beam", "Kamui", ["Mágico", {"magic": 8}], "ap-kakashi-mangekyo", "Naruto"],
  ["iruka", "Iruka", 1, "Azul", "Suporte", "ward", "Instrução de Campo", ["Azul", {"defense": 8}], "ap-iruka", "Naruto"],
  ["kaguya-otsutsuki", "Kaguya Ōtsutsuki", 8, "Branco", "Mágico", "beam", "Troca Dimensional", ["Mágico", {"magic": 8}], "ap-kaguya-otsutsuki", "Naruto"],
  ["neji", "Neji", 3, "Branco", "Guardião", "ward", "Rotação", ["Branco", {"defense": 10}], "ap-neji", "Naruto"],
  ["madara-dez-caudas", "Madara · Dez-Caudas", 7, "Preto", "Mágico", "beam", "Esferas da Verdade", ["Mágico", {"magic": 8}], "ap-madara-dez-caudas", "Naruto"],
  ["shikamaru", "Shikamaru", 2, "Preto", "Suporte", "ward", "Possessão das Sombras", ["Preto", {"resistance": 10}], "ap-shikamaru", "Naruto"],
  ["hagoromo-otsutsuki", "Hagoromo Ōtsutsuki", 8, "Dourado", "Suporte", "heal", "Chakra dos Seis Caminhos", ["Suporte", {"hp": 8}], "ap-hagoromo-otsutsuki", "Naruto"],
  ["arataka-reigen", "Arataka Reigen", 2, "Laranja", "Suporte", "ward", "Conversa Convincente", ["Suporte", {"defense": 10}], "ap-arataka-reigen", "Mob Psycho 100"],
  ["speedwagon", "Speedwagon", 1, "Laranja", "Suporte", "ward", "Apoio de Campo", ["Laranja", {"hp": 8}], "ap-speedwagon", "JoJo"],
  ["dio", "DIO", 6, "Amarelo", "Combatente", "rush", "The World", ["Combatente", {"attack": 8}], "ap-dio", "JoJo"],
  ["joseph-jovem", "Joseph · jovem", 2, "Amarelo", "Suporte", "ward", "Armadilha de Hamon", ["Amarelo", {"defense": 10}], "ap-joseph-jovem", "JoJo"],
  ["kakyoin", "Kakyoin", 4, "Verde", "Mágico", "beam", "Emerald Splash", ["Mágico", {"magic": 8}], "ap-kakyoin", "JoJo"],
  ["polnareff", "Polnareff", 4, "Azul", "Combatente", "rush", "Silver Chariot", ["Combatente", {"attack": 8}], "ap-polnareff", "JoJo"],
  ["jotaro", "Jotaro", 6, "Roxo", "Combatente", "rush", "Star Platinum", ["Combatente", {"attack": 8}], "ap-jotaro", "JoJo"],
  ["johnny-tusk-act-4", "Johnny · Tusk Act 4", 7, "Rosa", "Mágico", "beam", "Rotação Infinita", ["Mágico", {"magic": 8}], "ap-johnny-tusk-act-4", "JoJo"],
  ["josuke-parte-4", "Josuke · Parte 4", 5, "Rosa", "Suporte", "heal", "Crazy Diamond", ["Suporte", {"hp": 8}], "ap-josuke-parte-4", "JoJo"],
  ["pucci-made-in-heaven", "Pucci · Made in Heaven", 7, "Branco", "Combatente", "rush", "Contagem Acelerada", ["Combatente", {"attack": 8}], "ap-pucci-made-in-heaven", "JoJo"],
  ["bruno-bucciarati", "Bruno Bucciarati", 4, "Branco", "Guardião", "ward", "Sticky Fingers", ["Guardião", {"defense": 8}], "ap-bruno-bucciarati", "JoJo"],
  ["koichi", "Koichi", 3, "Branco", "Mágico", "beam", "Echoes Act 3", ["Mágico", {"magic": 8}], "ap-koichi", "JoJo"],
  ["giorno-gold-experience-requiem", "Giorno · Gold Experience Requiem", 8, "Dourado", "Suporte", "ward", "Retorno a Zero", ["Suporte", {"hp": 8}], "ap-giorno-gold-experience-requiem", "JoJo"],
  ["misaka-mikoto", "Misaka Mikoto", 4, "Amarelo", "Mágico", "beam", "Railgun", ["Mágico", {"magic": 8}], "ap-misaka-mikoto", "Toaru"],
  ["simon-tengen-toppa", "Simon · Tengen Toppa Gurren Lagann", 8, "Verde", "Combatente", "rush", "Força Espiral", ["Combatente", {"attack": 8}], "ap-simon-tengen-toppa", "Gurren Lagann"],
  ["frieren", "Frieren", 5, "Turquesa", "Mágico", "beam", "Zoltraak", ["Mágico", {"magic": 8}], "ap-frieren", "Frieren"],
  ["rimuru-tempest", "Rimuru Tempest", 8, "Azul", "Guardião", "ward", "Predação", ["Guardião", {"defense": 8}], "ap-rimuru-tempest", "Tensei Shitara Slime Datta Ken"],
  ["tetsuo-shima", "Tetsuo Shima", 7, "Roxo", "Mágico", "beam", "Colapso Psíquico", ["Mágico", {"magic": 8}], "ap-tetsuo-shima", "Akira"],
  ["ultimate-madoka", "Madoka Kaname · Ultimate Madoka", 8, "Rosa", "Suporte", "ward", "Lei dos Ciclos", ["Suporte", {"hp": 8}], "ap-ultimate-madoka", "Madoka Magica"],
  ["eternal-sailor-moon", "Eternal Sailor Moon", 8, "Branco", "Suporte", "heal", "Luz da Lua Eterna", ["Suporte", {"hp": 8}], "ap-eternal-sailor-moon", "Sailor Moon"],
  ["anos-voldigoad", "Anos Voldigoad", 7, "Preto", "Mágico", "beam", "Destruição da Fonte", ["Mágico", {"magic": 8}], "ap-anos-voldigoad", "The Misfit of Demon King Academy"],
];
const approvedArt = {"hoova-shisui":"hoova-shisui","zawa-cheon":"zawa-cheon","careca-kumagawa":"careca-kumagawa",
  "yamcha": "yamcha",
  "bulma": "bulma",
  "piccolo": "piccolo",
  "kuririn": "kuririn",
  "gohan": "gohan-namek",
  "tenshinhan": "tenshinhan",
  "freeza": "freeza-forma-final",
  "android17": "android-17-torneio-do-poder",
  "vegeta": "vegeta-super-saiyajin-blue",
  "broly": "broly-super",
  "goku": "goku-instinto-superior",
  "beerus": "beerus",
  "usopp": "usopp",
  "nami": "nami",
  "rocklee": "rock-lee",
  "zoro": "zoro",
  "law": "trafalgar-law",
  "gojo": "gojo",
  "netero": "netero",
  "mob": "mob-por-cento",
  "accelerator": "accelerator",
  "shinra_banshoman": "shinra-banshoman",
  "benimaru_shinmon": "benimaru-shinmon",
  "luminous": "luminous-valentine",
  "veldora": "veldora-tempest",
  "shinra": "shinra-kusakabe",
  "arthur": "arthur-boyle",
  "maki_oze": "maki-oze",
  "iris": "iris",
  "mayuri": "mayuri-kurotsuchi",
  "starrk": "coyote-starrk",
  "yoruichi": "yoruichi-shihoin",
  "urahara": "kisuke-urahara",
  "sukuna-forma-original": "sukuna-forma-original",
  "nanami": "nanami",
  "maki-desperta": "maki-desperta",
  "aoi-todo": "aoi-todo",
  "kasumi-miwa": "kasumi-miwa",
  "kenjaku": "kenjaku",
  "nobara": "nobara",
  "mahoraga": "mahoraga",
  "yuta": "yuta",
  "panda": "panda",
  "toji": "toji",
  "yamamoto": "yamamoto",
  "renji": "renji",
  "ikkaku": "ikkaku",
  "orihime": "orihime",
  "grimmjow": "grimmjow",
  "uryu-thousand-year-blood-war": "uryu-thousand-year-blood-war",
  "aizen-hogyoku": "aizen-hogyoku",
  "byakuya": "byakuya",
  "rukia": "rukia",
  "yhwach": "yhwach",
  "ichigo-bankai-verdadeiro": "ichigo-bankai-verdadeiro",
  "kenpachi": "kenpachi",
  "shanks": "shanks",
  "portgas-d-ace": "portgas-d-ace",
  "sanji": "sanji",
  "kaido": "kaido",
  "chopper": "chopper",
  "barba-branca-auge": "barba-branca-auge",
  "luffy-gear-5": "luffy-gear-5",
  "gol-d-roger": "gol-d-roger",
  "alucard": "alucard",
  "ban-pos-purgatorio": "ban-pos-purgatorio",
  "diane": "diane",
  "gilthunder": "gilthunder",
  "king-asas-completas": "king-asas-completas",
  "howzer": "howzer",
  "merlin": "merlin",
  "gowther": "gowther",
  "hawk": "hawk",
  "elizabeth-poderes-de-deusa": "elizabeth-poderes-de-deusa",
  "meliodas-magia-verdadeira": "meliodas-magia-verdadeira",
  "rei-dos-demonios": "rei-dos-demonios",
  "escanor-the-one-ultimate": "escanor-the-one-ultimate",
  "metal-bat": "metal-bat",
  "genos": "genos",
  "saitama": "saitama",
  "snek": "snek",
  "tatsumaki": "tatsumaki",
  "fubuki": "fubuki",
  "mumen-rider": "mumen-rider",
  "bang": "bang",
  "tanktop-master": "tanktop-master",
  "blast": "blast",
  "flashy-flash": "flashy-flash",
  "garou-cosmico": "garou-cosmico",
  "vash": "vash",
  "kurapika": "kurapika",
  "knuckle": "knuckle",
  "meruem-pos-rosa": "meruem-pos-rosa",
  "killua": "killua",
  "leorio": "leorio",
  "zushi": "zushi",
  "hisoka": "hisoka",
  "neferpitou": "neferpitou",
  "biscuit": "biscuit",
  "chrollo": "chrollo",
  "gon-transformacao-adulta": "gon-transformacao-adulta",
  "inuyasha": "inuyasha",
  "edward-elric": "edward-elric",
  "kenshin-himura": "kenshin-himura",
  "magna": "magna",
  "mereoleona": "mereoleona",
  "luck": "luck",
  "finral": "finral",
  "noelle": "noelle",
  "zagred": "zagred",
  "vanessa": "vanessa",
  "licht": "licht",
  "asta-devil-union": "asta-devil-union",
  "yami": "yami",
  "lucius-zogratis": "lucius-zogratis",
  "yuno-star-magic": "yuno-star-magic",
  "naruto-modo-kurama": "naruto-modo-kurama",
  "gaara": "gaara",
  "minato": "minato",
  "tenten": "tenten",
  "kakashi-mangekyo": "kakashi-mangekyo",
  "iruka": "iruka",
  "kaguya-otsutsuki": "kaguya-otsutsuki",
  "neji": "neji",
  "madara-dez-caudas": "madara-dez-caudas",
  "shikamaru": "shikamaru",
  "hagoromo-otsutsuki": "hagoromo-otsutsuki",
  "arataka-reigen": "arataka-reigen",
  "speedwagon": "speedwagon",
  "dio": "dio",
  "joseph-jovem": "joseph-jovem",
  "kakyoin": "kakyoin",
  "polnareff": "polnareff",
  "jotaro": "jotaro",
  "johnny-tusk-act-4": "johnny-tusk-act-4",
  "josuke-parte-4": "josuke-parte-4",
  "pucci-made-in-heaven": "pucci-made-in-heaven",
  "bruno-bucciarati": "bruno-bucciarati",
  "koichi": "koichi",
  "giorno-gold-experience-requiem": "giorno-gold-experience-requiem",
  "misaka-mikoto": "misaka-mikoto",
  "simon-tengen-toppa": "simon-tengen-toppa",
  "frieren": "frieren",
  "rimuru-tempest": "rimuru-tempest",
  "tetsuo-shima": "tetsuo-shima",
  "ultimate-madoka": "ultimate-madoka",
  "eternal-sailor-moon": "eternal-sailor-moon",
  "anos-voldigoad": "anos-voldigoad"
};

function spriteFor(unit){
  const slug=approvedArt[unit.id];
  if(!slug)return CHARACTERS[unit.id].sprite;
  return "ap-"+slug+(unit.shiny?"-shiny":"");
}

const leadershipStats={hp:'PV',attack:'Ataque',magic:'Magia',defense:'Defesa',resistance:'Resistência',speed:'Velocidade'};
const leadershipKeys=Object.keys(leadershipStats);
const CHARACTERS = Object.fromEntries(roster.map(([id,name,tier,color,role,kind,skill,[scope,bonuses],sprite,universe='Dragon Ball'])=>{
  const leader=scope+' · '+Object.entries(bonuses).map(([stat,value])=>leadershipStats[stat]+' +'+value+'%').join(' e ');
  return [id,{id,name,tier,color,role,kind,skill,leader,scope,leadership:leadershipKeys.map(k=>(bonuses[k]??0)/100),
    sprite:approvedArt[id]?'ap-'+approvedArt[id]:sprite,universe}];
}));
const SKILL_EFFECTS = {
  koto:'Genjutsu de 150% da Magia. A próxima habilidade do alvo causa 35% menos dano. Na Arena, causa 175% da Magia e marca por 4 s, reduzindo o próximo golpe em 40%. Recarga de 8 s.',
  demonSword:'Três cortes de 65% do Ataque. O terceiro ignora metade da Defesa. Na Arena, dispara duas lâminas de 70%. Se alguma acertar, lança um corte de 100% que ignora metade da Defesa. Recarga de 7 s.',
  fiction:'Na campanha, apaga um golpe fatal contra si uma vez por batalha. Na Arena, lança um parafuso de 130% da Magia e protege o aliado ativo por 4 s. Apaga até 180% da Magia em dano do próximo golpe. Recarga de 10 s.',
  room:'ROOM cura o aliado em campo com a menor fração de PV em 150% da Magia. Gamma Knife atinge o inimigo com 135% da Magia e ignora 40% da Resistência. Recarga de 8 s. Nos duelos de bolas, ROOM abre onde Law ativou a habilidade, e o corte exige que o adversário toque o campo.',
  benihime:'Escudo de 220% da Magia no aliado em campo com a menor fração de PV e corte de 105% da Magia no adversário. Recarga de 8 s.',
  barreira:'Concede a cada aliado em campo um escudo de 100% da Defesa de Android 17. O próprio Android recebe 180% se estiver em campo. Recarga de 9 s.',
  death_ray:'Raio de 175% da Magia que ignora 25% da Resistência. Abaixo de 35% dos PV do alvo, passa para 235% da Magia. Recarga de 7 s.',
  final_flash:'Disparo de 215% do Ataque que causa dano dobrado a escudos. Recarga de 8 s.',
  furia:'Golpe de 165% do Ataque. Cada uso aumenta o próximo em 25 pontos percentuais, até 240%. Recarga de 6 s.',
  instinto:'Dois golpes de 100% do Ataque. Prepara uma esquiva de alvo único se estiver sem cargas. Recarga de 8 s.',
  dominio:'Atinge cada inimigo em campo com 155% da Magia em área e bloqueia suas ações por 1,5 s. Recarga de 12 s.',
  bodisatva:'Três golpes de 65% do Ataque. O terceiro ignora metade da Defesa. Recarga de 7 s.',
  despertar:'Onda de 165% da Magia contra todos os inimigos em campo. Com metade dos PV ou menos, Mob dispara a onda com 225%. Recarga de 9 s.',
  reescrita:"Golpeia com 190% do Ataque. Uma vez por luta, se um aliado em campo estiver com até 40% de PV, usa a ação para restaurar metade dos PV máximos do mais ferido. Recarga de 9 s.",
  nichirin:"Atinge o alvo com 180% do Ataque e os demais inimigos a até 28 unidades dele com 85% do Ataque. Recarga de 10 s.",
  ciclo_vital:"Cura em 200% da Magia o aliado em campo com a menor porcentagem de PV e atinge o adversário com 105% da Magia. Recarga de 9 s.",
  tempestade:"Desfere um raio de 185% da Magia que ignora 30% da Resistência. Um arco secundário de 75% da Magia atinge outro inimigo em campo, se houver. Recarga de 10 s.",

  ashisogi:"Enfraquece os ataques básicos do alvo em 35% por 4 s e causa dano mágico de 130% da Magia. Recarga de 9 s.",
  metralleta:"Dispara três tiros de 60% da Magia contra o mesmo alvo. Recarga de 9 s.",
  shunko:"Golpeia com 140% do Ataque e ganha uma carga de esquiva contra um golpe de alvo único. Recarga de 12 s.",
  excalibur:"O corte de plasma causa 145% do Ataque e ignora 35% da Defesa do alvo. Recarga de 7 s.",

  piccolo:'Cria um escudo de 110% da Magia e pode interceptar um golpe contra um aliado próximo nos 4,5 s seguintes.',
  bulma:'Aplica um escudo de 200% da Magia ao aliado com a menor porcentagem de PV, quando ele tem 95% de PV ou menos.',
  heal:'Cura o aliado com a menor porcentagem de PV em 130% da Magia, quando ele tem 95% de PV ou menos.',
  yamcha:'Causa dano físico equivalente a 160% do Ataque.',
  kuririn:'Causa dano mágico equivalente a 165% da Magia ao inimigo com menos PV.',
  beam:'Causa dano mágico equivalente a 165% da Magia.',
  beerus:'Remove o escudo, causa dano mágico equivalente a 240% da Magia e bloqueia a ressurreição se o golpe for fatal.',
  accelerator:'Reflete até duas habilidades de alvo único por luta, com recarga de 8 s e alcance de um espaço na ordem da formação.',
};
SKILL_EFFECTS.ward=SKILL_EFFECTS.piccolo;
SKILL_EFFECTS.rush=SKILL_EFFECTS.yamcha;
const recruitPools = TIERS.map((_,i)=>Object.values(CHARACTERS).filter(c=>c.tier===i+1));
const chanceByTier = [.55,.27,.12,.045,.012,.0025,.00045,.00005];
const passives={
  'Haki do Rei':'Ao iniciar a luta, trava as ações inimigas por 2 s. Durante esse período, os inimigos recebem 30% mais dano. Uma ativação por equipe.',
  'Instinto Superior':'Esquiva dos três primeiros golpes diretos de alvo único e contra-ataca o agressor se ele estiver em campo e o portador puder agir.',
  'Restrição Celestial':'Intercepta os dois primeiros golpes de alvo único contra aliados próximos e sofre metade do dano. Na Arena, pode proteger o titular da reserva.',
  'Haki da Observação':'Até duas vezes por luta, antecipa uma habilidade de alvo único com um golpe de 200% do dano básico. Eliminar o atacante cancela a habilidade.',
  'Zenkai':'Uma vez por luta, sobrevive a um golpe fatal com 40% dos PV máximos e ganha +75% de Ataque e Magia até o fim do combate.',
  'Full Counter':'Reflete a primeira habilidade mágica de alvo único que atingir o portador ou um aliado próximo. Devolve o dobro do dano-base da habilidade.',
  'The World':'Após a primeira habilidade principal bem-sucedida, para o tempo por 3 s. Só o portador pode agir e sua habilidade fica pronta outra vez.',
  'Voto de Nen':'Última Aposta é opcional. Ative na ficha para causar 4× o dano e ocupar duas vagas. Desative para voltar a usar uma vaga e conservar os bônus de atributos.',
  'Made in Heaven':'Causa 4× o dano durante toda a luta e ocupa uma vaga. Na primeira ação ofensiva, ativa Aceleração do Tempo por 5 s. O intervalo de ações cai 80% para o portador e 40% para aliados. A aceleração coletiva não acumula.'
};
const T=(name,odds,buffs)=>({name,odds,buffs,passive:passives[name]??null,
  rarity:TIERS[odds<=5?0:odds<=10?1:odds<=25?2:odds<=50?3:odds<=125?4:odds<=250?5:odds<=1000?6:7]});
const TRAITS = [T('Concentração Total',4,[.3,0,0,0,0,0]),T('Reforço Amaldiçoado',5,[0,.25,.25,0,0,0]),T('Haki do Armamento',10,[0,0,0,.4,0,0]),T('Ten',10,[0,0,0,0,.4,0]),T('Kaidō',20,[0,0,.35,0,.2,0]),T('Shunpo',20,[0,.2,0,0,0,.35]),T('Modo Sábio',25,[.35,0,0,.25,.25,0]),T('Respiração do Trovão',25,[0,.4,0,0,0,.25]),T('Haki do Rei',50,[.3,.5,.5,0,0,0]),T('Instinto Superior',100,[0,.4,.4,0,0,.5]),T('Restrição Celestial',125,[.6,0,0,.5,.5,0]),T('Haki da Observação',125,[0,.4,0,.4,0,0]),T('Zenkai',200,[.45,0,0,.35,0,0]),T('Full Counter',250,[0,0,0,.6,.6,0]),T('The World',500,[0,.6,.6,0,0,.4]),T('Voto de Nen',1000,[.6,0,0,.4,.4,0]),T('Made in Heaven',2000,[0,0,0,0,.5,0])];
const initial = ['piccolo','yamcha','kuririn','bulma'];
const position = [[72,47],[56,72],[39,28],[22,59]];
const HOUR = 3600000;
const UPGRADES = {
  ritmo:{name:'Ritmo de expedição',worlds:[1,2,4,6,8],costs:[120,1800,15000,80000,240000],values:[10,9,8,7,6,5],unit:' s',description:'Reduz a espera entre encontros.'},
  sorte:{name:'Sorte',worlds:[1,1,1,2,3,5,7,8,10],costs:[50,125,300,1000,3500,12000,36000,90000,200000],values:[10,20,30,40,50,60,70,80,90,100],unit:'%',description:'Até 50%, aumenta a chance de encontrar um recruta em lutas comuns. Cada ponto acima de 50% aumenta em 1% relativo a chance de esse recruta ser Raro ou superior.'},
  ouro:{name:'Bônus de ouro',worlds:[1,1,1,2,4,6,8],costs:[75,180,400,2000,18000,90000,250000],values:[0,10,20,30,35,40,45,50],unit:'%',description:'Acrescenta ouro às vitórias em encontros comuns e de elite.'},
  xp:{name:'Experiência compartilhada',worlds:[1,1,1,2,4,6,8],costs:[60,150,325,1600,14000,75000,210000],values:[0,25,40,60,70,80,90,100],unit:'%',description:'Distribui entre os reservas uma fração da XP que um titular recebe por vitória. Cada titular mantém sua recompensa integral.'},
  rastreio:{name:'Rastreio de raros',worlds:[1,2,4,6,9],costs:[100,600,4500,24000,100000],values:[18,20,24,28,32,36],unit:'%',description:'Chance de um recruta ser de raridade Rara ou superior. Cada uma dessas raridades recebe o mesmo aumento proporcional.'},
  treino:{name:'Treino de combate',worlds:[1,2,4,7],costs:[80,700,5000,30000],values:[0,10,20,30,40],unit:'%',description:'Aumenta a XP por vitória na campanha. O bônus também entra no cálculo da experiência compartilhada.'},
  enfermaria:{name:'Enfermaria',worlds:[1,3,5,8],costs:[90,1000,6500,45000],values:[20,18,16,14,12],unit:' s',description:'Reduz o tempo de recuperação de titulares derrotados na exploração, inclusive quando a equipe inteira cai.'},
};
const xpFor = level => 16 + level*5 + Math.round(.14*level**2);
const scale = level => 1 + .1*(level-1) + .001*(level-1)**2;
const thresholds=[0,0];
for(let level=1;level<100;level++)thresholds.push(thresholds[level]+xpFor(level));
const xpTo=level=>thresholds[level];
function levelAt(xp){
  let low=1,high=100;
  while(low<high){const mid=Math.ceil((low+high)/2);if(xp>=thresholds[mid])low=mid;else high=mid-1;}
  return low;
}
function xpProgress(xp,cap=100){
  const level=levelAt(xp);
  return {level,current:xp-xpTo(level),required:level<cap?xpFor(level):0};
}
const maxLevel = state=>Math.max(1,...state.team.map(id=>levelAt(state.collection.find(x=>x.uid===id).xp)));
const readyForBoss = state=>state.team.length>0 && state.finalWins>=(state.bossGoal??12) && !state.completed;
const upgradeLevel = (state,id)=>state.upgrades?.[id]??(id==='ritmo'&&state.upgraded?1:0);
const upgradeValue = (state,id)=>UPGRADES[id].values[upgradeLevel(state,id)];
const waitFor = state=>upgradeValue(state,'ritmo')*1000;

function buyUpgrade(state,id){
  if(!Object.hasOwn(UPGRADES,id))return false;
  const level=upgradeLevel(state,id);
  const cost=UPGRADES[id].costs[level];
  if(cost===undefined||state.gold<cost||(state.unlocked??0)+1<UPGRADES[id].worlds[level])return false;
  state.gold-=cost;
  (state.upgrades??={})[id]=level+1;
  return true;
}

function fresh(now=Date.now(),seed=Date.now()>>>0){
  const collection = initial.map(id=>({uid:`initial-${id}`,id,xp:0,serial:1,shiny:false,trait:null,odds:null}));
  return {version:1,seed,created:now,collection,team:collection.map(x=>x.uid),positions:Object.fromEntries(collection.map((x,i)=>[x.uid,position[i]])),leader:collection[0].uid,area:0,gold:0,wins:0,losses:0,finalWins:0,streak:0,upgrades:{},completed:false,world:0,unlocked:0,journey:{},autoRoutes:true,paused:false,running:true,nextAt:now,waitDuration:0,pending:null,index:0,clock:now,log:[]};
}

const starterBonus = {piccolo:[.05,0,0,.05,0,0],yamcha:[0,.05,0,0,0,.05],kuririn:[0,0,.05,0,0,0],bulma:[0,0,0,0,.05,0]};
function leaderBuff(leader,member){
  if(!leader)return [];
  return [member.role,member.color,member.universe,'Equipe'].includes(leader.scope)?leader.leadership:[];
}

function slotTraits(unit,index=unit.activeSlot??0){
  const stored=unit.traitSlots?.[index]??(index===0&&unit.trait?[unit.trait]:[]);
  return Array.isArray(stored)?[...new Set(stored)].filter(name=>TRAITS.some(t=>t.name===name)).slice(0,3):[];
}
function rollLoadout(random){
  const count=random()<.05?(random()<.01?3:2):1;
  const pool=TRAITS.slice(),picked=[];
  for(let i=0;i<count;i++){
    let weight=random()*pool.reduce((n,t)=>n+1/t.odds,0);
    const index=pool.findIndex(t=>(weight-=1/t.odds)<0);
    picked.push(pool.splice(index<0?pool.length-1:index,1)[0].name);
  }
  return picked;
}
// Exact chance for this unordered set: sum every draw order without replacement.
function loadoutChance(names){
  if(!names.length||names.length>3)return 0;
  const weights=names.map(name=>1/TRAITS.find(t=>t.name===name).odds);
  function orders(left,total){
    if(left.length===0)return 1;
    return left.reduce((p,w,i)=>p+w/total*orders(left.filter((_,j)=>j!==i),total-w),0);
  }
  return [0,.95,.0495,.0005][names.length]*orders(weights,TRAITS.reduce((n,t)=>n+1/t.odds,0));
}
function changeTraitSlot(state,action){
  const {uid,slot}=action;
  const unit=state.collection.find(u=>u.uid===uid);
  if(!unit||![0,1].includes(slot))return false;
  const slots=[slotTraits(unit,0),slotTraits(unit,1)];
  if(action.type==='reroll'){
    if(!(state.traitItems>=1)||action.roll!==(state.traitRolls??0))return false;
    state.traitRolls=(state.traitRolls??0)+1;
    recordDex(state,unit);
    slots[slot]=rollLoadout(rng(state.seed,0x54524149^state.traitRolls));
    state.traitItems--;
  }else{
    if(!slots[slot].length||slot===(unit.activeSlot??0))return false;
    unit.activeSlot=slot;
  }
  unit.traitSlots=slots;
  const active=slots[unit.activeSlot??0];
  unit.trait=active[0]??null;
  recordDex(state,unit);
  if(!active.includes('Voto de Nen'))delete unit.nen;
  return true;
}
function fighter(unit, coords=[55,50], leader=null, tactical=false){
  const card=CHARACTERS[unit.id];
  const level=levelAt(unit.xp);
  const growth=scale(level);
  const names=slotTraits(unit);
  const buffs=names.map(n=>TRAITS.find(t=>t.name===n).buffs);
  const aura=leaderBuff(leader,card);
  const [hp,attack,magic,defense,resistance,speed]=baseStats[card.tier-1].map((base,i)=>Math.round(base*(1+roles[card.role][i])*(1+(starterBonus[card.id]?.[i]||0))*(1+buffs.reduce((sum,b)=>sum+b[i],0))*(1+(aura[i]||0))*(i===5?1:growth*(unit.shiny?1.25:1))));
  const [x,y]=coords;
  return {...card,signatureAssist:card.tier>=5&&card.role==='Suporte', uid:unit.uid,trait:unit.trait,traits:names,nen:names.includes("Voto de Nen")&&unit.nen===true, level, x,y,hp,attack,magic,defense,resistance,speed,scale:growth,interval:tactical?Math.max(600,Math.round(300000/speed/100)*100):3000,magicBasic:card.role==='Mágico'||card.role==='Suporte',evade:names.includes('Instinto Superior')?3:0,survive:names.includes('Zenkai')?1:0,sprite:spriteFor(unit)};
}

function rng(seed,index){
  let state=(seed^Math.imul(index+1,2654435761))>>>0 || 1;
  return ()=>{state^=state<<13;state^=state>>>17;state^=state<<5;return (state>>>0)/4294967296;};
}
function pickTrait(random){
  let p=random();for(const t of TRAITS){p-=1/t.odds;if(p<0)return t;}return null;
}
function recruitWeights(rarePercent){
  const base=UPGRADES.rastreio.values[0];
  if(rarePercent===base)return chanceByTier;
  // Transfer probability from common units to rare and higher tiers, preserving their relative odds.
  return chanceByTier.map((weight,i)=>{
    if(i===0)return weight-(rarePercent-base)/100;
    return i===1?weight:weight*rarePercent/base;
  });
}
function recruitRates(luckPercent,rastreioPercent){
  return {encounter:Math.min(50,luckPercent),rare:rastreioPercent*(100+Math.max(0,luckPercent-50))/100};
}
function rollRecruit(random,luck=.10,universe='Dragon Ball',rarePercent=UPGRADES.rastreio.values[0]){
  const rates=recruitRates(luck*100,rarePercent);
  const chance=rates.encounter/100;
  if(random()>=chance) return null;
  let p=random(),tier=1;
  const weights=recruitWeights(rates.rare);
  for(const weight of weights){if(p<weight)break;p-=weight;tier++;}
  tier=Math.min(tier,8);
  const pool=recruitPools[tier-1];
  const local=pool.filter(c=>c.universe===universe);
  // One ticket per character globally, plus a second ticket for each local character.
  const total=pool.length+local.length;
  const ticket=Math.floor(random()*total);
  const card=ticket<pool.length?pool[ticket]:local[ticket-pool.length];
  const cardChance=(card.universe===universe?2:1)/total;
  const shinyP=.05;
  const shiny=random()<shinyP;
  const trait=pickTrait(random);
  const traitP=trait?1/trait.odds:1-TRAITS.reduce((sum,t)=>sum+1/t.odds,0);
  return {id:card.id,shiny,trait:trait?.name??null,odds:Math.round(1/(chance*weights[tier-1]*cardChance*(shiny?shinyP:1-shinyP)*traitP))};
}

const SALE_PRICES=[8,20,50,125,350,1000,3500,12000];
const RECOVERY_MS=20000;
function readyAt(state,uid){
  return Math.max(state.partyRecovery??0,state.recovery?.[uid]??0);
}
function firstReady(state){
  return Math.min(...state.team.map(uid=>readyAt(state,uid)));
}

// Faixas de dois mundos. Elites usam o ponto médio entre comum e chefe.
const enemyBonuses = [
  {hp:0, damage:0, bossHp:0, bossDamage:0},
  {hp:.05, damage:.05, bossHp:.10, bossDamage:.08},
  {hp:.10, damage:.08, bossHp:.20, bossDamage:.15},
  {hp:.15, damage:.12, bossHp:.35, bossDamage:.22},
  {hp:.20, damage:.16, bossHp:.50, bossDamage:.32}
];

function makeBattle(state,start,boss=false,towerFloor=0){
  const random=rng(state.seed,state.index++);
  const encounterWorld=towerFloor?(towerFloor-1)%WORLDS.length:state.world??0;
  const world=WORLDS[encounterWorld];
  const area=world.areas[state.area];
  const elite=!boss&&state.area===2&&state.index%7===0;
  const special=boss?world.boss:elite?world.elite:null;
  const leader=state.collection.find(c=>c.uid===state.leader);
  const available=state.team.filter(uid=>readyAt(state,uid)<=start);
  const team=available.map(uid=>fighter(state.collection.find(c=>c.uid===uid),state.positions[uid],available.includes(leader?.uid)?CHARACTERS[leader.id]:null,!!special));
  const level=towerFloor?90+towerFloor:special?special.level:Math.max(area.levels[0],Math.min(area.levels[1],maxLevel(state)+Math.floor(random()*3)-1));
  const recruit=special?null:rollRecruit(random,upgradeValue(state,'sorte')/100,world.universe,upgradeValue(state,'rastreio'));
  const grow=scale(level)*(towerFloor?1+.06*(towerFloor-1):1);
  const bonus=enemyBonuses[Math.floor(encounterWorld/2)];
  const hpBonus=boss?bonus.bossHp:elite?(bonus.hp+bonus.bossHp)/2:bonus.hp;
  const damageBonus=boss?bonus.bossDamage:elite?(bonus.damage+bonus.bossDamage)/2:bonus.damage;
  const [rawHp,rawPower,def,res]=(special?.base??area.base).map(x=>Math.round(x*grow));
  const hp=Math.round(rawHp*(1+hpBonus)),power=Math.round(rawPower*(1+damageBonus));
  const baseEnemy={name:towerFloor?`Torre ${towerFloor} · ${special.name}`:special?.name??area.enemy,hp,attack:power,magic:boss?Math.round(power*.88):power,defense:def,resistance:res,scale:grow,color:boss?world.boss.color:area.color,level,sprite:`enemy-${encounterWorld+1}-${boss?5:elite?4:state.area+1}`,interval:boss?3200:3000,skill:boss?'Ofensiva de '+special.name:null,kind:boss?world.boss.kind:null,x:60,y:50};
  const candidate = recruit ? fighter({...recruit,xp:xpTo(level)},[60,50],null,false) : null;
  const enemy = candidate ? {...baseEnemy,name:candidate.name,sprite:candidate.sprite,skill:candidate.skill,trait:candidate.trait,color:candidate.color,kind:candidate.kind, hp:Math.max(hp,Math.round(candidate.hp*1.65)),attack:Math.max(power,candidate.attack),magic:Math.max(power,candidate.magic),magicBasic:candidate.magicBasic,defense:Math.max(def,candidate.defense),resistance:Math.max(res,candidate.resistance),evade:candidate.evade,survive:candidate.survive} : baseEnemy;
  const damageBoost=boss?1.30:elite?1.45:1.55;
  enemy.attack=Math.round(enemy.attack*damageBoost);
  enemy.magic=Math.round(enemy.magic*damageBoost);
  const result=new Combate([team,[enemy]],{mode:'equipe'}).run();
  const simulatedTime=result.seconds*1000;
  const duration=Math.max(1200,Math.min(boss?16000:6000,simulatedTime/(boss?2:4)));
  const reserveShare=upgradeValue(state,'xp')/100;
  const reserves=reserveShare?state.collection.filter(unit=>!state.team.includes(unit.uid)&&unit.xp<xpTo(levelCap(state))).map(unit=>unit.uid):[];
  return {start,end:start+duration,boss,elite,towerFloor,world:encounterWorld,area:state.area,level,team,enemy,recruit,result,
    goldReward:Math.round((6+2*level)*1.2*(boss?8:(elite?2:1)*(1+upgradeValue(state,'ouro')/100))),
    xpBonus:upgradeValue(state,'treino')/100,recoveryMs:upgradeValue(state,'enfermaria')*1000,reserveShare,reserves};
}

function shareExperience(state,battle,xp){
  let available=Math.floor(xp*(battle.reserveShare??0));
  if(!available||!battle.reserves?.length)return 0;
  const maxXp=xpTo(levelCap(state));
  const reserves=new Set(battle.reserves);
  const eligible=state.collection.filter(unit=>reserves.has(unit.uid)&&unit.xp<maxXp).sort((a,b)=>b.xp-a.xp);
  let granted=0;
  for(const [index,unit] of eligible.entries()){
    const amount=Math.min(maxXp-unit.xp,Math.floor(available/(eligible.length-index)));
    unit.xp+=amount;
    available-=amount;
    granted+=amount;
  }
  return granted;
}

function saleSettings(saved){
  // Older backups can contain only the filters that were configured.
  const list=value=>Array.isArray(value)?value:[];
  const tiers=list(saved?.tiers).map(Number).filter(i=>Number.isInteger(i)&&i>=1&&i<=TIERS.length);
  const characters=list(saved?.characters).filter(id=>Object.hasOwn(CHARACTERS,id));
  const traitRules={};
  for(const [tier,rule] of Object.entries(saved?.traitRules??{})){
    if(!TIERS[Number(tier)-1]||!rule)continue;
    const below=Number(rule.below);
    traitRules[tier]={
      below:Number.isInteger(below)&&below>=0&&below<=1000000?below:0,
      names:list(rule.names).filter(name=>TRAITS.some(t=>t.name===name))
    };
  }
  return {enabled:saved?.enabled===true,tiers:[...new Set(tiers)],characters:[...new Set(characters)],traitRules};
}

function saleMatches(settings,unit){
  const tier=CHARACTERS[unit.id].tier;
  if(!settings?.enabled||!(settings.tiers?.includes(tier)||settings.characters?.includes(unit.id)))return false;
  if(!unit.trait)return true;
  const rule=settings.traitRules?.[tier];
  const trait=TRAITS.find(t=>t.name===unit.trait);
  return !!(trait&&rule&&(trait.odds<rule.below||rule.names?.includes(trait.name)));
}

function settle(state,battle){
  const entry={won:battle.result.winner===0&&battle.result.reason==='eliminação',gold:0,xp:0,reserveXp:0,teamXp:0,recruit:null,boss:battle.boss,label:battle.enemy.name,end:battle.end};
  const fallen=battle.result.events.filter(e=>e.type==='cai'&&e.actor.startsWith('0:'));
  if(fallen.length){
    state.recovery??={};
    for(const e of fallen){
      const unit=battle.team[Number(e.actor.slice(2))];
      const when=battle.start+(battle.end-battle.start)*Math.min(1,e.time/Math.max(1,battle.result.seconds*1000));
      state.recovery[unit.uid]=Math.ceil(when)+(battle.recoveryMs??RECOVERY_MS);
    }
    if(fallen.length===battle.team.length)state.partyRecovery=battle.end+(battle.recoveryMs??RECOVERY_MS);
  }
  if(entry.won){
    state.wins++;state.streak=0;
    if(battle.area===2&&!battle.boss) state.finalWins++;
    entry.xp=Math.round((8+2*battle.level)*(battle.boss?3:battle.elite?2:1)*(1+(battle.xpBonus??0)));
    entry.gold=battle.goldReward??Math.round((6+2*battle.level)*(battle.boss?8:(battle.elite?2:1)*(1+(battle.goldBonus??0))));
    if(battle.towerFloor && battle.towerFloor===(state.towerCleared??0)+1){
      state.towerCleared=battle.towerFloor;
      state.traitItems=(state.traitItems??0)+towerPrize(battle.towerFloor);
    }
    state.gold+=entry.gold;
    for(const fighter of battle.team){const copy=state.collection.find(c=>c.uid===fighter.uid);if(copy){const previous=copy.xp;copy.xp=Math.min(xpTo(levelCap(state)),previous+entry.xp);entry.teamXp+=copy.xp-previous;}}
    entry.reserveXp=shareExperience(state,battle,entry.xp);
    if(battle.recruit){
      const {id,shiny}=battle.recruit;
      const key=id+(shiny?'-shiny':'');
      const serial=1+(state.serials?.[key]??state.collection.reduce((max,c)=>c.id===id&&!!c.shiny===!!shiny?Math.max(max,c.serial):max,0));
      (state.serials??={})[key]=serial;
      const copy={...battle.recruit,uid:`catch-${state.index}`,xp:xpTo(Math.min(levelCap(state),battle.level)),serial};
      recordDex(state,copy);
      const settings=state.autoSell,tier=CHARACTERS[id].tier;
      const match=saleMatches(settings,copy);
      if(match&&state.collection.some(c=>c.id===id&&!!c.shiny===!!shiny)){
        entry.sold=copy;entry.saleGold=SALE_PRICES[tier-1];entry.gold+=entry.saleGold;state.gold+=entry.saleGold;
      }else{state.collection.push(copy);entry.recruit=copy;}
    }
    if(battle.boss && !battle.towerFloor){
      state.completed=true;
      state.unlocked=Math.min(WORLDS.length-1,Math.max(state.unlocked??0,(state.world??0)+1));
    }
    if(state.autoRoutes){
      const areas=worldOf(state).areas;
      state.area=Math.max(state.area,areas.findLastIndex(a=>a.unlock<=maxLevel(state)));
    }
  }else{
    state.losses++;
    if(!battle.boss && ++state.streak>=3){if(state.area>0)state.area--;state.streak=0;}
  }
  state.log=[entry,...state.log].slice(0,25);
  return entry;
}

function advance(state,now,budget,encounterLimit=Infinity){
  if(state.autoSell)state.autoSell=saleSettings(state.autoSell);
  if(state.world===undefined){
    state.world=0;state.unlocked=state.completed?1:0;state.journey={};state.autoRoutes=true;
    state.paused=false;
    if(!state.running&&!state.pending)state.nextAt=now;
    state.running=true;
  }
  const previous=state.clock;
  if(now<previous) return [];
  const cap=Math.min(now,previous+12*HOUR);
  const entries=[];
  function canStart(at){
    if(!budget)return true;
    if(budget.remaining>0){budget.remaining--;return true;}
    budget.exhausted=true;
    state.clock=at;
    return false;
  }
  while(true){
    if(state.pending){
      if(state.pending.end>cap) break;
      const battle=state.pending;
      state.pending=null;
      entries.push(settle(state,battle));
      state.waitDuration=waitFor(state);
      state.nextAt=battle.end+state.waitDuration;
      state.running=!state.paused;
      if(state.destination!==undefined)travel(state,state.destination);
      else if(state.autoRoutes && state.running && battle.boss && state.completed && state.world<state.unlocked)travel(state,state.world+1);
      if(entries.length>=encounterLimit){
        state.clock=Math.max(previous,battle.end);
        return entries;
      }
      continue;
    }
    if(state.towerQueued && state.team.length){
      const when=Math.max(previous,state.towerQueued.at,firstReady(state),entries.at(-1)?.end??0);
      if(when<=cap){
        if(!canStart(when))return entries;
        delete state.towerQueued;
        state.pending=makeBattle(state,when,true,(state.towerCleared??0)+1);
        continue;
      }
    }
    if(!state.team.length||!state.running||state.nextAt>cap) break;
    const start=Math.max(state.nextAt,firstReady(state));
    if(start>cap)break;
    if(!canStart(Math.max(previous,start)))return entries;
    if(state.autoRoutes && state.completed && state.world<state.unlocked)travel(state,state.world+1);
    state.pending=makeBattle(state,start,!!state.autoRoutes && readyForBoss(state));
  }
  if(now>cap){
    if(state.pending){
      // Preserve the fight and the remaining replay when the AFK window ends mid-battle.
      state.pending.start+=now-cap;
      state.pending.end+=now-cap;
    }
    state.running=!state.paused;
    state.nextAt=now+waitFor(state);
  }
  state.clock=now;
  return entries;
}

const AWAY_THRESHOLD=10*60*1000;
const AFK_ENCOUNTER_LIMIT=2400;
function newWindow(state,start){
  return {start,encounters:0,wins:0,gold:0,teamXp:0,reserveXp:0,firstRecruit:state.collection.length,recruitUids:[]};
}
function hydrateAwayRecruits(state){
  if(state.awayWindow&&!Array.isArray(state.awayWindow.recruitUids)){
    const start=Number.isInteger(state.awayWindow.firstRecruit)?Math.max(0,state.awayWindow.firstRecruit):state.collection.length;
    state.awayWindow.recruitUids=state.collection.slice(start).map(u=>u.uid);
  }
  if(Array.isArray(state.awayReports)){
    for(const r of state.awayReports){
      if(r&&!Array.isArray(r.recruitUids)){
        const start=Number.isInteger(r.firstRecruit)?Math.max(0,r.firstRecruit):state.collection.length;
        const end=Number.isInteger(r.lastRecruit)?Math.max(start,r.lastRecruit):start;
        r.recruitUids=state.collection.slice(start,end).map(u=>u.uid);
      }
    }
  }
}
function advanceWithPresence(state,now,observedAt=null,budget){
  if(!state.dex){
    state.dex={normal:[],shiny:[],traits:[]};
    for(const u of state.collection)recordDex(state,u);
    for(const e of state.log??[]){if(e.recruit||e.sold)recordDex(state,e.recruit??e.sold);}
    for(const id of Object.keys(CHARACTERS)){
      if(state.serials?.[id]>0)recordDex(state,{id});
      if(state.serials?.[id+'-shiny']>0)recordDex(state,{id,shiny:true});
    }
  }
  if(Object.hasOwn(state,'traitFragments')){
    state.traitItems=(state.traitItems??0)+Math.max(0,Math.floor(state.traitFragments)||0);
    delete state.traitFragments;
  }
  hydrateAwayRecruits(state);
  const window=state.awayWindow??=newWindow(state,state.clock);
  const all=[];
  function run(until){
    const w=state.awayWindow;
    const limit=w.start+12*HOUR;
    const remaining=AFK_ENCOUNTER_LIMIT-w.encounters;
    if(remaining>0&&until>=state.clock&&state.clock<=limit){
      const entries=advance(state,Math.min(until,limit),budget,remaining);
      for(const e of entries){
        if(e.sold){w.sold=(w.sold??0)+1;w.saleGold=(w.saleGold??0)+e.saleGold;}
        if(e.recruit?.uid)(w.recruitUids??=[]).push(e.recruit.uid);
        w.encounters++;w.wins+=Number(e.won);w.gold+=e.gold;w.teamXp+=e.teamXp;w.reserveXp+=e.reserveXp;all.push(e);
      }
    }
    if(!budget?.exhausted&&until>state.clock&&(until>limit||w.encounters>=AFK_ENCOUNTER_LIMIT)){
      if(w.encounters>=AFK_ENCOUNTER_LIMIT)w.encounterLimitReached=true;
      const shift=until-state.clock;
      if(state.pending){state.pending.start+=shift;state.pending.end+=shift;}
      state.nextAt+=shift;state.clock=until;
    }
  }
  if(Number.isFinite(observedAt)&&observedAt>window.start){
    const seen=Math.min(now,observedAt);
    run(seen);
    if(budget?.exhausted)return all;
    if(seen-window.start>=AWAY_THRESHOLD){
      (state.awayReports??=[]).push({...window,recruitUids:[...(window.recruitUids??[])],end:seen,lastRecruit:state.collection.length});
    }
    state.awayWindow=newWindow(state,seen);
  }
  run(now);
  return all;
}

function startExploration(state,now){
  if(state.pending?.boss||state.running)return false;
  state.running=true;
  if(!state.pending)state.nextAt=Math.max(now,state.nextAt);
  return true;
}

const TOWER_LIMIT=30;
const towerPrize=floor=>floor%5===0?2:1;
function raidToday(now){
  const {day,nextAt}=dailyCycle(now);
  const index=Math.floor(Date.parse(day+'T00:00:00Z')/86400000)%WORLDS.length;
  return {day,nextAt,index,boss:WORLDS[index].boss};
}
function ballBoss(index,level,factor,raid){
  const b=WORLDS[index].boss,g=scale(level)*factor;
  const [hp,attack,defense,resistance]=b.base.map(v=>Math.round(v*g));
  return {name:b.name,kind:b.kind??'freeza-boss',skill:'Ofensiva de '+b.name,color:b.color,role:'Combatente',
    sprite:'enemy-'+(index+1)+'-5',level,scale:g,speed:106,hp:raid?(b.name==='Byakuya Kuchiki'?40000:10000000):hp,attack,magic:attack,defense,resistance,x:60,y:50};
}
function towerEnemies(floor){
  const index=(floor-1)%WORLDS.length;
  const level=Math.min(100,62+Math.floor((floor-1)*.45));
  const factor=.82+.009*(floor-1);
  const team=[ballBoss(index,level,factor,false)];
  if(floor>TOWER_LIMIT){
    const count=Math.min(3,1+Math.floor((floor-31)/10));
    for(let i=1;i<=count;i++)team.push(ballBoss((index+i)%WORLDS.length,level,factor*.65,false));
  }
  return team;
}
function ballChallenge(state,action,now){
  const raid=action.type==='raid',daily=raidToday(now);
  const used=state.raid?.day===daily.day?state.raid.attempts:0;
  const floor=(state.towerCleared??0)+1;
  if(action.sequence!==(state.ballSequence??0))return false;
  if(raid?(used>=3||action.day!==daily.day):((state.unlocked??0)<9||state.towerQueued||state.pending?.towerFloor||action.floor!==floor))return false;
  const available=state.team.filter(uid=>readyAt(state,uid)<=now);
  if(!available.length)return false;
  const leader=available.includes(state.leader)?CHARACTERS[state.collection.find(u=>u.uid===state.leader).id]:null;
  const left=available.map(uid=>fighter(state.collection.find(u=>u.uid===uid),state.positions[uid],leader,true));
  const right=raid?[ballBoss(daily.index,45,1,true)]:towerEnemies(floor);
  const limit=raid?60:120;
  const match=finishDuel(createDuel(left,right,limit));
  const damage=Math.round(match.combat.log.reduce((sum,e)=>sum+(e.type==='dano'&&e.actor?.startsWith('0:')&&e.target?.startsWith('1:')?e.hp:0),0));
  const fallen=match.sides[0].team.filter(f=>!match.combat.alive(f));
  if(fallen.length){
    const until=now+upgradeValue(state,'enfermaria')*1000;
    state.recovery??={};
    for(const f of fallen)state.recovery[f.uid]=Math.max(until,state.recovery[f.uid]??0);
    if(fallen.length===available.length)state.partyRecovery=Math.max(until,state.partyRecovery??0);
  }
  let items=0;
  if(raid){
    items=1;
    state.raid={day:daily.day,attempts:used+1,bestDamage:Math.max(used?state.raid.bestDamage:0,damage),bestEver:Math.max(state.raid?.bestEver??0,damage)};
  }else if(match.result==='Vitória'){
    state.towerCleared=floor;items=towerPrize(floor);
  }
  state.traitItems=(state.traitItems??0)+items;
  state.ballSequence=(state.ballSequence??0)+1;
  state.ballRun={physics:3,sequence:state.ballSequence,left,right,limit,raid,floor,damage,items,result:match.result};
  return true;
}
function challenge(state,now){
  if(!readyForBoss(state))return false;
  if(state.pending||firstReady(state)>now)return false;
  state.pending=makeBattle(state,now,true);
  return true;
}

function formationSlots(state){
  return state.slots??Array.from({length:4},(_,i)=>state.team[i]??null);
}

function formationCost(state,slots=state.team){
  return slots.reduce((n,uid)=>n+(uid?(state.collection.find(u=>u.uid===uid)?.nen?2:1):0),0);
}
function equip(state,uid,replaced,requestedSlot){
  if(!state.collection.some(c=>c.uid===uid)||state.team.includes(uid))return false;
  const slots=formationSlots(state).slice();
  const index=requestedSlot??(replaced?slots.indexOf(replaced):slots.indexOf(null));
  if(!Number.isInteger(index)||index<0||index>=4||slots[index]!== (replaced??null))return false;
  const next=slots.slice();next[index]=uid;
  if(formationCost(state,next)>4)return false;
  state.positions[uid]=(state.positions[replaced]??state.slotPositions?.[index]??position[index]).slice();
  if(!state.leader||state.leader===replaced)state.leader=uid;
  slots[index]=uid;
  state.slots=slots;state.team=slots.filter(Boolean);
  return true;
}

function removeMember(state,uid){
  const slots=formationSlots(state).slice(),index=slots.indexOf(uid);
  if(!uid||index<0)return false;
  state.slotPositions??={};
  state.slotPositions[index]=state.positions[uid];
  slots[index]=null;
  state.slots=slots;state.team=slots.filter(Boolean);
  if(state.leader===uid)state.leader=state.team[0]??null;
  return true;
}

function travel(state,index){
  state.journey[state.world]={area:state.area,completed:state.completed,finalWins:state.finalWins,bossGoal:state.bossGoal??12};
  const progress=state.journey[index]??{area:0,completed:false,finalWins:0,bossGoal:12+3*index};
  Object.assign(state,{bossGoal:12},progress,{world:index,streak:0});
  delete state.destination;
}
const STAT_KEYS=['hp','attack','magic','defense','resistance','speed'];
function unitPower(unit, leader=null){
  const stats=fighter(unit,undefined,leader);
  return STAT_KEYS.reduce((sum,key)=>sum+stats[key],0);
}
function formationPower(unit,leader=null,atMaxLevel=true){
  const f=fighter(atMaxLevel?{...unit,xp:xpTo(100)}:unit,undefined,leader);
  const health=f.hp/5;
  const protection=(f.defense+f.resistance)/2;
  const offense=(f.magicBasic?f.magic:f.attack)*f.speed/100;
  switch(f.role){
    case 'Guardião': return Math.round(.25*offense+.40*health+.35*protection);
    case 'Suporte': return Math.round(.55*offense+.25*health+.20*protection);
    case 'Mágico': return Math.round(.80*offense+.10*health+.10*protection);
    default: return Math.round(.70*offense+.15*health+.15*protection);
  }
}
function projectedPower(unit,leader=null){
  return unitPower({...unit,xp:xpTo(100)},leader);
}
function leaderApplies(leader, member){
  return leaderBuff(leader,member).some(Boolean);
}

const ROLE_ORDER={Guardião:0,Combatente:1,Mágico:2,Suporte:3};
const PRESET_COORDS={
  padrao:[[74,44],[56,76],[36,26],[22,60]],
  espalhado:[[82,20],[62,82],[24,20],[20,82]],
  proteger:[[72,50],[46,42],[46,58],[58,24]],
};
function applyFormationPreset(state, preset='padrao'){
  const coords=PRESET_COORDS[preset];
  if(!coords||!state.team.length)return false;
  const ordered=state.team.slice().sort((a,b)=>{
    const ca=CHARACTERS[state.collection.find(u=>u.uid===a).id];
    const cb=CHARACTERS[state.collection.find(u=>u.uid===b).id];
    return (ROLE_ORDER[ca.role]??9)-(ROLE_ORDER[cb.role]??9);
  });
  ordered.forEach((uid,i)=>{state.positions[uid]=coords[i].slice();});
  return true;
}

function applySuggestedFormation(state,action,now){
  const {team,leader}=action;
  if(!Array.isArray(team)||!team.length||team.length>4||
    team.some(uid=>typeof uid!=='string')||new Set(team).size!==team.length||!team.includes(leader))return false;
  const units=team.map(uid=>state.collection.find(unit=>unit.uid===uid));
  if(units.some(unit=>!unit)||units.reduce((cost,unit)=>cost+(unit.nen?2:1),0)>4)return false;
  const wasEmpty=!state.team.length;
  state.team=team.slice();
  state.slots=Array.from({length:4},(_,i)=>team[i]??null);
  state.leader=leader;
  applyFormationPreset(state,'padrao');
  if(wasEmpty&&!state.pending)state.nextAt=now;
  return true;
}

function allTraits(unit){return [...new Set([...slotTraits(unit,0),...slotTraits(unit,1)])];}
function recordDex(state,unit){
  if(!unit||!Object.hasOwn(CHARACTERS,unit.id))return;
  const dex=state.dex??={normal:[],shiny:[],traits:[]};
  const bucket=unit.shiny?(dex.shiny??=[]):(dex.normal??=[]);
  if(!bucket.includes(unit.id))bucket.push(unit.id);
  for(const name of allTraits(unit)){
    const traits=dex.traits??=[];
    if(!traits.includes(name))traits.push(name);
  }
}
function dexSummary(state){
  const normal=new Set(Array.isArray(state.dex?.normal)?state.dex.normal:[]);
  const shiny=new Set(Array.isArray(state.dex?.shiny)?state.dex.shiny:[]);
  const traitsSeen=new Set(Array.isArray(state.dex?.traits)?state.dex.traits:[]);
  const counts=new Map(),traitCounts=new Map();
  for(const u of state.collection){
    if(!Object.hasOwn(CHARACTERS,u.id))continue;
    if(u.shiny)shiny.add(u.id);else normal.add(u.id);
    counts.set(u.id,(counts.get(u.id)??0)+1);
    for(const name of allTraits(u)){traitsSeen.add(name);traitCounts.set(name,(traitCounts.get(name)??0)+1);}
  }
  const worldsByUniverse=new Map();
  for(const w of WORLDS){
    if(!worldsByUniverse.has(w.universe))worldsByUniverse.set(w.universe,[]);
    worldsByUniverse.get(w.universe).push(w.name);
  }
  const characters=Object.values(CHARACTERS).map(c=>({
    ...c,normal:normal.has(c.id),shiny:shiny.has(c.id),seen:normal.has(c.id)||shiny.has(c.id),
    count:counts.get(c.id)??0,worlds:worldsByUniverse.get(c.universe)??[]
  })).sort((a,b)=>a.tier-b.tier||a.name.localeCompare(b.name,'pt-BR'));
  const traits=TRAITS.map(t=>({...t,seen:traitsSeen.has(t.name),count:traitCounts.get(t.name)??0}));
  return {
    characters,traits,
    totals:{
      seenChars:characters.filter(c=>c.seen).length,totalChars:characters.length,
      shinyChars:characters.filter(c=>c.shiny).length,
      seenTraits:traits.filter(t=>t.seen).length,totalTraits:traits.length
    }
  };
}

function canSellUnit(state, uid){
  if(!uid||state.collection.length<=1||state.team.includes(uid))return false;
  const unit=state.collection.find(u=>u.uid===uid);
  return !!unit&&unit.locked!==true;
}
function toggleLock(state, uid, locked){
  if(typeof uid!=='string'||typeof locked!=='boolean')return false;
  const unit=state.collection.find(u=>u.uid===uid);
  if(!unit||Boolean(unit.locked)===locked)return false;
  if(locked)unit.locked=true;else delete unit.locked;
  return true;
}
function duplicateSellCandidates(state,{includeCommonTraits=false}={}){
  const teamSet=new Set(state.team);
  const traitOdds=new Map(TRAITS.map(t=>[t.name,t.odds]));
  const groups=new Map();
  for(const u of state.collection){
    const key=`${u.id}:${u.shiny?1:0}`;
    if(!groups.has(key))groups.set(key,[]);
    groups.get(key).push(u);
  }
  const candidates=[];
  for(const list of groups.values()){
    if(list.length<=1)continue;
    const sorted=list.slice().sort((a,b)=>{
      return projectedPower(b)-projectedPower(a)||b.xp-a.xp||a.serial-b.serial;
    });
    for(const u of sorted.slice(1)){
      if(teamSet.has(u.uid)||u.locked||u.shiny)continue;
      const names=allTraits(u);
      if(names.length&&(!includeCommonTraits||names.length>1||(traitOdds.get(names[0])??Infinity)>25))continue;
      candidates.push(u);
    }
  }
  return candidates;
}

function sellUnit(state, uid){
  if(!canSellUnit(state,uid))return false;
  hydrateAwayRecruits(state);
  const index=state.collection.findIndex(u=>u.uid===uid);
  const [unit]=state.collection.splice(index,1);
  recordDex(state,unit);
  const gold=SALE_PRICES[CHARACTERS[unit.id].tier-1]??0;
  state.gold+=gold;
  delete state.positions?.[uid];
  if(state.recovery)delete state.recovery[uid];
  if(state.awayWindow&&index<state.awayWindow.firstRecruit)state.awayWindow.firstRecruit--;
  if(Array.isArray(state.awayReports)){
    for(const r of state.awayReports){
      if(index<r.firstRecruit)r.firstRecruit--;
      if(index<r.lastRecruit)r.lastRecruit--;
    }
  }
  return gold;
}

function applyGameAction(state,action,now){
  switch(action?.type){
    case 'lock': return toggleLock(state,action.uid,action.locked);
    case 'sellBatch': {
      if(!Array.isArray(action.uids)||!action.uids.length||action.uids.length>200||typeof action.includeCommonTraits!=='boolean')return false;
      const eligible=new Set(duplicateSellCandidates(state,{includeCommonTraits:action.includeCommonTraits}).map(u=>u.uid));
      const ids=new Set(action.uids);
      if(ids.size!==action.uids.length||[...ids].some(uid=>!eligible.has(uid)))return false;
      for(const uid of ids)sellUnit(state,uid);
      return true;
    }
    case 'arenaShop': {
      const count=state.arenaPurchases??0;
      if(action.purchase!==count||!(state.arenaTrophies>=5))return false;
      state.arenaTrophies-=5;
      state.arenaPurchases=count+1;
      state.traitItems=(state.traitItems??0)+1;
      return true;
    }
    case 'reroll': case 'equipTraitSlot': return changeTraitSlot(state,action);
    case 'raid': return ballChallenge(state,action,now);
    case 'nen': {
      const u=state.collection.find(c=>c.uid===action.uid);
      if(!u||!slotTraits(u).includes('Voto de Nen')||typeof action.enabled!=='boolean')return false;
      if(action.enabled&&!u.nen&&state.team.includes(u.uid)&&formationCost(state)>=4)return false;
      u.nen=action.enabled;return true;
    }
    case 'saleTrait': {
      const {tier,name,below,checked}=action;
      if(!Number.isInteger(tier)||tier<1||tier>TIERS.length)return false;
      const named=name!==undefined;
      if(named&&(!TRAITS.some(t=>t.name===name)||typeof checked!=='boolean'))return false;
      if(!named&&(!Number.isInteger(below)||below<0||below>1000000))return false;
      const settings=state.autoSell=saleSettings(state.autoSell);
      const rules=settings.traitRules??={};
      const rule=rules[tier]??={below:0,names:[]};
      if(!named)rule.below=below;
      else if(checked){if(!rule.names.includes(name))rule.names.push(name);}
      else rule.names=rule.names.filter(n=>n!==name);
      return true;
    }
    case 'saleSetting': {
      const {group,value,checked}=action;
      if(typeof checked!=='boolean'||!['enabled','tiers','characters'].includes(group))return false;
      if(group==='tiers'&&(!Number.isInteger(value)||value<1||value>TIERS.length))return false;
      if(group==='characters'&&!Object.hasOwn(CHARACTERS,value))return false;
      const settings=state.autoSell=saleSettings(state.autoSell);
      if(group==='enabled')settings.enabled=checked;
      else settings[group]=checked?[...new Set([...settings[group],value])]:settings[group].filter(v=>v!==value);
      return true;
    }
    case 'dismissAway': {
      if(!state.awayReports?.length||state.awayReports[0].end!==action.end)return false;
      state.awayReports.shift();return true;
    }
    case 'pause':
      state.running=false;state.paused=true;return true;
    case 'resume': {
      const wasPaused=Boolean(state.paused);
      state.paused=false;
      return startExploration(state,now)||wasPaused;
    }
    case 'autoRoutes':
      state.autoRoutes=action.enabled===true;return true;
    case 'world':
      if(!Number.isInteger(action.index)||action.index<0||action.index>state.unlocked)return false;
      state.autoRoutes=false;
      if(state.pending)state.destination=action.index;else travel(state,action.index);
      return true;
    case 'area': {
      const area=Number.isInteger(action.area)&&worldOf(state).areas[action.area];
      if(!area||maxLevel(state)<area.unlock||(!state.autoRoutes&&state.area===action.area))return false;
      state.autoRoutes=false;state.area=action.area;state.streak=0;return true;
    }
    case 'leader':
      if(!state.team.includes(action.uid)||state.leader===action.uid)return false;
      state.leader=action.uid;return true;
    case 'remove': return removeMember(state,action.uid);
    case 'equip': {
      const empty=!state.team.length;
      const changed=equip(state,action.uid,action.replaced,action.slot);
      if(changed&&empty&&!state.pending)state.nextAt=now;
      return changed;
    }
    case 'tower': return ballChallenge(state,action,now);
    case 'boss': return challenge(state,now);
    case 'upgrade': return buyUpgrade(state,action.id);
    case 'position': {
      if(!state.team.includes(action.uid))return false;
      const coords=action.coords;
      if(!Array.isArray(coords)||coords.length!==2||!coords.every(Number.isFinite))return false;
      state.positions[action.uid]=coords.map(value=>Math.max(8,Math.min(92,Math.round(value))));
      return true;
    }
    case 'autoFormation': return applySuggestedFormation(state,action,now);
    case 'formationPreset': return applyFormationPreset(state,action.preset);
    case 'sell': return sellUnit(state,action.uid)!==false;
    default: return false;
  }
}

return {AREAS,BOSS,WORLDS,worldOf,levelCap,COLORS,TIERS,spriteFor,CHARACTERS,SKILL_EFFECTS,TRAITS,UPGRADES,xpFor,levelAt,xpProgress,maxLevel,readyForBoss,upgradeLevel,waitFor,buyUpgrade,fresh,slotTraits,loadoutChance,fighter,recruitRates,rollRecruit,SALE_PRICES,RECOVERY_MS,readyAt,makeBattle,saleSettings,advance,AWAY_THRESHOLD,advanceWithPresence,startExploration,TOWER_LIMIT,towerPrize,raidToday,towerEnemies,challenge,formationSlots,formationCost,equip,unitPower,formationPower,projectedPower,leaderApplies,applyFormationPreset,dexSummary,canSellUnit,duplicateSellCandidates,sellUnit,applyGameAction};
})();
const {serialSchema,issueSerials} =serials;
const {advance,advanceWithPresence,applyGameAction,fighter,fresh,CHARACTERS} =game;
const {dailyCycle,DEFAULT_PROFILE,appearancePatch,PROFILE_BODY_LIMIT,GIFT_GOLD} =communityRules;

class ApiError extends Error {
  constructor(status,message,code){super(message);this.status=status;this.code=code;}
}
function reject(status,message,code){throw new ApiError(status,message,code);}
const BUILD='nexus-namek-52';
const schemas=[
  'CREATE TABLE IF NOT EXISTS nexus_links(provider TEXT,subject TEXT,player TEXT NOT NULL,PRIMARY KEY(provider,subject),UNIQUE(provider,player))',
  'CREATE TABLE IF NOT EXISTS nexus_oauth(key TEXT PRIMARY KEY,browser TEXT,provider TEXT,player TEXT,expires INTEGER)',
  'CREATE TABLE IF NOT EXISTS nexus_handoffs(key TEXT PRIMARY KEY,player TEXT NOT NULL,expires INTEGER)',
  'CREATE TABLE IF NOT EXISTS nexus_sessions(key TEXT PRIMARY KEY,player TEXT NOT NULL,expires INTEGER)',

  `CREATE TABLE IF NOT EXISTS nexus_arena_matches(
    player TEXT NOT NULL, day TEXT NOT NULL, attempt INTEGER NOT NULL CHECK(attempt BETWEEN 1 AND 5),
    rival TEXT NOT NULL, delta INTEGER NOT NULL, replay TEXT NOT NULL,
    PRIMARY KEY(player,day,attempt), UNIQUE(player,day,rival), CHECK(player<>rival))`,

  `CREATE TABLE IF NOT EXISTS nexus_players(
    id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, token_hash TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL, game TEXT NOT NULL, appearance TEXT NOT NULL,
    revision INTEGER NOT NULL DEFAULT 0, play_ms INTEGER NOT NULL DEFAULT 0, last_seen INTEGER,
    reg_key TEXT NOT NULL, power INTEGER NOT NULL, top_units TEXT NOT NULL, rare_units TEXT NOT NULL)`,
  'CREATE TABLE IF NOT EXISTS nexus_game_backups(player TEXT,day INTEGER,game TEXT NOT NULL,revision INTEGER NOT NULL,PRIMARY KEY(player,day))',
  `CREATE TRIGGER IF NOT EXISTS nexus_campaign_history BEFORE UPDATE OF game ON nexus_players
    WHEN OLD.game<>NEW.game AND NOT EXISTS(SELECT 1 FROM nexus_game_backups WHERE player=OLD.id AND day=unixepoch()/86400)
    BEGIN
      INSERT INTO nexus_game_backups(player,day,game,revision) VALUES(OLD.id,unixepoch()/86400,OLD.game,OLD.revision);
      DELETE FROM nexus_game_backups WHERE player=OLD.id AND day<unixepoch()/86400-6;
    END`,
  `CREATE TRIGGER IF NOT EXISTS nexus_arena_trophy_win AFTER INSERT ON nexus_arena_matches
    WHEN json_extract(NEW.replay,'$.trophies') BETWEEN 1 AND 5 BEGIN
      UPDATE nexus_players SET game=json_set(game,'$.arenaTrophies',
        coalesce(json_extract(game,'$.arenaTrophies'),0)+json_extract(NEW.replay,'$.trophies')),
        revision=revision+1 WHERE id=NEW.player;
    END`,
  'CREATE INDEX IF NOT EXISTS nexus_registration ON nexus_players(reg_key)',
  'CREATE INDEX IF NOT EXISTS nexus_power ON nexus_players(power DESC,name,id)',
  `CREATE TABLE IF NOT EXISTS nexus_friends(
    a TEXT NOT NULL REFERENCES nexus_players(id), b TEXT NOT NULL REFERENCES nexus_players(id),
    requested_by TEXT NOT NULL REFERENCES nexus_players(id), accepted INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(a,b),CHECK(a<b))`,
  'CREATE INDEX IF NOT EXISTS nexus_friends_b ON nexus_friends(b)',
  `CREATE TABLE IF NOT EXISTS nexus_gifts(
    sender TEXT NOT NULL REFERENCES nexus_players(id), recipient TEXT NOT NULL REFERENCES nexus_players(id),
    day TEXT NOT NULL, gold INTEGER NOT NULL, sent_at INTEGER NOT NULL,PRIMARY KEY(sender,recipient,day))`,
  'CREATE INDEX IF NOT EXISTS nexus_inbox ON nexus_gifts(recipient,sent_at DESC)',
  'CREATE INDEX IF NOT EXISTS nexus_gift_day ON nexus_gifts(recipient,day)',
  'DROP TRIGGER IF EXISTS nexus_fragment_credit',
  `CREATE TRIGGER IF NOT EXISTS nexus_token_credit AFTER INSERT ON nexus_gifts
   WHEN (SELECT count(*) FROM nexus_gifts WHERE recipient=NEW.recipient AND day=NEW.day)<=3 BEGIN
    UPDATE nexus_players SET game=json_set(game,'$.traitItems',coalesce(json_extract(game,'$.traitItems'),0)+1)
    WHERE id=NEW.recipient;
   END`,
  `CREATE TRIGGER IF NOT EXISTS nexus_gift_credit AFTER INSERT ON nexus_gifts BEGIN
    UPDATE nexus_players SET game=json_set(game,'$.gold',json_extract(game,'$.gold')+NEW.gold),
      revision=revision+1 WHERE id=NEW.recipient;
  END`
];
const initialized=new WeakSet();
const SCHEMA_VERSION=1;
async function initialize(db){
  if(initialized.has(db))return;
  let schema;
  try{
    schema=await db.prepare('SELECT version FROM nexus_schema_version WHERE id=1').first();
  }catch(error){
    // Existing deployments do not have the version marker until this migration commits.
    if(!/no such table: (?:main\.)?nexus_schema_version\b/i.test(String(error?.message)))throw error;
  }
  if(!schema||schema.version<SCHEMA_VERSION){
    const migration=[...schemas,...serialSchema('nexus_players',true),
      'CREATE TABLE IF NOT EXISTS nexus_schema_version(id INTEGER PRIMARY KEY,version INTEGER NOT NULL)',
      'INSERT INTO nexus_schema_version(id,version) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET version=max(version,excluded.version)'];
    await db.batch(migration.map((sql,i)=>i===migration.length-1?db.prepare(sql).bind(SCHEMA_VERSION):db.prepare(sql)));
  }
  initialized.add(db);
}
const hex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
const random=count=>crypto.getRandomValues(new Uint8Array(count));
const hash=async value=>hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))));
const publicPlayer=({id,name,code})=>({id,name,code});
function summarize(unit){
  const stats=fighter(unit);
  const power=['hp','attack','magic','defense','resistance','speed'].reduce((sum,k)=>sum+stats[k],0);
  return {id:unit.id,xp:unit.xp,name:CHARACTERS[unit.id].name,level:stats.level,shiny:unit.shiny,
    trait:unit.trait,traitSlots:unit.traitSlots,activeSlot:unit.activeSlot,nen:unit.nen===true,serial:unit.serial,odds:unit.odds,power};
}
function rankedUnits(collection){
  const units=collection.map(summarize);
  const rarity=(a,b)=>(b.odds??0)-(a.odds??0)||a.name.localeCompare(b.name)||a.serial-b.serial;
  const rare=units.filter(u=>u.odds>0).sort(rarity).slice(0,30);
  const top=units.sort((a,b)=>b.power-a.power||rarity(a,b)).slice(0,4);
  return [top.reduce((sum,u)=>sum+u.power,0),JSON.stringify(top),JSON.stringify(rare)];
}
async function register(db,input,request){
  const name=typeof input.name==='string'?input.name.normalize('NFC').trim().replace(/\s+/gu,' '):'';
  if(!/^[\p{L}\p{N} _.-]{2,24}$/u.test(name))reject(400,'Use de 2 a 24 letras ou números no nome.');
  const now=Date.now();
  const regKey=await hash(Math.floor(now/3600000)+'/'+(request.headers.get('CF-Connecting-IP')??'local'));
  const token=btoa(String.fromCharCode(...random(24))).replaceAll('+','-').replaceAll('/','_');
  const state=fresh(now,crypto.getRandomValues(new Uint32Array(1))[0]);
  const tokenHash=await hash(token);
  const id=crypto.randomUUID();
  for(let attempt=0;attempt<3;attempt++){
    const counter=await db.prepare('SELECT * FROM nexus_serials WHERE id=1').first();
    issueSerials(state,state.collection,counter);
    const ranks=rankedUnits(state.collection);
    const code=hex(random(5)).toUpperCase();
    const inserted=await db.prepare(`INSERT INTO nexus_players(id,code,token_hash,name,game,appearance,reg_key,power,top_units,rare_units)
      SELECT ?,?,?,?,?,?,?,?,?,? WHERE (SELECT revision FROM nexus_serials WHERE id=1)=? AND (SELECT count(*) FROM nexus_players WHERE reg_key=?)<20
      ON CONFLICT(code) DO NOTHING RETURNING id`).bind(id,code,tokenHash,name,JSON.stringify(state),JSON.stringify(DEFAULT_PROFILE),regKey,...ranks,counter.revision,regKey).first();
    if(inserted)return {token,player:{id,name,code}};
    const count=await db.prepare('SELECT count(*) AS n FROM nexus_players WHERE reg_key=?').bind(regKey).first();
    if(count.n>=20)reject(429,'Limite temporário de criação de contas atingido.');
  }
  reject(503,'Tente criar o perfil novamente.','REGISTRATION_CONTENTION');
}
const providers = {
  google:{authorize:'https://accounts.google.com/o/oauth2/v2/auth',exchange:'https://oauth2.googleapis.com/token',user:'https://openidconnect.googleapis.com/v1/userinfo',scope:'openid'},
  discord:{authorize:'https://discord.com/oauth2/authorize',exchange:'https://discord.com/api/oauth2/token',user:'https://discord.com/api/v10/users/@me',scope:'identify'}
};
const oauthCookie=(value,age)=>`__Host-nexus-auth=${value}; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=${age}`;
const API_RESPONSE_HEADERS={
  'Cache-Control':'no-store',
  'Content-Security-Policy':"default-src 'none'; frame-ancestors 'none'",
  'X-Frame-Options':'DENY',
  'X-Content-Type-Options':'nosniff',
  'Referrer-Policy':'no-referrer'
};
function oauthResponse(body,cookie,redirect){
  const headers={...API_RESPONSE_HEADERS};
  if(cookie)headers['Set-Cookie']=cookie;
  if(redirect)headers.Location=redirect;
  else headers['Content-Type']='application/json';
  return new Response(redirect?null:JSON.stringify(body),{status:redirect?303:200,headers});
}
async function socialAuth(request,env,db,url){
  const match=/^\/api\/auth\/(google|discord)\/(start|callback)$/.exec(url.pathname);
  const cookie=(request.headers.get('Cookie')??'').match(/(?:^|;\s*)__Host-nexus-auth=([a-f0-9]{64})(?:;|$)/)?.[1];
  const now=Date.now();
  if(request.method==='POST'&&request.headers.get('Origin')!==url.origin)reject(403,'Origem inválida.');
  if(url.pathname==='/api/auth/finish'&&request.method==='POST'){
    if(!cookie)reject(401,'Entre novamente para continuar.');
    const row=await db.prepare('DELETE FROM nexus_handoffs WHERE key=? AND expires>? RETURNING player').bind(await hash(cookie),now).first();
    if(!row)reject(401,'A entrada expirou. Tente novamente.');
    const access=hex(random(24));
    await db.prepare('INSERT INTO nexus_sessions(key,player,expires) VALUES(?,?,?)').bind(await hash(access),row.player,now+30*86400000).run();
    return oauthResponse({access},oauthCookie('',0));
  }
  if(!match)reject(404,'Rota não encontrada.');
  const [,name,stage]=match,p=providers[name],key=env[name.toUpperCase()+'_CLIENT_ID'],secret=env[name.toUpperCase()+'_CLIENT_SECRET'];
  const callback=url.origin+'/api/auth/'+name+'/callback';
  if(!key||!secret)reject(503,'Este método de entrada ainda precisa ser configurado no servidor.','OAUTH_NOT_CONFIGURED');
  if(stage==='start'&&request.method==='POST'){
    const {intent}=await readBody(request);
    if(!['link','login'].includes(intent))reject(400,'Escolha entrar ou vincular.');
    const player=intent==='link'?await authenticate(db,request):null;
    const state=hex(random(32)),browser=hex(random(32));
    await db.batch(['nexus_oauth','nexus_handoffs','nexus_sessions'].map(table=>db.prepare('DELETE FROM '+table+' WHERE expires<=?').bind(now)).concat(db.prepare('INSERT INTO nexus_oauth(key,browser,provider,player,expires) VALUES(?,?,?,?,?)').bind(await hash(state),await hash(browser),name,player,now+600000)));
    const dest=new URL(p.authorize);
    dest.search=new URLSearchParams({response_type:'code',client_id:key,redirect_uri:callback,scope:p.scope,state});
    return oauthResponse({url:dest.href},oauthCookie(browser,600));
  }
  if(stage!=='callback'||request.method!=='GET')reject(405,'Método inválido.');
  const back=(status)=>oauthResponse(null,oauthCookie('',0),'/?account='+status+'#comunidade');
  const state=url.searchParams.get('state');
  if(!cookie||!state||!/^[a-f0-9]{64}$/.test(state))return back('expired');
  const flow=await db.prepare('DELETE FROM nexus_oauth WHERE key=? AND browser=? AND provider=? AND expires>? RETURNING player').bind(await hash(state),await hash(cookie),name,now).first();
  if(!flow)return back('expired');
  const code=url.searchParams.get('code');
  if(!code)return back('cancelled');
  const exchanged=await fetch(p.exchange,{method:'POST',body:new URLSearchParams({client_id:key,client_secret:secret,redirect_uri:callback,grant_type:'authorization_code',code})});
  if(!exchanged.ok)return back('failed');
  const token=(await exchanged.json()).access_token;
  if(typeof token!=='string'||!token)return back('failed');
  const info=await fetch(p.user,{headers:{Authorization:'Bearer '+token}});
  if(!info.ok)return back('failed');
  const user=await info.json(),subject=name==='google'?user.sub:user.id;
  if(typeof subject!=='string'||!subject||subject.length>255)return back('failed');
  if(flow.player)await db.prepare('INSERT INTO nexus_links(provider,subject,player) VALUES(?,?,?) ON CONFLICT DO NOTHING').bind(name,subject,flow.player).run();
  const owner=await db.prepare('SELECT player FROM nexus_links WHERE provider=? AND subject=?').bind(name,subject).first();
  if(flow.player)return back(owner?.player===flow.player?'linked':'conflict');
  if(!owner)return back('unlinked');
  const handoff=hex(random(32));
  await db.prepare('INSERT INTO nexus_handoffs(key,player,expires) VALUES(?,?,?)').bind(await hash(handoff),owner.player,Date.now()+120000).run();
  return oauthResponse(null,oauthCookie(handoff,120),'/?account=login#comunidade');
}

async function authenticate(db,request){
  const token=/^Bearer ([A-Za-z0-9_-]{32}|[a-f0-9]{48})$/.exec(request.headers.get('Authorization')??'')?.[1];
  if(!token)reject(401,'Entre na sua conta da comunidade.');
  const digest=await hash(token);
  const row=token.length===48?await db.prepare('SELECT player AS id FROM nexus_sessions WHERE key=? AND expires>?').bind(digest,Date.now()).first():await db.prepare('SELECT id FROM nexus_players WHERE token_hash=?').bind(digest).first();
  if(!row)reject(401,'Código de acesso inválido.');
  return row.id;
}
const CAMPAIGN_BATTLES_PER_SYNC=6;
async function sync(db,id,body){
  const row=await db.prepare('SELECT id,name,code,game,revision,last_seen FROM nexus_players WHERE id=?').bind(id).first();
  const state=JSON.parse(row.game),now=Date.now(),previous=state.pending;
  const previousCollection=JSON.stringify(state.collection);
  const age=body.observationAge===undefined&&body.visible===true?0:body.observationAge;
  const seen=Number.isFinite(age)&&age>=0?now-age:null;
  const budget={remaining:CAMPAIGN_BATTLES_PER_SYNC,exhausted:false};
  const entries=advanceWithPresence(state,now,seen,budget);
  const partial=budget.exhausted;
  const last=entries.at(-1);
  const finished=previous&&last?.end===previous.end?{battle:previous,entry:last}:null;
  if(!partial&&body.action?.type==='autoFormation'&&!Array.isArray(body.action.team))
    reject(409,'Atualize a página para usar a formação automática.','CLIENT_UPDATE_REQUIRED');
  const changed=!partial&&applyGameAction(state,body.action,now);
  if(changed)entries.push(...advance(state,now));
  const units=entries.map(e=>e.recruit||e.sold).filter(Boolean);
  const counter=units.length?await db.prepare('SELECT * FROM nexus_serials WHERE id=1').first():null;
  issueSerials(state,units,counter);
  const delta=now-(row.last_seen??now);
  const played=delta>0&&delta<=20000?delta:0;
  const ranks=JSON.stringify(state.collection)===previousCollection?[]:rankedUnits(state.collection);
  const rankFields=ranks.length?'power=?,top_units=?,rare_units=?,':'';
  const result=await db.prepare(`UPDATE nexus_players SET game=?,play_ms=play_ms+?,last_seen=?,
    ${rankFields}revision=revision+1 WHERE id=? AND revision=? AND (? IS NULL OR (SELECT revision FROM nexus_serials WHERE id=1)=?)`)
    .bind(JSON.stringify(state),played,body.visible===true?now:null,...ranks,id,row.revision,counter?.revision??null,counter?.revision??null).run();
  if(!result.meta.changes)reject(409,'A campanha está sendo atualizada. Tente novamente.','SYNC_CONTENTION');
  if(partial){
    if(body.checkpoints!==true)reject(409,'Atualize a página para continuar a recuperação da campanha.','CLIENT_UPDATE_REQUIRED');
    const awayLimit=(state.awayWindow?.start??state.clock)+12*3600000;
    return {catchingUp:true,remaining:Math.max(1,Math.min(now,awayLimit)-state.clock)};
  }
  delete state.seed;
  return {state,changed,finished,now,player:publicPlayer(row),entries:entries.slice(-25),
    offline:{total:entries.length,wins:entries.filter(e=>e.won).length,gold:entries.reduce((sum,e)=>sum+e.gold,0),recruits:entries.filter(e=>e.recruit).length}};
}
async function profile(db,id){
  const row=await db.prepare('SELECT id,name,code,game,appearance,play_ms,rare_units FROM nexus_players WHERE id=?').bind(id).first();
  if(!row)reject(404,'Jogador não encontrado.');
  const state=JSON.parse(row.game);
  return {...publicPlayer(row),appearance:JSON.parse(row.appearance),playMs:row.play_ms,encounters:state.wins+state.losses,towerCleared:state.towerCleared??0,
    leaderId:state.collection.find(u=>u.uid===state.leader)?.id,team:state.team.map(uid=>summarize(state.collection.find(u=>u.uid===uid))),
    showcase:JSON.parse(row.rare_units).slice(0,5)};
}
async function arenaOpponents(db,id){
  // Shortlist by stored inventory strength, then compare only the equipped teams.
  const rows=await db.prepare(`SELECT id,name,json_extract(game,'$.team') AS slots,json_extract(game,'$.leader') AS leader,
    (SELECT json_group_array(json(u.value)) FROM json_each(p.game,'$.collection') u
     WHERE json_extract(u.value,'$.uid') IN (SELECT value FROM json_each(p.game,'$.team'))) AS equipped
    FROM nexus_players p WHERE json_array_length(game,'$.team')>0 OR id=?
    ORDER BY (id=?) DESC, abs(power-(SELECT power FROM nexus_players WHERE id=?)),id LIMIT 25`).bind(id,id,id).all();
  const squads=rows.results.map(row=>{
    const units=JSON.parse(row.equipped);
    const team=JSON.parse(row.slots).map(uid=>units.find(u=>u.uid===uid)).filter(Boolean);
    const leaderId=team.find(u=>u.uid===row.leader)?.id;
    const power=team.reduce((sum,u)=>sum+game.unitPower(u,CHARACTERS[leaderId]),0);
    return {id:row.id,name:row.name,leaderId,power,team:team.map(summarize)};
  });
  const own=squads.find(p=>p.id===id)?.power??0;
  return {own,opponents:squads.filter(p=>p.id!==id && p.team.length).sort((a,b)=>Math.abs(a.power-own)-Math.abs(b.power-own)).slice(0,3)};
}
async function rankedStatus(db,id,day=dailyCycle().day){
  return db.prepare(`SELECT ? AS day, COUNT(CASE WHEN day=? THEN 1 END) AS used,
    COALESCE(SUM(delta),0) AS points FROM nexus_arena_matches WHERE player=?`).bind(day,day,id).first();
}
function rankedTeam(row){
  const state=JSON.parse(row.game);
  const units=state.team.map(uid=>state.collection.find(u=>u.uid===uid)).filter(Boolean);
  const captain=CHARACTERS[units.find(u=>u.uid===state.leader)?.id];
  return {fighters:units.map(u=>fighter(u,state.positions?.[u.uid],captain,true)),
    power:units.reduce((sum,u)=>sum+game.unitPower(u,captain),0)};
}
function winTrophies(result,ownPower,rivalPower){
  if(result!=='Vitória')return 0;
  const scaled=rivalPower*100;
  if(scaled<=80*ownPower)return 1;
  if(scaled<=90*ownPower)return 2;
  if(scaled<110*ownPower)return 3;
  if(scaled<120*ownPower)return 4;
  return 5;
}
async function rankedMatch(db,id,{day,attempt}){
  if(day!==dailyCycle().day||!Number.isInteger(attempt)||attempt<1||attempt>5)
    reject(409,'Atualize as tentativas da Arena.');
  const saved=db.prepare('SELECT replay FROM nexus_arena_matches WHERE player=? AND day=? AND attempt=?').bind(id,day,attempt);
  async function receipt(row){return {run:JSON.parse(row.replay),status:await rankedStatus(db,id,day)};}
  const previous=await saved.first();
  if(previous)return receipt(previous);
  const status=await rankedStatus(db,id,day);
  if(attempt!==status.used+1)reject(409,'Atualize as tentativas da Arena.');
  const own=rankedTeam(await db.prepare('SELECT game FROM nexus_players WHERE id=?').bind(id).first());
  if(!own.power)reject(409,'Monte sua formação antes de entrar na ranqueada.');
  const rival=await db.prepare(`SELECT id,name,game FROM nexus_players WHERE id<>? AND json_array_length(game,'$.team')>0
    AND id NOT IN (SELECT rival FROM nexus_arena_matches WHERE player=? AND day=?) ORDER BY RANDOM() LIMIT 1`).bind(id,id,day).first();
  if(!rival){
    const concurrent=await saved.first();
    if(concurrent)return receipt(concurrent);
    reject(409,'Sem adversários disponíveis. Cada jogador pode ser sorteado uma vez por ciclo.');
  }
  const other=rankedTeam(rival);
  const run={physics:3,ranked:true,rivalName:rival.name,left:own.fighters,right:other.fighters,limit:120};
  run.result=duelEngine.finishDuel(duelEngine.createDuel(run.left,run.right,run.limit)).result;
  const difference=Math.max(-.38,Math.min(.38,other.power/own.power-1));
  run.trophies=winTrophies(run.result,own.power,other.power);
  run.delta=run.result==='Vitória'?Math.round(20+50*difference):run.result==='Derrota'?-Math.round(10-25*difference):0;
  await db.prepare('INSERT OR IGNORE INTO nexus_arena_matches(player,day,attempt,rival,delta,replay) VALUES(?,?,?,?,?,?)')
    .bind(id,day,attempt,rival.id,run.delta,JSON.stringify(run)).run();
  const row=await saved.first();
  if(!row)reject(409,'As tentativas mudaram. Atualize a Arena.');
  return receipt(row);
}
function scoreBoard(db,kind,limit){
  const sql=kind==='tower'?`SELECT id,name,json_extract(game,'$.towerCleared') AS score FROM nexus_players
      WHERE score>0 ORDER BY score DESC,id LIMIT ?`:
    `SELECT p.id,p.name,SUM(m.delta) AS score FROM nexus_arena_matches m
      JOIN nexus_players p ON p.id=m.player GROUP BY p.id,p.name ORDER BY score DESC,p.name,p.id LIMIT ?`;
  return db.prepare(sql).bind(limit);
}
async function rankings(db){
  const [power,rarity,raid,tower,arena]=await db.batch([
    db.prepare('SELECT id,name,power,top_units FROM nexus_players ORDER BY power DESC,name,id LIMIT 30'),
    db.prepare(`SELECT p.id,p.name,u.value AS unit FROM nexus_players p,json_each(p.rare_units) u
      ORDER BY json_extract(u.value,'$.odds') DESC,json_extract(u.value,'$.name'),json_extract(u.value,'$.serial'),p.id LIMIT 30`),
    db.prepare(`SELECT id,name,json_extract(game,'$.raid.bestDamage') AS score FROM nexus_players
      WHERE json_extract(game,'$.raid.day')=? AND score>0 ORDER BY score DESC,id LIMIT 30`).bind(dailyCycle().day),
    scoreBoard(db,'tower',30),scoreBoard(db,'arena',30)
  ]);
  return {arena:arena.results,raid:raid.results,tower:tower.results,power:power.results.map(({id,name,power,top_units})=>({player:{id,name},power,units:JSON.parse(top_units)})),
    rarity:rarity.results.map(({id,name,unit})=>({...JSON.parse(unit),player:{id,name}}))};
}
const pair=(a,b)=>a<b?[a,b]:[b,a];
async function friends(db,id){
  const now=Date.now(),cycle=dailyCycle(now);
  const [connections,inbox]=await db.batch([
    db.prepare(`SELECT p.id,p.name,p.code,f.accepted,f.requested_by,
      EXISTS(SELECT 1 FROM nexus_gifts g WHERE g.sender=? AND g.recipient=p.id AND g.day=?) AS sent
      FROM nexus_friends f JOIN nexus_players p ON p.id=CASE WHEN f.a=? THEN f.b ELSE f.a END
      WHERE f.a=? OR f.b=? ORDER BY p.name,p.id`).bind(id,cycle.day,id,id,id),
    db.prepare(`SELECT p.id,p.name,g.gold,g.sent_at AS sentAt FROM nexus_gifts g JOIN nexus_players p ON p.id=g.sender
      WHERE g.recipient=? ORDER BY g.sent_at DESC LIMIT 20`).bind(id)
  ]);
  return {friends:connections.results.filter(r=>r.accepted),requests:connections.results.filter(r=>!r.accepted),inbox:inbox.results,cycle,now,giftGold:GIFT_GOLD};
}
async function invite(db,id,code){
  if(typeof code!=='string'||!/^[a-f0-9]{10}$/i.test(code.trim()))reject(400,'Informe o código de amigo com 10 caracteres.');
  const other=await db.prepare('SELECT id FROM nexus_players WHERE code=?').bind(code.trim().toUpperCase()).first();
  if(!other)reject(404,'Código de amigo não encontrado.');
  if(other.id===id)reject(400,'Esse é o seu próprio código.');
  const result=await db.prepare(`INSERT OR IGNORE INTO nexus_friends(a,b,requested_by) SELECT ?,?,?
    WHERE (SELECT count(*) FROM nexus_friends WHERE (a=? OR b=?) AND accepted=1)<40
      AND (SELECT count(*) FROM nexus_friends WHERE (a=? OR b=?) AND accepted=1)<40
      AND (SELECT count(*) FROM nexus_friends WHERE requested_by=? AND accepted=0)<20
      AND (SELECT count(*) FROM nexus_friends WHERE (a=? OR b=?) AND accepted=0 AND requested_by<>?)<40`)
    .bind(...pair(id,other.id),id,id,id,other.id,other.id,id,other.id,other.id,other.id).run();
  if(!result.meta.changes)reject(409,'Já existe um convite ou o limite de amigos foi atingido.');
}
async function reply(db,id,body){
  if(typeof body.id!=='string'||!['accept','remove'].includes(body.decision))reject(400,'Resposta inválida.');
  const ids=pair(id,body.id);
  const statement=body.decision==='remove'
    ?db.prepare('DELETE FROM nexus_friends WHERE a=? AND b=?').bind(...ids)
    :db.prepare(`UPDATE nexus_friends SET accepted=1 WHERE a=? AND b=? AND requested_by<>? AND accepted=0
      AND (SELECT count(*) FROM nexus_friends WHERE (a=? OR b=?) AND accepted=1)<40
      AND (SELECT count(*) FROM nexus_friends WHERE (a=? OR b=?) AND accepted=1)<40`)
      .bind(...ids,id,id,id,body.id,body.id);
  if(!(await statement.run()).meta.changes)reject(409,'A amizade ou o convite já mudou.');
}
async function gift(db,id,recipient){
  if(typeof recipient!=='string')reject(400,'Escolha um amigo.');
  const now=Date.now(),ids=pair(id,recipient);
  const result=await db.prepare(`INSERT OR IGNORE INTO nexus_gifts(sender,recipient,day,gold,sent_at)
    SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM nexus_friends WHERE a=? AND b=? AND accepted=1)`)
    .bind(id,recipient,dailyCycle(now).day,GIFT_GOLD,now,...ids).run();
  if(!result.meta.changes){
    if(!await db.prepare('SELECT 1 FROM nexus_friends WHERE a=? AND b=? AND accepted=1').bind(...ids).first())reject(403,'Presentes são exclusivos para amigos confirmados.');
    reject(409,'Você já enviou um presente a esse amigo neste ciclo.');
  }
  return {gold:GIFT_GOLD};
}
async function readBody(request,limit=8192){
  if(!request.headers.get('Content-Type')?.startsWith('application/json'))reject(415,'Envie JSON.');
  const reader=request.body?.getReader();
  if(!reader)reject(400,'Pedido inválido.');
  const decoder=new TextDecoder();let raw='',bytes=0;
  for(;;){
    const chunk=await reader.read();if(chunk.done)break;
    bytes+=chunk.value.byteLength;
    if(bytes>limit){await reader.cancel();reject(413,'Pedido muito grande.');}
    raw+=decoder.decode(chunk.value,{stream:true});
  }
  let body;
  try{body=JSON.parse(raw+decoder.decode());}catch{reject(400,'Pedido inválido.');}
  if(!body||Array.isArray(body)||typeof body!=='object')reject(400,'Pedido inválido.');
  return body;
}
function json(value,status=200,extraHeaders={}){
  return Response.json(value,{status,headers:{...API_RESPONSE_HEADERS,...extraHeaders}});
}
function databaseFailure(error){
  const message=[error?.message,error?.cause?.message].filter(Boolean).join(' ');
  if(/D1 DB is overloaded|requests queued for too long|too many requests queued/i.test(message))return 'D1_OVERLOADED';
  if(/D1 DB storage operation exceeded timeout/i.test(message))return 'D1_TIMEOUT';
  if(/D1 DB.*(?:restart|transient issue)|replica disconnected from primary|D1_ERROR.*network connection lost|D1 DB storage caused object to be reset/i.test(message))
    return 'D1_UNAVAILABLE';
  return null;
}
export default {
  async fetch(request,env){
    const path=new URL(request.url).pathname;
    if(!path.startsWith('/api/'))return env.ASSETS.fetch(request);
    const start=Date.now();
    let stage='binding';
    try{
      const db=env.NEXUS_DB;
      if(!db)reject(503,'O banco da campanha está indisponível neste ambiente.','D1_BINDING_MISSING');
      if(request.method==='GET'&&path==='/api/health'){
        stage='health';
        await db.prepare('SELECT 1 AS ok').first();
        return json({ok:true,build:BUILD});
      }
      stage='schema';
      await initialize(db);
      stage='route';
      if(path.startsWith('/api/auth/'))return await socialAuth(request,env,db,new URL(request.url));
      const post=request.method==='POST';
      
      if(post&&path==='/api/community/account')return json(await register(db,await readBody(request),request),201);
      const id=await authenticate(db,request);
      const body=post?await readBody(request,path==='/api/community/profile'?PROFILE_BODY_LIMIT:8192):null;
      if(request.method==='GET'){
        if(path==='/api/community/profile')return json(await profile(db,id));
        const other=/^\/api\/community\/profile\/([a-f0-9-]{36})$/.exec(path)?.[1];
        if(other)return json(await profile(db,other));
        if(path==='/api/community/friends')return json(await friends(db,id));
        if(path==='/api/community/ranked')return json(await rankedStatus(db,id));
        if(path==='/api/community/arena')return json(await arenaOpponents(db,id));
        if(path==='/api/community/top/tower'||path==='/api/community/top/arena')
          return json({rows:(await scoreBoard(db,path.endsWith('/tower')?'tower':'arena',10).all()).results});
        if(path==='/api/community/rankings')return json(await rankings(db));
      }
      if(post){
        if(path==='/api/community/logout'){
          const token=request.headers.get('Authorization').slice(7);
          await db.prepare('DELETE FROM nexus_sessions WHERE key=? AND player=?').bind(await hash(token),id).run();
          return json({});
        }
        if(path==='/api/community/ranked')return json(await rankedMatch(db,id,body));
        if(path==='/api/game')return json(await sync(db,id,body));
        if(path==='/api/community/profile'){
          let patch;
          const owner=await db.prepare('SELECT code FROM nexus_players WHERE id=?').bind(id).first();
          try{patch=appearancePatch(body,owner?.code);}catch(error){reject(400,error.message);}
          await db.prepare('UPDATE nexus_players SET appearance=json_patch(appearance,?) WHERE id=?').bind(JSON.stringify(patch),id).run();
          return json(await profile(db,id));
        }
        if(path==='/api/community/friend-request'){await invite(db,id,body.code);return json({});}
        if(path==='/api/community/friend-reply'){await reply(db,id,body);return json({});}
        if(path==='/api/community/gift')return json(await gift(db,id,body.id));
      }
      reject(404,'Rota não encontrada.');
    }catch(error){
      if(error instanceof ApiError&&error.status<500&&!error.code)return json({error:error.message},error.status);
      const temporary=databaseFailure(error);
      const code=temporary??error.code??'API_INTERNAL_ERROR';
      const status=temporary?503:error instanceof ApiError?error.status:500;
      const ray=request.headers.get('CF-Ray')??undefined;
      const route=path.replace(/^\/api\/community\/profile\/[^/]+$/,'/api/community/profile/:id');
      console.error(JSON.stringify({event:'nexus_api_error',build:BUILD,route,method:request.method,stage,status,code,ray,elapsedMs:Date.now()-start,errorName:error.name}));
      const message=temporary?'O serviço da campanha está temporariamente ocupado. Tente novamente em instantes.':
        error instanceof ApiError?error.message:'Não foi possível acessar a campanha online.';
      const retryable=temporary||['REGISTRATION_CONTENTION','SYNC_CONTENTION'].includes(code);
      return json({error:message,code,...(ray?{ray}:{})},status,retryable?{'Retry-After':code==='SYNC_CONTENTION'?'4':'15'}:{});
    }
  }
};
