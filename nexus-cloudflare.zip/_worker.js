const serials=(()=>{

// Reserve the old per-account numbering ranges once, including gaps left by sales.
function serialSchema(players,hasRanks){
  const kind="json_extract(u.value,'$.id') || CASE WHEN json_extract(u.value,'$.shiny') THEN '-shiny' ELSE '' END";
  const base=(value)=>`coalesce((SELECT offset FROM nexus_legacy_ranges WHERE owner=p.id AND kind=json_extract(${value},'$.id') || CASE WHEN json_extract(${value},'$.shiny') THEN '-shiny' ELSE '' END),0)`;
  const mapped=(value)=>`json_set(${value},'$.serial',json_extract(${value},'$.serial')+${base(value)})`;
  const array=(source)=>`(SELECT json_group_array(json(${mapped('u.value')})) FROM json_each(${source}) u)`;
  let entry='u.value';
  for(const field of ['recruit','sold']){
    const obj=`json_extract(u.value,'$.${field}')`;
    entry=`json_set(${entry},'$.${field}',json(CASE WHEN json_type(u.value,'$.${field}')='object' THEN ${mapped(obj)} ELSE NULL END))`;
  }
  return [
    'CREATE TABLE IF NOT EXISTS nexus_serials(id INTEGER PRIMARY KEY, revision INTEGER NOT NULL, counts TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS nexus_legacy_ranges(owner TEXT,kind TEXT,offset INTEGER,amount INTEGER,PRIMARY KEY(owner,kind))',
    `INSERT INTO nexus_legacy_ranges
     WITH source AS (
       SELECT p.id owner,${kind} kind,json_extract(u.value,'$.serial') n,json_extract(p.game,'$.created') created FROM ${players} p,json_each(p.game,'$.collection') u WHERE NOT EXISTS(SELECT 1 FROM nexus_serials)
       UNION ALL SELECT p.id,u.key,u.value,json_extract(p.game,'$.created') FROM ${players} p,json_each(p.game,'$.serials') u WHERE NOT EXISTS(SELECT 1 FROM nexus_serials)
     ), limits AS (SELECT owner,kind,max(n) amount,created FROM source GROUP BY owner,kind)
     SELECT owner,kind,coalesce(sum(amount) OVER(PARTITION BY kind ORDER BY created,owner ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0),amount FROM limits`,
    `UPDATE ${players} AS p SET game=json_set(game,'$.collection',json(${array("p.game,'$.collection'")}),'$.log',json((SELECT json_group_array(json(${entry})) FROM json_each(p.game,'$.log') u)))${hasRanks?`,top_units=${array('p.top_units')},rare_units=${array('p.rare_units')}`:''} WHERE NOT EXISTS(SELECT 1 FROM nexus_serials)`,
    "INSERT OR IGNORE INTO nexus_serials SELECT 1,0,json_group_object(kind,n) FROM (SELECT kind,sum(amount) n FROM nexus_legacy_ranges GROUP BY kind)",
    ...['INSERT','UPDATE OF game'].map((event,i)=>`CREATE TRIGGER IF NOT EXISTS nexus_issue_${i} AFTER ${event} ON ${players}
      WHEN json_extract(NEW.game,'$.issuance.revision')=(SELECT revision+1 FROM nexus_serials WHERE id=1)
      BEGIN UPDATE nexus_serials SET revision=revision+1,counts=json_patch(counts,json_extract(NEW.game,'$.issuance.counts')) WHERE id=1; END`)
  ];
}
function issueSerials(state,units,counter){
  delete state.issuance;
  if(!units.length)return;
  const previous=JSON.parse(counter.counts),counts={};
  for(const unit of units){
    const key=unit.id+(unit.shiny?'-shiny':'');
    unit.serial=counts[key]=(counts[key]??previous[key]??0)+1;
  }
  state.issuance={revision:counter.revision+1,counts};
}

return {serialSchema,issueSerials};
})();
const engine=(()=>{

const DEFAULT_LIMIT = 60000;
const SAMPLE_STEP = 100;
const HP_EPSILON = 1e-8;
const sum = values => values.reduce((a, b) => a + b, 0);
const COLORS = ['Vermelho','Laranja','Amarelo','Verde','Turquesa','Azul','Roxo','Rosa'];
function affinity(a, b) {
  if (!a || !b) return 1;
  if (a === 'Dourado') return b === a ? 2 : 1.5;
  if ((a === 'Branco' || a === 'Preto') && a === b) return 1.5;
  const position = COLORS.indexOf(a);
  if (position < 0) return 1;
  return b === COLORS[(position + 1) % 8] ? 1.5 : b === COLORS[(position + 7) % 8] ? .75 : 1;
}
const distance = (a, b) => Math.hypot((a.x ?? a.slot * 20) - (b.x ?? b.slot * 20), (a.y ?? 50) - (b.y ?? 50));
const MAIN_SKILLS = new Set(['piccolo','yamcha','kuririn','bulma','freeza-boss','ginyu','beam','rush','ward','heal']);

class Combate {
  constructor(rosters, { mode = 'duelo', limit = DEFAULT_LIMIT } = {}) {
    if (!['duelo', 'equipe'].includes(mode) || !Number.isInteger(limit) || limit < SAMPLE_STEP || limit > DEFAULT_LIMIT || rosters.length !== 2 || rosters.some(team => !team.length || team.length > 4)) {
      throw new RangeError('Configuração de combate inválida.');
    }
    this.mode = mode;
    this.limit = limit;
    this.time = 0;
    this.teams = rosters.map((team, side) => team.map((spec, slot) => ({
      ...spec, side, slot, id: `${side}:${slot}`, name: spec.name ?? `${side}:${slot}`,
      hp: spec.hp ?? 1000, maxHp: spec.hp ?? 1000, attack: spec.attack ?? 100, magic: spec.magic ?? 100,
      defense: spec.defense ?? 0, resistance: spec.resistance ?? 0, shield: spec.shield ?? 0,
      interval: Math.max(SAMPLE_STEP, spec.interval ?? 3000), nextBasic: Math.max(SAMPLE_STEP, spec.interval ?? 3000),
      nextAssist: 5000, evade: spec.evade ?? 0, intercept: spec.intercept ?? 0, survive: spec.survive ?? 0, protectUntil: spec.intercept ? Infinity : 0,
      revive: spec.revive ?? 0, vector: spec.kind === 'accelerator' ? 2 : 0, vectorReady: 0,
      uses: 0, skillReady: 0, actions: 0, seenId: null, seenActions: 0, graceUntil: 0,
      weakenUntil: 0, powerUntil: 0, resistedUntil: 0,
    })));
    this.log = [];
    this.hasteUntil=[0,0];
    for(const team of this.teams){
      const king=team.find(u=>u.trait==='Haki do Rei');
      if(king)for(const foe of this.teams[1-king.side]){
        foe.stunUntil=2000;foe.exposedUntil=2000;
      }
    }
  }

  record(type, actor, target, data = {}) {
    this.log.push({ time: this.time, type, actor: actor?.id, target: target?.id, ...data });
  }

  alive(u) { return u.hp > HP_EPSILON; }
  active(side) { return this.teams[side].find(u => this.alive(u)); }
  present(u) { return this.alive(u) && (this.mode === 'equipe' || this.active(u.side) === u); }

  blocked(u){return u.stunUntil>this.time||(this.freezeUntil>this.time&&this.freezeOwner!==u);}
  pace(u){
    if(u.hasteUntil>this.time)return .2;
    return this.hasteUntil[u.side]>this.time?.6:1;
  }
  beginAttack(u){
    if(u.trait!=='Made in Heaven'||u.heavenUsed)return;
    const team=this.teams[u.side],before=team.map(f=>this.pace(f));
    u.heavenUsed=true;u.hasteUntil=this.time+5000;this.hasteUntil[u.side]=this.time+5000;
    team.forEach((f,i)=>{
      const ratio=this.pace(f)/before[i];
      if(f.nextBasic>this.time)f.nextBasic=this.time+(f.nextBasic-this.time)*ratio;
      if(f.ready>this.time/1000)f.ready=this.time/1000+(f.ready-this.time/1000)*ratio;
    });
    this.record('aceleração',u);
  }
  outgoingPower(source,damage,basic=false){
    const trait=source.trait==='Made in Heaven'||source.nen?4:1;
    return damage*trait*(basic&&source.weakenUntil>this.time?.65:1);
  }

  hit(source, target, attack = {}) {
    const { damage = source.attack, magic = false, skill = true, area = false, reflected = false,
      removeShield = false, shieldMultiplier = 1, ignoreDefense = 0, blockRevive = false, delayOnBreak = 0 } = attack;
    if (!this.alive(source) || !this.present(target) || source.side === target.side) return false;
    if (!Number.isFinite(damage) || damage < 0 || !Number.isFinite(shieldMultiplier) || shieldMultiplier < 1) throw new RangeError('Dano ou multiplicador inválido.');
    if(!reflected)this.beginAttack(source);
    let victim = target,interceptFactor=1;
    if(!area&&!reflected){
      const guard=this.teams[target.side].find(u=>u!==target&&u.trait==='Restrição Celestial'&&!this.blocked(u)&&this.alive(u)&&(u.guardUses??0)<2&&(this.mode==='duelo'||distance(u,target)<=30));
      if(guard){guard.guardUses=(guard.guardUses??0)+1;victim=guard;interceptFactor=.5;this.record('intercepta',guard,target);}
    }
    if (victim===target && !area && !reflected && this.mode === 'equipe') {
      const guard = this.teams[target.side].find(u => u !== target && !this.blocked(u) && this.alive(u) && u.intercept > 0 && u.protectUntil >= this.time && distance(u,target) <= 30);
      if (guard) {
        guard.intercept--;
        victim = guard;
        this.record('intercepta', guard, target);
      }
    }
    if (!area && !reflected && victim.evade > 0) {
      victim.evade--;
      this.record('esquiva', victim, source);
      if(victim.trait==='Instinto Superior'&&!attack.counter&&!this.blocked(victim)&&this.present(source))this.hit(victim,source,{skill:false,counter:true,magic:!!victim.magicBasic,damage:victim.magicBasic?victim.magic:victim.attack});
      return true;
    }
    if(!area&&!reflected&&skill&&victim.trait==='Haki da Observação'&&(victim.observeUses??0)<2&&!this.blocked(victim)&&this.present(source)){
      victim.observeUses=(victim.observeUses??0)+1;
      this.hit(victim,source,{skill:false,counter:true,damage:2*(victim.magicBasic?victim.magic:victim.attack),magic:!!victim.magicBasic});
      if(!this.alive(source))return true;
    }
    if (!area && !reflected && skill) {
      const mirror=magic&&this.teams[victim.side].find(u=>u.trait==='Full Counter'&&!u.mirrorUsed&&this.alive(u)&&!this.blocked(u)&&(u===victim||this.mode==='duelo'||distance(u,victim)<=30));
      if(mirror){
        mirror.mirrorUsed=true;this.record('reflete',mirror,source);
        this.hit(mirror,this.present(source)?source:this.active(source.side),{...attack,damage:damage*2,reflected:true});
        return true;
      }
      const vector = this.teams[victim.side].find(u => this.alive(u) && u.vector > 0 && u.vectorReady <= this.time && (this.mode === 'duelo' || Math.abs(u.slot - victim.slot) <= 1));
      if (vector) {
        vector.vector--;
        vector.vectorReady = this.time + 8000;
        this.record('reflete', vector, source, { remaining: vector.vector });
        const returnTarget = this.present(source) ? source : this.active(source.side);
        if (returnTarget) this.hit(vector, returnTarget, { ...attack, damage, reflected: true });
        return true;
      }
    }
    const openPower = skill && !reflected && source.powerUntil > this.time;
    if (openPower) source.powerUntil = 0;
    const mitigation = (magic ? victim.resistance : victim.defense) * (1 - ignoreDefense);
    let value = this.outgoingPower(source,damage,!skill) * interceptFactor * (victim.exposedUntil>this.time?1.3:1) * affinity(source.color,victim.color) * (openPower ? 1.3 : 1) * 40 / (40 + mitigation/(source.scale || 1));
    const priorShield = victim.shield;
    if (removeShield) victim.shield = 0;
    const absorbed = Math.min(victim.shield, value * shieldMultiplier);
    victim.shield -= absorbed;
    value -= absorbed / shieldMultiplier;
    if (priorShield > 0 && victim.shield <= HP_EPSILON) {
      victim.shield = 0;
      victim.nextBasic += delayOnBreak;
      this.record('escudo rompe', source, victim);
    }
    const actual = Math.min(victim.hp, value);
    victim.hp = Math.max(0, victim.hp - value);
    this.record('dano', source, victim, { hp: actual, reflected, remaining: victim.hp, skill });
    if (!this.alive(victim)) this.defeat(victim, source, blockRevive);
    return true;
  }

  defeat(victim, source, blockRevive) {
    if (victim.survive > 0) {
      victim.survive--;
      if(victim.trait==="Zenkai"){victim.attack*=1.75;victim.magic*=1.75;}
      victim.hp = victim.maxHp * .4;
      this.record('sobrevive', victim, source, { remaining: victim.hp });
    } else if (victim.revive > 0 && !blockRevive) {
      victim.revive--;
      victim.hp = victim.maxHp * .7;
      this.record('ressurge', victim, source, { remaining: victim.hp });
    } else {
      victim.hp = 0;
      victim.shield = 0;
      const successor = this.mode === 'duelo' ? this.active(victim.side) : null;
      this.record('cai', victim, source);
      if (successor) {
        successor.nextBasic = this.time + successor.interval;
        successor.graceUntil = this.time + SAMPLE_STEP;
        this.record('entra', successor);
      }
    }
  }

  heal(unit, amount) {
    if (!this.alive(unit)) return;
    unit.hp = Math.min(unit.maxHp, unit.hp + amount);
    this.record('cura', unit, undefined, { remaining: unit.hp });
  }

  use(actor,target,type,role='principal'){
    const used=this.cast(actor,target,type,role);
    if(used&&role==='principal'&&actor.trait==='The World'&&!actor.worldUsed){
      actor.worldUsed=true;this.freezeOwner=actor;this.freezeUntil=this.time+3000;
      actor.skillReady=0;actor.nextBasic=Math.min(actor.nextBasic,this.time+SAMPLE_STEP);
      actor.ready=this.time/1000;this.record('tempo parado',actor);
    }
    return used;
  }
  cast(actor, target, type, role = 'principal') {
    if (!this.alive(actor) || !this.present(target)) return false;
    const strike = options => this.hit(actor, target, options);
    switch (type) {
      case 'reescrita':
      case 'ciclo_vital': {
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+9000;
        const ally=this.teams[actor.side].filter(unit=>this.present(unit))
          .reduce((lowest,unit)=>unit.hp/unit.maxHp<lowest.hp/lowest.maxHp?unit:lowest);
        if(type==='ciclo_vital'){
          this.heal(ally,actor.magic*2);
          return strike({damage:actor.magic*1.05,magic:true});
        }
        if(actor.uses===0&&ally.hp<=ally.maxHp*.4){
          actor.uses++;
          this.heal(ally,ally.maxHp*.5);
          return true;
        }
        return strike({damage:actor.attack*1.9});
      }
      case 'nichirin': {
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+10000;
        const victims=this.teams[target.side].filter(unit=>this.present(unit)&&distance(unit,target)<=28);
        this.record('onda',actor,target,{targets:victims.map(unit=>unit.id)});
        for(const unit of victims)this.hit(actor,unit,{damage:actor.attack*(unit===target?1.8:.85),area:true});
        return true;
      }
      case 'tempestade': {
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+10000;
        const other=this.teams[target.side].find(unit=>unit!==target&&this.present(unit));
        strike({damage:actor.magic*1.85,magic:true,ignoreDefense:.3});
        if(other)this.hit(actor,other,{damage:actor.magic*.75,magic:true});
        return true;
      }
      case 'ashisogi':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+9000;
        target.weakenUntil=Math.max(target.weakenUntil,this.time+4000);
        return strike({damage:actor.magic*1.3,magic:true});
      case 'metralleta':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+9000;
        for(let i=0;i<3&&this.alive(actor)&&this.present(target);i++)strike({damage:actor.magic*.6,magic:true});
        return true;
      case 'shunko':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+12000;
        actor.evade++;
        return strike({damage:actor.attack*1.4});
      case 'excalibur':
        if(actor.skillReady>this.time)return false;
        actor.skillReady=this.time+7000;
        return strike({damage:actor.attack*1.45,ignoreDefense:.35});
      case 'piccolo':
      case 'ward': {
        if (actor.skillReady > this.time) return false;
        actor.skillReady = this.time + 10000;
        actor.intercept = 1;
        actor.protectUntil = this.time + 4500;
        actor.shield = Math.max(actor.shield,actor.magic * 1.1);
        this.record('protege',actor);
        return true;
      }
      case 'bulma':
      case 'heal': {
        if (actor.skillReady > this.time) return false;
        const ally = this.teams[actor.side].filter(u=>this.present(u)).sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp)[0];
        if (!ally || ally.hp/ally.maxHp > .95) return false;
        actor.skillReady = this.time + 7000;
        if (type === 'heal') this.heal(ally,actor.magic * 1.3);
        else { ally.shield=Math.max(ally.shield,actor.magic*2);this.record('protege',actor,ally); }
        return true;
      }
      case 'yamcha':
      case 'kuririn':
      case 'rush':
      case 'beam': {
        if (actor.skillReady > this.time) return false;
        const magic = ['kuririn','beam'].includes(type);
        const victim = type === 'kuririn' ? this.teams[target.side].filter(u=>this.present(u)).sort((a,b)=>a.hp-b.hp)[0] : target;
        actor.skillReady = this.time + (magic ? 7000 : 6000);
        return this.hit(actor,victim,{ damage: magic ? actor.magic*1.65 : actor.attack*1.6, magic });
      }
      case 'freeza-boss':
      case 'ginyu': {
        if (actor.skillReady > this.time) return false;
        actor.skillReady = this.time + 12000;
        const anchor = this.teams[target.side].filter(u=>this.present(u)).sort((a,b)=>b.hp-a.hp)[0];
        const victims = this.teams[target.side].filter(u=>this.present(u)&&distance(u,anchor)<=28);
        this.record('onda',actor,anchor,{ targets: victims.map(u=>u.id) });
        for (const victim of victims) this.hit(actor,victim,{damage:actor.magic * (type === 'freeza-boss' ? .82 : .7),magic:true,area:true});
        return true;
      }
      case 'beerus': {
        if (role === 'principal' && actor.skillReady > this.time) return false;
        if (role === 'principal') actor.skillReady = this.time + 9000;
        return strike({ damage: actor.magic * (role === 'reserva' ? 1.25 : 2.4), magic: true, removeShield: true, blockRevive: role !== 'reserva' });
      }
      case 'zoro': return strike({ damage: actor.attack * 1.1, shieldMultiplier: 2 });
      case 'barba-branca': return strike({ damage: actor.attack * 1.35, removeShield: true, delayOnBreak: 1000 });
      case 'polnareff': {
        if (role === 'reserva') return strike({ damage: actor.attack, shieldMultiplier: 2 });
        for (let i=0; i<3 && this.alive(actor) && this.present(target); i++) {
          strike({ damage: actor.attack * (i === 2 && !target.shield ? .75 : .45), shieldMultiplier: i === 2 ? 2 : 1 });
        }
        return true;
      }
      case 'tetsuo': {
        const boosted = (this.active(actor.side)?.resistedUntil ?? 0) > this.time;
        return strike({ damage: actor.magic * (boosted ? 1.65 : 1.1), magic: true, removeShield: boosted });
      }
      case 'kaguya': {
        if (actor.uses >= 2 || actor.skillReady > this.time) return false;
        actor.uses++;
        actor.skillReady = this.time + 12000;
        this.teams[target.side].filter(u=>this.alive(u)).forEach(u=>{u.weakenUntil = this.time + 4000;});
        this.teams[actor.side].filter(u=>this.alive(u)).forEach(u=>{u.powerUntil = this.time + 4000;});
        this.record('dimensão', actor, target);
        return true;
      }
      case 'saitama': {
        if (actor.uses >= 2 || actor.skillReady > this.time || target.actions - (actor.seenId === target.id ? actor.seenActions : 0) < 3) return false;
        actor.uses++;
        actor.skillReady = this.time + 10000;
        actor.seenId = target.id;
        actor.seenActions = target.actions;
        return strike({ damage: actor.attack * 2.8, removeShield: true, ignoreDefense: .5 });
      }
      default: return false;
    }
  }

  run() {
    for (this.time = SAMPLE_STEP; this.time <= this.limit; this.time += SAMPLE_STEP) {
      if (!this.active(0) || !this.active(1)) break;
      const order = [0, 1].sort((a,b) => (this.time / SAMPLE_STEP) % 2 ? a-b : b-a);
      for (const side of order) {
        const own = this.active(side);
        if (!own) continue;
        for (const actor of this.mode === 'duelo' ? [own] : this.teams[side]) {
          const target = this.mode === 'equipe' ? this.teams[1-side].filter(u=>this.present(u)).sort((a,b)=>(b.x??-b.slot)-(a.x??-a.slot))[0] : this.active(1-side);
          if (!target || !this.present(actor) || actor.nextBasic > this.time || actor.graceUntil > this.time) continue;
          if(this.blocked(actor))continue;
          this.beginAttack(actor);
          actor.nextBasic = this.time + actor.interval*this.pace(actor);
          actor.actions++;
          if (!this.use(actor, target, actor.kind) || MAIN_SKILLS.has(actor.kind) && ['piccolo','ward','bulma','heal'].includes(actor.kind)) this.hit(actor, target, { skill: false, damage: actor.magicBasic ? actor.magic : actor.attack, magic: !!actor.magicBasic });
        }
        if (this.mode === 'duelo') for (const reserve of this.teams[side]) {
          const ally = this.active(side);
          const target = this.active(1-side);
          if (!ally || !target || !this.alive(reserve) || reserve === ally || this.blocked(reserve) || reserve.nextAssist > this.time) continue;
          reserve.nextAssist = this.time + 7000;
          if (reserve.healer) this.heal(ally, reserve.healer);
          else if (reserve.assist) this.use(reserve, target, reserve.assist, 'reserva');
        }
      }
      if (!this.active(0) || !this.active(1)) break;
    }
    const live = this.teams.map(t=>t.some(u=>this.alive(u)));
    const scores = this.teams.map(t=>sum(t.map(u=>u.hp/u.maxHp))/t.length);
    const timeout = live.every(Boolean);
    const scoreDiff = scores[0]-scores[1];
    const winner = timeout ? (Math.abs(scoreDiff)<HP_EPSILON ? null : scoreDiff>0?0:1) : live[0]===live[1]?null:live[0]?0:1;
    return { winner, seconds: Math.min(this.time,this.limit)/1000, reason: timeout?'limite':'eliminação', scores, events: this.log };
  }
}


return {affinity,Combate};
})();
const game=(()=>{
const {Combate,affinity}=engine;

const AREAS = [
  { id:'entrada', name:'Costa de Namek', description:'Patrulhas do império rondam o litoral.', levels:[1,3], unlock:1, enemy:'Soldado da Tropa Freeza', base:[150,18,9,9], color:'Roxo' },
  { id:'meio', name:'Planícies Verdes', description:'O terreno aberto favorece as tropas de elite.', levels:[4,6], unlock:4, enemy:'Veterano da Tropa Freeza', base:[220,23,12,12], color:'Amarelo' },
  { id:'final', name:'Base de Freeza', description:'Vença 12 encontros nesta área para liberar Freeza.', levels:[7,10], unlock:7, enemy:'Oficial da Tropa Freeza', base:[300,28,14,14], color:'Vermelho' },
];
const BOSS = {name:'Freeza · Forma Final',base:[520,38,18,18], color:'Roxo'};
const WORLDS = [
  {
    name:"Namek", universe:"Dragon Ball",
    areas:AREAS,
    elite:{"name": "Capitão Ginyu", "level": 11, "base": [380, 33, 16, 16]},
    boss:{"name": "Freeza · forma final", "level": 12, "base": [520, 38, 18, 18], "kind": "freeza-boss", "color": "Roxo"},
  },
  {
    name:"Arlong Park", universe:"One Piece",
    areas:[
      {"name": "Costa de Cocoyasi", "enemy": "Vigia dos Piratas Arlong", "levels": [11, 13], "unlock": 1, "base": [150, 18, 9, 9], "color": "Amarelo", "description": "Vigia dos Piratas Arlong"},
      {"name": "Vila de Cocoyasi", "enemy": "Homem-peixe dos Piratas Arlong", "levels": [14, 16], "unlock": 14, "base": [220, 23, 12, 12], "color": "Vermelho", "description": "Homem-peixe dos Piratas Arlong"},
      {"name": "Fortaleza de Arlong", "enemy": "Veterano dos Piratas Arlong", "levels": [17, 20], "unlock": 17, "base": [300, 28, 14, 14], "color": "Azul", "description": "Veterano dos Piratas Arlong"}
    ],
    elite:{"name": "Kuroobi", "level": 21, "base": [385, 33, 16, 16]},
    boss:{"name": "Arlong", "level": 22, "base": [532, 38, 18, 18], "kind": "rush", "color": "Azul"},
  },
  {
    name:"Exames Chūnin", universe:"Naruto",
    areas:[
      {"name": "Portões da Folha", "enemy": "Genin rival", "levels": [21, 23], "unlock": 1, "base": [150, 18, 9, 9], "color": "Vermelho", "description": "Genin rival"},
      {"name": "Floresta da Morte", "enemy": "Genin da Vila do Som", "levels": [24, 26], "unlock": 24, "base": [220, 23, 12, 12], "color": "Azul", "description": "Genin da Vila do Som"},
      {"name": "Arena dos Exames", "enemy": "Genin da Vila da Areia", "levels": [27, 30], "unlock": 27, "base": [300, 28, 14, 14], "color": "Verde", "description": "Genin da Vila da Areia"}
    ],
    elite:{"name": "Neji Hyūga", "level": 31, "base": [390, 33, 16, 16]},
    boss:{"name": "Gaara · transformação parcial", "level": 32, "base": [544, 38, 18, 18], "kind": "ward", "color": "Laranja"},
  },
  {
    name:"Soul Society", universe:"Bleach",
    areas:[
      {"name": "Rukongai", "enemy": "Shinigami em patrulha", "levels": [31, 33], "unlock": 1, "base": [150, 18, 9, 9], "color": "Azul", "description": "Shinigami em patrulha"},
      {"name": "Muralhas do Seireitei", "enemy": "Soldado da guarda do Seireitei", "levels": [34, 36], "unlock": 34, "base": [220, 23, 12, 12], "color": "Verde", "description": "Soldado da guarda do Seireitei"},
      {"name": "Colina de Sōkyoku", "enemy": "Oficial de esquadrão", "levels": [37, 40], "unlock": 37, "base": [300, 28, 14, 14], "color": "Turquesa", "description": "Oficial de esquadrão"}
    ],
    elite:{"name": "Renji Abarai", "level": 41, "base": [395, 33, 16, 16]},
    boss:{"name": "Byakuya Kuchiki", "level": 42, "base": [556, 38, 18, 18], "kind": "beam", "color": "Rosa"},
  },
  {
    name:"Jujutsu Kaisen", universe:"Jujutsu Kaisen",
    areas:[
      {"name": "Escola de Jujutsu", "enemy": "Maldição menor", "levels": [41, 43], "unlock": 1, "base": [150, 18, 9, 9], "color": "Verde", "description": "Maldição menor"},
      {"name": "Distrito amaldiçoado", "enemy": "Maldição de distrito", "levels": [44, 46], "unlock": 44, "base": [220, 23, 12, 12], "color": "Turquesa", "description": "Maldição de distrito"},
      {"name": "Domínio vulcânico", "enemy": "Maldição de grau 2", "levels": [47, 50], "unlock": 47, "base": [300, 28, 14, 14], "color": "Rosa", "description": "Maldição de grau 2"}
    ],
    elite:{"name": "Portador de Dedo", "level": 51, "base": [400, 33, 16, 16]},
    boss:{"name": "Jogo", "level": 52, "base": [568, 38, 18, 18], "kind": "ginyu", "color": "Vermelho"},
  },
  {
    name:"Black Clover", universe:"Black Clover",
    areas:[
      {"name": "Vila de Hage", "enemy": "Recruta do Olho do Sol da Meia-Noite", "levels": [51, 53], "unlock": 1, "base": [150, 18, 9, 9], "color": "Turquesa", "description": "Recruta do Olho do Sol da Meia-Noite"},
      {"name": "Floresta encantada", "enemy": "Mago do Olho do Sol da Meia-Noite", "levels": [54, 56], "unlock": 54, "base": [220, 23, 12, 12], "color": "Rosa", "description": "Mago do Olho do Sol da Meia-Noite"},
      {"name": "Templo submerso", "enemy": "Veterano do Olho do Sol da Meia-Noite", "levels": [57, 60], "unlock": 57, "base": [300, 28, 14, 14], "color": "Laranja", "description": "Veterano do Olho do Sol da Meia-Noite"}
    ],
    elite:{"name": "Fana", "level": 61, "base": [405, 33, 16, 16]},
    boss:{"name": "Vetto", "level": 62, "base": [580, 38, 18, 18], "kind": "rush", "color": "Verde"},
  },
  {
    name:"Nanatsu no Taizai", universe:"Nanatsu no Taizai",
    areas:[
      {"name": "Arredores de Liones", "enemy": "Recruta de Liones", "levels": [61, 63], "unlock": 1, "base": [150, 18, 9, 9], "color": "Rosa", "description": "Recruta de Liones"},
      {"name": "Cidade de Liones", "enemy": "Cavaleiro de Liones", "levels": [64, 66], "unlock": 64, "base": [220, 23, 12, 12], "color": "Laranja", "description": "Cavaleiro de Liones"},
      {"name": "Castelo real", "enemy": "Cavaleiro Sagrado", "levels": [67, 70], "unlock": 67, "base": [300, 28, 14, 14], "color": "Roxo", "description": "Cavaleiro Sagrado"}
    ],
    elite:{"name": "Dreyfus", "level": 71, "base": [410, 33, 16, 16]},
    boss:{"name": "Hendrickson · forma demoníaca", "level": 72, "base": [592, 38, 18, 18], "kind": "beam", "color": "Preto"},
  },
  {
    name:"JoJo", universe:"JoJo",
    areas:[
      {"name": "Ruas do Cairo", "enemy": "Capanga de DIO", "levels": [71, 73], "unlock": 1, "base": [150, 18, 9, 9], "color": "Laranja", "description": "Capanga de DIO"},
      {"name": "Distrito antigo", "enemy": "Usuário de Stand a serviço de DIO", "levels": [74, 76], "unlock": 74, "base": [220, 23, 12, 12], "color": "Roxo", "description": "Usuário de Stand a serviço de DIO"},
      {"name": "Mansão de DIO", "enemy": "Usuário de Stand veterano", "levels": [77, 80], "unlock": 77, "base": [300, 28, 14, 14], "color": "Amarelo", "description": "Usuário de Stand veterano"}
    ],
    elite:{"name": "Vanilla Ice", "level": 81, "base": [415, 33, 16, 16]},
    boss:{"name": "DIO · The World", "level": 82, "base": [604, 38, 18, 18], "kind": "rush", "color": "Amarelo"},
  },
  {
    name:"Hunter × Hunter", universe:"Hunter × Hunter",
    areas:[
      {"name": "Fronteira de NGL", "enemy": "Formiga Quimera operária", "levels": [81, 83], "unlock": 1, "base": [150, 18, 9, 9], "color": "Roxo", "description": "Formiga Quimera operária"},
      {"name": "Território das formigas", "enemy": "Formiga Quimera soldado", "levels": [84, 86], "unlock": 84, "base": [220, 23, 12, 12], "color": "Amarelo", "description": "Formiga Quimera soldado"},
      {"name": "Palácio Real", "enemy": "Formiga Quimera capitã", "levels": [87, 90], "unlock": 87, "base": [300, 28, 14, 14], "color": "Vermelho", "description": "Formiga Quimera capitã"}
    ],
    elite:{"name": "Neferpitou", "level": 91, "base": [420, 33, 16, 16]},
    boss:{"name": "Meruem", "level": 92, "base": [616, 38, 18, 18], "kind": "rush", "color": "Verde"},
  },
  {
    name:"One Punch Man", universe:"One Punch Man",
    areas:[
      {"name": "Periferia da Cidade Z", "enemy": "Monstro nível Lobo", "levels": [91, 93], "unlock": 1, "base": [150, 18, 9, 9], "color": "Amarelo", "description": "Monstro nível Lobo"},
      {"name": "Zona evacuada", "enemy": "Monstro nível Tigre", "levels": [94, 96], "unlock": 94, "base": [220, 23, 12, 12], "color": "Vermelho", "description": "Monstro nível Tigre"},
      {"name": "Covil dos monstros", "enemy": "Monstro nível Demônio", "levels": [97, 100], "unlock": 97, "base": [300, 28, 14, 14], "color": "Azul", "description": "Monstro nível Demônio"}
    ],
    elite:{"name": "Rei do Mar Profundo", "level": 101, "base": [425, 33, 16, 16]},
    boss:{"name": "Boros", "level": 102, "base": [628, 38, 18, 18], "kind": "freeza-boss", "color": "Vermelho"},
  }
];
const worldOf = state=>WORLDS[state.world??0];
const levelCap = state=>10*(1+(state.unlocked??0));
const COLORS = {Verde:'#71dd9f',Laranja:'#ffab68',Amarelo:'#f5d66c',Azul:'#83baff',Branco:'#ecebff',Roxo:'#cc95ff',Rosa:'#f592bc',Preto:'#a8a2be',Vermelho:'#ff8290',Turquesa:'#70e1da',Dourado:'#ffe28a'};
const TIERS = ['Comum','Incomum','Rara','Épica','Mítica','Divina','Secreta','Transcendente'];
const baseStats = [[100,20,20,12,12,100],[106,21,21,13,13,101],[113,23,23,14,14,102],[121,24,24,15,15,103],[130,26,26,16,16,104],[140,28,28,17,17,105],[151,30,30,18,18,106],[164,33,33,20,20,108]];
const roles = {Combatente:[.10,.25,-.15,0,0,0],Guardião:[.25,-.10,0,.25,.15,0],Mágico:[-.15,0,.30,0,.10,0],Suporte:[0,-.15,.15,0,.15,.05]};
const roster = [
  ["shinra_banshoman", "Shinra Banshōman", 8, "Dourado", "Combatente", "reescrita", "Reescrita da Realidade", "Ataque dos Dourados +22%", "fighter", "Fire Force"],
  ["benimaru_shinmon", "Benimaru Shinmon", 7, "Vermelho", "Combatente", "nichirin", "Nichirin", "Ataque dos Vermelhos +18%", "fighter", "Fire Force"],
  ["luminous", "Luminous Valentine", 7, "Rosa", "Suporte", "ciclo_vital", "Ciclo de Vida e Morte", "PV dos Rosas +18%", "support", "Tensei Shitara Slime Datta Ken"],
  ["veldora", "Veldora Tempest", 7, "Turquesa", "Mágico", "tempestade", "Tempestade do Dragão", "Magia dos Turquesas +18%", "freeza", "Tensei Shitara Slime Datta Ken"],

  ["mayuri", "Mayuri Kurotsuchi", 5, "Roxo", "Mágico", "ashisogi", "Ashisogi Jizō", "Magia dos Roxos +15%", "support", "Bleach"],
  ["starrk", "Coyote Starrk", 6, "Azul", "Mágico", "metralleta", "Cero Metralleta", "Magia dos Azuis +15%", "fighter", "Bleach"],
  ["yoruichi", "Yoruichi Shihōin", 5, "Amarelo", "Combatente", "shunko", "Shunkō", "Ataque dos Amarelos +15%", "fighter", "Bleach"],
  ["urahara", "Kisuke Urahara", 6, "Verde", "Suporte", "bulma", "Benihime · Escudo de Sangue", "PV dos Verdes +15%", "support", "Bleach"],
  ["shinra", "Shinra Kusakabe", 4, "Vermelho", "Combatente", "rush", "Chute de Ignição", "Ataque dos Vermelhos +12%", "fighter", "Fire Force"],
  ["arthur", "Arthur Boyle", 4, "Azul", "Combatente", "excalibur", "Excalibur", "Ataque dos Azuis +12%", "fighter", "Fire Force"],
  ["maki_oze", "Maki Oze", 3, "Laranja", "Guardião", "ward", "Guarda das Chamas", "PV dos Laranjas +10%", "namek", "Fire Force"],
  ["iris", "Iris", 2, "Branco", "Suporte", "heal", "Prece da Companhia 8", "PV dos Brancos +10%", "support", "Fire Force"],
  ['piccolo','Piccolo',4,'Verde','Guardião','piccolo','Proteção Namekuseijin','Defesa e Resistência de Dragon Ball +12%','namek'],
  ['yamcha','Yamcha',1,'Laranja','Combatente','yamcha','Punho do Lobo','Ataque de Combatentes +8%','fighter'],
  ['kuririn','Kuririn',2,'Amarelo','Mágico','kuririn','Disco Cortante','Magia dos Amarelos +10%','monk'],
  ['bulma','Bulma',1,'Azul','Suporte','bulma','Cápsula de Proteção','PV dos Azuis +8%','support'],
  ['tenshinhan','Tenshinhan',3,'Branco','Suporte','ward','Taiyōken','Velocidade dos Brancos +10%','monk'],
  ['gohan','Gohan · Namek',4,'Amarelo','Combatente','rush','Explosão de Raiva','Ataque dos Amarelos +10%','fighter'],
  ['freeza','Freeza · Forma Final',5,'Roxo','Mágico','beam','Raio da Morte','Magia dos Roxos +15%','freeza'],
  ['android17','Android 17',6,'Verde','Guardião','ward','Barreira Contínua','Defesa dos Verdes +15%','fighter'],
  ['vegeta','Vegeta · Blue',7,'Azul','Combatente','rush','Final Flash','Ataque dos Azuis +18%','fighter'],
  ['broly','Broly · Super',7,'Verde','Combatente','rush','Fúria Crescente','Ataque de Combatentes +18%','namek'],
  ['goku','Goku · Instinto Superior',8,'Branco','Combatente','rush','Resposta Instintiva','Ataque de Dragon Ball +22%','fighter'],
  ['beerus','Beerus',8,'Roxo','Mágico','beerus','Hakai','Magia de Mágicos +22%','freeza'],
  ['usopp','Usopp',1,'Amarelo','Suporte','heal','Estilingue','PV dos Amarelos +8%','support','One Piece'],
  ['nami','Nami',2,'Turquesa','Mágico','beam','Nuvem de Tempestade','Magia dos Turquesas +10%','support','One Piece'],
  ['rocklee','Rock Lee',3,'Verde','Combatente','rush','Lótus Primária','Velocidade dos Verdes +10%','fighter','Naruto'],
  ['zoro','Zoro',4,'Verde','Combatente','rush','Santōryū','Ataque dos Verdes +12%','fighter','One Piece'],
  ['law','Trafalgar Law',5,'Azul','Suporte','bulma','ROOM','PV dos Azuis +12%','support','One Piece'],
  ['gojo','Gojo',8,'Azul','Mágico','beam','Vazio Ilimitado','Magia dos Azuis +22%','fighter','Jujutsu Kaisen'],
  ['netero','Netero',6,'Dourado','Combatente','rush','Mãos do Bodisatva','Ataque dos Dourados +15%','monk','Hunter × Hunter'],
  ['mob','Mob · ???%',7,'Preto','Mágico','beam','Despertar Psíquico','Magia dos Pretos +18%','support','Mob Psycho 100'],
  ['accelerator','Accelerator',8,'Branco','Guardião','accelerator','Controle Vetorial','Resistência dos Brancos +22%','fighter','Toaru'],
];
const approvedArt = {
  "yamcha": "yamcha",
  "bulma": "bulma",
  "piccolo": "piccolo",
  "kuririn": "kuririn",
  "gohan": "gohan-namek",
  "tenshinhan": "tenshinhan",
  "freeza": "freeza-forma-final",
  "android17": "android-17-torneio-do-poder",
  "vegeta": "vegeta-super-saiyajin-blue",
  "broly": "broly-super",
  "goku": "goku-instinto-superior",
  "beerus": "beerus",
  "usopp": "usopp",
  "nami": "nami",
  "rocklee": "rock-lee",
  "zoro": "zoro",
  "law": "trafalgar-law",
  "gojo": "gojo",
  "netero": "netero",
  "mob": "mob-por-cento",
  "accelerator": "accelerator",
  "shinra_banshoman": "shinra-banshoman",
  "benimaru_shinmon": "benimaru-shinmon",
  "luminous": "luminous-valentine",
  "veldora": "veldora-tempest",
  "shinra": "shinra-kusakabe",
  "arthur": "arthur-boyle",
  "maki_oze": "maki-oze",
  "iris": "iris",
  "mayuri": "mayuri-kurotsuchi",
  "starrk": "coyote-starrk",
  "yoruichi": "yoruichi-shihoin",
  "urahara": "kisuke-urahara"
};

function spriteFor(unit){
  const slug=approvedArt[unit.id];
  if(!slug)return CHARACTERS[unit.id].sprite;
  return "ap-"+slug+(unit.shiny?"-shiny":"");
}

const CHARACTERS = Object.fromEntries(roster.map(([id,name,tier,color,role,kind,skill,leader,sprite,universe='Dragon Ball'])=>[id,{id,name,tier,color,role,kind,skill,leader,sprite:approvedArt[id]?"ap-"+approvedArt[id]:sprite,universe}]));
const SKILL_EFFECTS = {
  reescrita:"Golpeia com 190% do Ataque. Uma vez por luta, se um aliado em campo estiver com até 40% de PV, usa a ação para restaurar metade dos PV máximos do mais ferido. Recarga de 9 s.",
  nichirin:"Atinge o alvo com 180% do Ataque e os demais inimigos a até 28 unidades dele com 85% do Ataque. Recarga de 10 s.",
  ciclo_vital:"Cura em 200% da Magia o aliado em campo com a menor porcentagem de PV e atinge o adversário com 105% da Magia. Recarga de 9 s.",
  tempestade:"Desfere um raio de 185% da Magia que ignora 30% da Resistência. Um arco secundário de 75% da Magia atinge outro inimigo em campo, se houver. Recarga de 10 s.",

  ashisogi:"Enfraquece os ataques básicos do alvo em 35% por 4 s e causa dano mágico de 130% da Magia. Recarga de 9 s.",
  metralleta:"Dispara três tiros de 60% da Magia contra o mesmo alvo. Recarga de 9 s.",
  shunko:"Golpeia com 140% do Ataque e ganha uma carga de esquiva contra um golpe de alvo único. Recarga de 12 s.",
  excalibur:"O corte de plasma causa 145% do Ataque e ignora 35% da Defesa do alvo. Recarga de 7 s.",

  piccolo:'Cria um escudo de 110% da Magia e pode interceptar um golpe contra um aliado próximo nos 4,5 s seguintes.',
  bulma:'Aplica um escudo de 200% da Magia ao aliado com a menor porcentagem de PV, quando ele tem 95% de PV ou menos.',
  heal:'Cura o aliado com a menor porcentagem de PV em 130% da Magia, quando ele tem 95% de PV ou menos.',
  yamcha:'Causa dano físico equivalente a 160% do Ataque.',
  kuririn:'Causa dano mágico equivalente a 165% da Magia ao inimigo com menos PV.',
  beam:'Causa dano mágico equivalente a 165% da Magia.',
  beerus:'Remove o escudo, causa dano mágico equivalente a 240% da Magia e bloqueia a ressurreição se o golpe for fatal.',
  accelerator:'Reflete até duas habilidades de alvo único por luta, com recarga de 8 s e alcance de um espaço na ordem da formação.',
};
SKILL_EFFECTS.ward=SKILL_EFFECTS.piccolo;
SKILL_EFFECTS.rush=SKILL_EFFECTS.yamcha;
const chanceByTier = [.55,.27,.12,.045,.012,.0025,.00045,.00005];
const passives={
  'Haki do Rei':'Ao iniciar a luta, trava as ações inimigas por 2 s. Durante esse período, os inimigos recebem 30% mais dano. Uma ativação por equipe.',
  'Instinto Superior':'Esquiva dos três primeiros golpes diretos de alvo único e contra-ataca o agressor se ele estiver em campo e o portador puder agir.',
  'Restrição Celestial':'Intercepta os dois primeiros golpes de alvo único contra aliados próximos e sofre metade do dano. Na Arena, pode proteger o titular da reserva.',
  'Haki da Observação':'Até duas vezes por luta, antecipa uma habilidade de alvo único com um golpe de 200% do dano básico. Eliminar o atacante cancela a habilidade.',
  'Zenkai':'Uma vez por luta, sobrevive a um golpe fatal com 40% dos PV máximos e ganha +75% de Ataque e Magia até o fim do combate.',
  'Full Counter':'Reflete a primeira habilidade mágica de alvo único que atingir o portador ou um aliado próximo. Devolve o dobro do dano-base da habilidade.',
  'The World':'Após a primeira habilidade principal bem-sucedida, para o tempo por 3 s. Só o portador pode agir e sua habilidade fica pronta outra vez.',
  'Voto de Nen':'Última Aposta é opcional. Ative na ficha para causar 4× o dano e ocupar duas vagas. Desative para voltar a usar uma vaga e conservar os bônus de atributos.',
  'Made in Heaven':'Causa 4× o dano durante toda a luta e ocupa uma vaga. Na primeira ação ofensiva, ativa Aceleração do Tempo por 5 s. O intervalo de ações cai 80% para o portador e 40% para aliados. A aceleração coletiva não acumula.'
};
const T=(name,odds,buffs)=>({name,odds,buffs,passive:passives[name]??null,
  rarity:TIERS[odds<=5?0:odds<=10?1:odds<=25?2:odds<=50?3:odds<=125?4:odds<=250?5:odds<=1000?6:7]});
const TRAITS = [T('Concentração Total',4,[.3,0,0,0,0,0]),T('Reforço Amaldiçoado',5,[0,.25,.25,0,0,0]),T('Haki do Armamento',10,[0,0,0,.4,0,0]),T('Ten',10,[0,0,0,0,.4,0]),T('Kaidō',20,[0,0,.35,0,.2,0]),T('Shunpo',20,[0,.2,0,0,0,.35]),T('Modo Sábio',25,[.35,0,0,.25,.25,0]),T('Respiração do Trovão',25,[0,.4,0,0,0,.25]),T('Haki do Rei',50,[.3,.5,.5,0,0,0]),T('Instinto Superior',100,[0,.4,.4,0,0,.5]),T('Restrição Celestial',125,[.6,0,0,.5,.5,0]),T('Haki da Observação',125,[0,.4,0,.4,0,0]),T('Zenkai',200,[.45,0,0,.35,0,0]),T('Full Counter',250,[0,0,0,.6,.6,0]),T('The World',500,[0,.6,.6,0,0,.4]),T('Voto de Nen',1000,[.6,0,0,.4,.4,0]),T('Made in Heaven',2000,[0,0,0,0,.5,0])];
const initial = ['piccolo','yamcha','kuririn','bulma'];
const position = [[72,47],[56,72],[39,28],[22,59]];
const HOUR = 3600000;
const UPGRADES = {
  ritmo:{name:'Ritmo de expedição',worlds:[1,2,4,6,8],costs:[120,1800,15000,80000,240000],values:[10,9,8,7,6,5],unit:' s',description:'Reduz a espera entre encontros.'},
  sorte:{name:'Sorte',worlds:[1,1,1,2,3,5,7,8,10],costs:[50,125,300,1000,3500,12000,36000,90000,200000],values:[10,20,30,40,50,60,70,80,90,100],unit:'%',description:'Chance de encontrar um personagem recrutável em uma luta comum. Vença para recrutá-lo.'},
  ouro:{name:'Bônus de ouro',worlds:[1,1,1,2,4,6,8],costs:[75,180,400,2000,18000,90000,250000],values:[0,10,20,30,35,40,45,50],unit:'%',description:'Acrescenta ouro às vitórias em encontros comuns e de elite.'},
  xp:{name:'Experiência compartilhada',worlds:[1,1,1,2,4,6,8],costs:[60,150,325,1600,14000,75000,210000],values:[0,25,40,60,70,80,90,100],unit:'%',description:'Distribui entre os reservas uma fração da XP que um titular recebe por vitória. Cada titular mantém sua recompensa integral.'},
  rastreio:{name:'Rastreio de raros',worlds:[1,2,4,6,9],costs:[100,600,4500,24000,100000],values:[18,20,24,28,32,36],unit:'%',description:'Chance de um recruta ser de raridade Rara ou superior. Cada uma dessas raridades recebe o mesmo aumento proporcional.'},
  treino:{name:'Treino de combate',worlds:[1,2,4,7],costs:[80,700,5000,30000],values:[0,10,20,30,40],unit:'%',description:'Aumenta a XP por vitória na campanha. O bônus também entra no cálculo da experiência compartilhada.'},
  enfermaria:{name:'Enfermaria',worlds:[1,3,5,8],costs:[90,1000,6500,45000],values:[20,18,16,14,12],unit:' s',description:'Reduz o tempo de recuperação de titulares derrotados na exploração, inclusive quando a equipe inteira cai.'},
};
const xpFor = level => 16 + level*5 + Math.round(.14*level**2);
const scale = level => 1 + .1*(level-1) + .001*(level-1)**2;
const thresholds=[0,0];
for(let level=1;level<100;level++)thresholds.push(thresholds[level]+xpFor(level));
const xpTo=level=>thresholds[level];
function levelAt(xp){
  let low=1,high=100;
  while(low<high){const mid=Math.ceil((low+high)/2);if(xp>=thresholds[mid])low=mid;else high=mid-1;}
  return low;
}
function xpProgress(xp,cap=100){
  const level=levelAt(xp);
  return {level,current:xp-xpTo(level),required:level<cap?xpFor(level):0};
}
const maxLevel = state=>Math.max(1,...state.team.map(id=>levelAt(state.collection.find(x=>x.uid===id).xp)));
const readyForBoss = state=>state.team.length>0 && state.finalWins>=12 && !state.completed;
const upgradeLevel = (state,id)=>state.upgrades?.[id]??(id==='ritmo'&&state.upgraded?1:0);
const upgradeValue = (state,id)=>UPGRADES[id].values[upgradeLevel(state,id)];
const waitFor = state=>upgradeValue(state,'ritmo')*1000;

function buyUpgrade(state,id){
  if(!Object.hasOwn(UPGRADES,id))return false;
  const level=upgradeLevel(state,id);
  const cost=UPGRADES[id].costs[level];
  if(cost===undefined||state.gold<cost||(state.unlocked??0)+1<UPGRADES[id].worlds[level])return false;
  state.gold-=cost;
  (state.upgrades??={})[id]=level+1;
  return true;
}

function fresh(now=Date.now(),seed=Date.now()>>>0){
  const collection = initial.map(id=>({uid:`initial-${id}`,id,xp:0,serial:1,shiny:false,trait:null,odds:null}));
  return {version:1,seed,created:now,collection,team:collection.map(x=>x.uid),positions:Object.fromEntries(collection.map((x,i)=>[x.uid,position[i]])),leader:collection[0].uid,area:0,gold:0,wins:0,losses:0,finalWins:0,streak:0,upgrades:{},completed:false,world:0,unlocked:0,journey:{},autoRoutes:true,paused:false,running:true,nextAt:now,waitDuration:0,pending:null,index:0,clock:now,log:[]};
}

const starterBonus = {piccolo:[.05,0,0,.05,0,0],yamcha:[0,.05,0,0,0,.05],kuririn:[0,0,.05,0,0,0],bulma:[0,0,0,0,.05,0]};
function leaderBuff(leader,member){
  if(!leader) return [];
  if(leader.id==='piccolo') return leader.universe===member.universe?[0,0,0,.12,.12]:[];
  if(leader.id==='yamcha') return member.role==='Combatente'?[0,.08]:[];
  const roleMatch = {broly:'Combatente',beerus:'Mágico'};
  const eligible = roleMatch[leader.id] ? member.role===roleMatch[leader.id] : leader.id==='goku' ? member.universe===leader.universe : member.color===leader.color;
  if(!eligible) return [];
  const amount = [.08,.10,.10,.12,.15,.15,.18,.22][leader.tier-1];
  if(leader.id==='gohan') return [0,.10];
  if(leader.id==='law') return [.12];
  if(['tenshinhan','rocklee'].includes(leader.id)) return [0,0,0,0,0,amount];
  if(leader.id==='android17') return [0,0,0,amount];
  if(leader.id==='accelerator') return [0,0,0,0,amount];
  if(leader.role==='Mágico') return [0,0,amount];
  if(leader.role==='Combatente') return [0,amount];
  return [amount];
}

function fighter(unit, coords=[55,50], leader=null, tactical=false){
  const card=CHARACTERS[unit.id];
  const level=levelAt(unit.xp);
  const growth=scale(level);
  const trait=TRAITS.find(t=>t.name===unit.trait);
  const [hp,attack,magic,defense,resistance,speed]=baseStats[card.tier-1].map((base,i)=>Math.round(Math.round(baseStats[0][i]+.7*(base-baseStats[0][i]))*(1+roles[card.role][i])*(1+(starterBonus[card.id]?.[i]||0))*(1+(trait?.buffs[i]||0))*(1+(leaderBuff(leader,card)[i]||0))*(i===5?1:growth*(unit.shiny?1.25:1))));
  const [x,y]=coords;
  return {...card, uid:unit.uid,trait:unit.trait,nen:unit.trait==="Voto de Nen"&&unit.nen===true, level, x,y,hp,attack,magic,defense,resistance,speed,scale:growth,interval:tactical?Math.max(600,Math.round(300000/speed/100)*100):3000,magicBasic:card.role==='Mágico'||card.role==='Suporte',evade:unit.trait==='Instinto Superior'?3:0,survive:unit.trait==='Zenkai'?1:0,sprite:spriteFor(unit)};
}

function rng(seed,index){
  let state=(seed^Math.imul(index+1,2654435761))>>>0 || 1;
  return ()=>{state^=state<<13;state^=state>>>17;state^=state<<5;return (state>>>0)/4294967296;};
}
function pickTrait(random){
  let p=random();for(const t of TRAITS){p-=1/t.odds;if(p<0)return t;}return null;
}
function recruitWeights(rarePercent){
  const base=UPGRADES.rastreio.values[0];
  if(rarePercent===base)return chanceByTier;
  // Transfer probability from common units to rare and higher tiers, preserving their relative odds.
  return chanceByTier.map((weight,i)=>{
    if(i===0)return weight-(rarePercent-base)/100;
    return i===1?weight:weight*rarePercent/base;
  });
}
function rollRecruit(random,chance=.10,universe='Dragon Ball',rarePercent=UPGRADES.rastreio.values[0]){
  if(random()>=chance) return null;
  let p=random(),tier=1;
  const weights=recruitWeights(rarePercent);
  for(const weight of weights){if(p<weight)break;p-=weight;tier++;}
  tier=Math.min(tier,8);
  const candidates=Object.values(CHARACTERS).filter(c=>c.tier===tier);
  const local=candidates.filter(c=>c.universe===universe);
  const others=candidates.filter(c=>c.universe!==universe);
  const group = !local.length ? others : !others.length || random()<.6 ? local : others;
  const groupP=local.length&&others.length?(group===local?.6:.4):1;
  const card=group[Math.floor(random()*group.length)];
  const shinyP=tier>=7?.1:.05;
  const shiny=random()<shinyP;
  const trait=pickTrait(random);
  const traitP=trait?1/trait.odds:1-TRAITS.reduce((sum,t)=>sum+1/t.odds,0);
  return {id:card.id,shiny,trait:trait?.name??null,odds:Math.round(1/(chance*weights[tier-1]*groupP/group.length*(shiny?shinyP:1-shinyP)*traitP))};
}

const SALE_PRICES=[8,20,50,125,350,1000,3500,12000];
const RECOVERY_MS=20000;
function readyAt(state,uid){
  return Math.max(state.partyRecovery??0,state.recovery?.[uid]??0);
}
function firstReady(state){
  return Math.min(...state.team.map(uid=>readyAt(state,uid)));
}

function makeBattle(state,start,boss=false){
  const random=rng(state.seed,state.index++);
  const world=worldOf(state);
  const area=world.areas[state.area];
  const elite=!boss&&state.area===2&&state.index%7===0;
  const special=boss?world.boss:elite?world.elite:null;
  const leader=state.collection.find(c=>c.uid===state.leader);
  const available=state.team.filter(uid=>readyAt(state,uid)<=start);
  const team=available.map(uid=>fighter(state.collection.find(c=>c.uid===uid),state.positions[uid],available.includes(leader?.uid)?CHARACTERS[leader.id]:null,!!special));
  const level=special?special.level:Math.max(area.levels[0],Math.min(area.levels[1],maxLevel(state)+Math.floor(random()*3)-1));
  const recruit=special?null:rollRecruit(random,upgradeValue(state,'sorte')/100,world.universe,upgradeValue(state,'rastreio'));
  const grow=scale(level);
  const [hp,power,def,res]=(special?.base??area.base).map(x=>Math.round(x*grow));
  const baseEnemy={name:special?.name??area.enemy,hp,attack:power,magic:boss?Math.round(power*.88):power,defense:def,resistance:res,scale:grow,color:boss?world.boss.color:area.color,level,sprite:`enemy-${(state.world??0)+1}-${boss?5:elite?4:state.area+1}`,interval:boss?3200:3000,kind:boss?world.boss.kind:null,x:60,y:50};
  const candidate = recruit ? fighter({...recruit,xp:xpTo(level)},[60,50],null,false) : null;
  const enemy = candidate ? {...baseEnemy,name:candidate.name,sprite:candidate.sprite,trait:candidate.trait,color:candidate.color,kind:candidate.kind, hp:Math.max(hp,Math.round(candidate.hp*1.65)),attack:Math.max(power,candidate.attack),magic:Math.max(power,candidate.magic),magicBasic:candidate.magicBasic,defense:Math.max(def,candidate.defense),resistance:Math.max(res,candidate.resistance),evade:candidate.evade,survive:candidate.survive} : baseEnemy;
  const damageBoost=boss?1.30:elite?1.45:1.55;
  enemy.attack=Math.round(enemy.attack*damageBoost);
  enemy.magic=Math.round(enemy.magic*damageBoost);
  const result=new Combate([team,[enemy]],{mode:'equipe'}).run();
  const simulatedTime=result.seconds*1000;
  const duration=Math.max(1200,Math.min(boss?16000:6000,simulatedTime/(boss?2:4)));
  const reserveShare=upgradeValue(state,'xp')/100;
  const reserves=reserveShare?state.collection.filter(unit=>!state.team.includes(unit.uid)&&unit.xp<xpTo(levelCap(state))).map(unit=>unit.uid):[];
  return {start,end:start+duration,boss,elite,world:state.world??0,area:state.area,level,team,enemy,recruit,result,
    goldReward:Math.round((6+2*level)*1.2*(boss?8:(elite?2:1)*(1+upgradeValue(state,'ouro')/100))),
    xpBonus:upgradeValue(state,'treino')/100,recoveryMs:upgradeValue(state,'enfermaria')*1000,reserveShare,reserves};
}

function shareExperience(state,battle,xp){
  let available=Math.floor(xp*(battle.reserveShare??0));
  if(!available||!battle.reserves?.length)return 0;
  const maxXp=xpTo(levelCap(state));
  const reserves=new Set(battle.reserves);
  const eligible=state.collection.filter(unit=>reserves.has(unit.uid)&&unit.xp<maxXp).sort((a,b)=>b.xp-a.xp);
  let granted=0;
  for(const [index,unit] of eligible.entries()){
    const amount=Math.min(maxXp-unit.xp,Math.floor(available/(eligible.length-index)));
    unit.xp+=amount;
    available-=amount;
    granted+=amount;
  }
  return granted;
}

function saleSettings(saved){
  // Older backups can contain only the filters that were configured.
  const list=value=>Array.isArray(value)?value:[];
  const tiers=list(saved?.tiers).map(Number).filter(i=>Number.isInteger(i)&&i>=1&&i<=TIERS.length);
  const characters=list(saved?.characters).filter(id=>Object.hasOwn(CHARACTERS,id));
  const traitRules={};
  for(const [tier,rule] of Object.entries(saved?.traitRules??{})){
    if(!TIERS[Number(tier)-1]||!rule)continue;
    const below=Number(rule.below);
    traitRules[tier]={
      below:Number.isInteger(below)&&below>=0&&below<=1000000?below:0,
      names:list(rule.names).filter(name=>TRAITS.some(t=>t.name===name))
    };
  }
  return {enabled:saved?.enabled===true,tiers:[...new Set(tiers)],characters:[...new Set(characters)],traitRules};
}

function saleMatches(settings,unit){
  const tier=CHARACTERS[unit.id].tier;
  if(!settings?.enabled||!(settings.tiers?.includes(tier)||settings.characters?.includes(unit.id)))return false;
  if(!unit.trait)return true;
  const rule=settings.traitRules?.[tier];
  const trait=TRAITS.find(t=>t.name===unit.trait);
  return !!(trait&&rule&&(trait.odds<rule.below||rule.names?.includes(trait.name)));
}

function settle(state,battle){
  const entry={won:battle.result.winner===0&&battle.result.reason==='eliminação',gold:0,xp:0,reserveXp:0,teamXp:0,recruit:null,boss:battle.boss,label:battle.enemy.name,end:battle.end};
  const fallen=battle.result.events.filter(e=>e.type==='cai'&&e.actor.startsWith('0:'));
  if(fallen.length){
    state.recovery??={};
    for(const e of fallen){
      const unit=battle.team[Number(e.actor.slice(2))];
      const when=battle.start+(battle.end-battle.start)*Math.min(1,e.time/Math.max(1,battle.result.seconds*1000));
      state.recovery[unit.uid]=Math.ceil(when)+(battle.recoveryMs??RECOVERY_MS);
    }
    if(fallen.length===battle.team.length)state.partyRecovery=battle.end+(battle.recoveryMs??RECOVERY_MS);
  }
  if(entry.won){
    state.wins++;state.streak=0;
    if(battle.area===2&&!battle.boss) state.finalWins++;
    entry.xp=Math.round((8+2*battle.level)*(battle.boss?3:battle.elite?2:1)*(1+(battle.xpBonus??0)));
    entry.gold=battle.goldReward??Math.round((6+2*battle.level)*(battle.boss?8:(battle.elite?2:1)*(1+(battle.goldBonus??0))));
    state.gold+=entry.gold;
    for(const fighter of battle.team){const copy=state.collection.find(c=>c.uid===fighter.uid);if(copy){const previous=copy.xp;copy.xp=Math.min(xpTo(levelCap(state)),previous+entry.xp);entry.teamXp+=copy.xp-previous;}}
    entry.reserveXp=shareExperience(state,battle,entry.xp);
    if(battle.recruit){
      const {id,shiny}=battle.recruit;
      const key=id+(shiny?'-shiny':'');
      const serial=1+(state.serials?.[key]??state.collection.reduce((max,c)=>c.id===id&&!!c.shiny===!!shiny?Math.max(max,c.serial):max,0));
      (state.serials??={})[key]=serial;
      const copy={...battle.recruit,uid:`catch-${state.index}`,xp:xpTo(Math.min(levelCap(state),battle.level)),serial};
      const settings=state.autoSell,tier=CHARACTERS[id].tier;
      const match=saleMatches(settings,copy);
      if(match&&state.collection.some(c=>c.id===id&&!!c.shiny===!!shiny)){
        entry.sold=copy;entry.saleGold=SALE_PRICES[tier-1];entry.gold+=entry.saleGold;state.gold+=entry.saleGold;
      }else{state.collection.push(copy);entry.recruit=copy;}
    }
    if(battle.boss){
      state.completed=true;
      state.unlocked=Math.min(WORLDS.length-1,Math.max(state.unlocked??0,(state.world??0)+1));
    }
    if(state.autoRoutes){
      const areas=worldOf(state).areas;
      state.area=Math.max(state.area,areas.findLastIndex(a=>a.unlock<=maxLevel(state)));
    }
  }else{
    state.losses++;
    if(!battle.boss && ++state.streak>=3){if(state.area>0)state.area--;state.streak=0;}
  }
  state.log=[entry,...state.log].slice(0,25);
  return entry;
}

function advance(state,now){
  if(state.autoSell)state.autoSell=saleSettings(state.autoSell);
  if(state.world===undefined){
    state.world=0;state.unlocked=state.completed?1:0;state.journey={};state.autoRoutes=true;
    state.paused=false;
    if(!state.running&&!state.pending)state.nextAt=now;
    state.running=true;
  }
  const previous=state.clock;
  if(now<previous) return [];
  const cap=Math.min(now,previous+12*HOUR);
  const entries=[];
  while(true){
    if(state.pending){
      if(state.pending.end>cap) break;
      const battle=state.pending;
      state.pending=null;
      entries.push(settle(state,battle));
      state.waitDuration=waitFor(state);
      state.nextAt=battle.end+state.waitDuration;
      state.running=!state.paused;
      if(state.destination!==undefined)travel(state,state.destination);
      else if(state.autoRoutes && state.running && battle.boss && state.completed && state.world<state.unlocked)travel(state,state.world+1);
      continue;
    }
    if(!state.team.length||!state.running||state.nextAt>cap) break;
    const start=Math.max(state.nextAt,firstReady(state));
    if(start>cap)break;
    if(state.autoRoutes && state.completed && state.world<state.unlocked)travel(state,state.world+1);
    state.pending=makeBattle(state,start,!!state.autoRoutes && readyForBoss(state));
  }
  if(now>cap){
    if(state.pending){
      // Preserve the fight and the remaining replay when the AFK window ends mid-battle.
      state.pending.start+=now-cap;
      state.pending.end+=now-cap;
    }
    state.running=!state.paused;
    state.nextAt=now+waitFor(state);
  }
  state.clock=now;
  return entries;
}

const AWAY_THRESHOLD=10*60*1000;
function newWindow(state,start){
  return {start,encounters:0,wins:0,gold:0,teamXp:0,reserveXp:0,firstRecruit:state.collection.length,recruitUids:[]};
}
function hydrateAwayRecruits(state){
  if(state.awayWindow&&!Array.isArray(state.awayWindow.recruitUids)){
    const start=Number.isInteger(state.awayWindow.firstRecruit)?Math.max(0,state.awayWindow.firstRecruit):state.collection.length;
    state.awayWindow.recruitUids=state.collection.slice(start).map(u=>u.uid);
  }
  if(Array.isArray(state.awayReports)){
    for(const r of state.awayReports){
      if(r&&!Array.isArray(r.recruitUids)){
        const start=Number.isInteger(r.firstRecruit)?Math.max(0,r.firstRecruit):state.collection.length;
        const end=Number.isInteger(r.lastRecruit)?Math.max(start,r.lastRecruit):start;
        r.recruitUids=state.collection.slice(start,end).map(u=>u.uid);
      }
    }
  }
}
function advanceWithPresence(state,now,observedAt=null){
  hydrateAwayRecruits(state);
  const window=state.awayWindow??=newWindow(state,state.clock);
  const all=[];
  function run(until){
    const w=state.awayWindow;
    const limit=w.start+12*HOUR;
    if(until>=state.clock&&state.clock<=limit){
      const entries=advance(state,Math.min(until,limit));
      for(const e of entries){
        if(e.sold){w.sold=(w.sold??0)+1;w.saleGold=(w.saleGold??0)+e.saleGold;}
        if(e.recruit?.uid)(w.recruitUids??=[]).push(e.recruit.uid);
        w.encounters++;w.wins+=Number(e.won);w.gold+=e.gold;w.teamXp+=e.teamXp;w.reserveXp+=e.reserveXp;all.push(e);
      }
    }
    if(until>limit&&until>state.clock){
      const shift=until-state.clock;
      if(state.pending){state.pending.start+=shift;state.pending.end+=shift;}
      state.nextAt+=shift;state.clock=until;
    }
  }
  if(Number.isFinite(observedAt)&&observedAt>window.start){
    const seen=Math.min(now,observedAt);
    run(seen);
    if(seen-window.start>=AWAY_THRESHOLD){
      (state.awayReports??=[]).push({...window,recruitUids:[...(window.recruitUids??[])],end:seen,lastRecruit:state.collection.length});
    }
    state.awayWindow=newWindow(state,seen);
  }
  run(now);
  return all;
}

function startExploration(state,now){
  if(state.pending?.boss||state.running)return false;
  state.running=true;
  if(!state.pending)state.nextAt=Math.max(now,state.nextAt);
  return true;
}

function challenge(state,now){
  if(!readyForBoss(state))return false;
  if(state.pending||firstReady(state)>now)return false;
  state.pending=makeBattle(state,now,true);
  return true;
}

function formationSlots(state){
  return state.slots??Array.from({length:4},(_,i)=>state.team[i]??null);
}

function formationCost(state,slots=state.team){
  return slots.reduce((n,uid)=>n+(uid?(state.collection.find(u=>u.uid===uid)?.nen?2:1):0),0);
}
function equip(state,uid,replaced,requestedSlot){
  if(!state.collection.some(c=>c.uid===uid)||state.team.includes(uid))return false;
  const slots=formationSlots(state).slice();
  const index=requestedSlot??(replaced?slots.indexOf(replaced):slots.indexOf(null));
  if(!Number.isInteger(index)||index<0||index>=4||slots[index]!== (replaced??null))return false;
  const next=slots.slice();next[index]=uid;
  if(formationCost(state,next)>4)return false;
  state.positions[uid]=(state.positions[replaced]??state.slotPositions?.[index]??position[index]).slice();
  if(!state.leader||state.leader===replaced)state.leader=uid;
  slots[index]=uid;
  state.slots=slots;state.team=slots.filter(Boolean);
  return true;
}

function removeMember(state,uid){
  const slots=formationSlots(state).slice(),index=slots.indexOf(uid);
  if(!uid||index<0)return false;
  state.slotPositions??={};
  state.slotPositions[index]=state.positions[uid];
  slots[index]=null;
  state.slots=slots;state.team=slots.filter(Boolean);
  if(state.leader===uid)state.leader=state.team[0]??null;
  return true;
}

function travel(state,index){
  state.journey[state.world]={area:state.area,completed:state.completed,finalWins:state.finalWins};
  const progress=state.journey[index]??{area:0,completed:false,finalWins:0};
  Object.assign(state,progress,{world:index,streak:0});
  delete state.destination;
}
const STAT_KEYS=['hp','attack','magic','defense','resistance','speed'];
function unitPower(unit, leader=null){
  const stats=fighter(unit,undefined,leader);
  return STAT_KEYS.reduce((sum,key)=>sum+stats[key],0);
}
function projectedPower(unit,leader=null){
  return unitPower({...unit,xp:xpTo(100)},leader);
}
function leaderApplies(leader, member){
  return leaderBuff(leader,member).some(Boolean);
}

const ROLE_ORDER={Guardião:0,Combatente:1,Mágico:2,Suporte:3};
const PRESET_COORDS={
  padrao:[[74,44],[56,76],[36,26],[22,60]],
  espalhado:[[82,20],[62,82],[24,20],[20,82]],
  proteger:[[72,50],[46,42],[46,58],[58,24]],
};
function applyFormationPreset(state, preset='padrao'){
  const coords=PRESET_COORDS[preset];
  if(!coords||!state.team.length)return false;
  const ordered=state.team.slice().sort((a,b)=>{
    const ca=CHARACTERS[state.collection.find(u=>u.uid===a).id];
    const cb=CHARACTERS[state.collection.find(u=>u.uid===b).id];
    return (ROLE_ORDER[ca.role]??9)-(ROLE_ORDER[cb.role]??9);
  });
  ordered.forEach((uid,i)=>{state.positions[uid]=coords[i].slice();});
  return true;
}

function autoFormation(state, mode='power', now=Date.now()){
  if(!['power','balanced','area'].includes(mode)||!state.collection.length)return false;
  const enemyColor=worldOf(state).areas[state.area]?.color;
  const unitCost=u=>u.nen?2:1;
  const areaFactor=c=>mode==='area'&&enemyColor?affinity(c.color,enemyColor)/Math.sqrt(affinity(enemyColor,c.color)):1;
  const scoreWith=(u,leaderCard)=>projectedPower(u,leaderCard)*areaFactor(CHARACTERS[u.id]);
  const cmp=(a,b)=>b.score-a.score||b.u.xp-a.u.xp||b.tier-a.tier||a.u.serial-b.u.serial;
  // Best representative per (character.id, cost) as candidate leader.
  const leaderMap=new Map();
  for(const u of state.collection){
    const c=CHARACTERS[u.id],cost=unitCost(u),key=`${u.id}:${cost}`;
    const item={u,cost,score:scoreWith(u,c),role:c.role,tier:c.tier};
    const prev=leaderMap.get(key);
    if(!prev||cmp(item,prev)<0)leaderMap.set(key,item);
  }
  let best=null;
  for(const lead of leaderMap.values()){
    const leaderCard=CHARACTERS[lead.u.id];
    const rem=4-lead.cost;
    const others=[];
    for(const u of state.collection){
      if(u.uid===lead.u.uid)continue;
      const cost=unitCost(u);
      if(cost>rem)continue;
      const c=CHARACTERS[u.id];
      others.push({u,cost,score:scoreWith(u,leaderCard),role:c.role,tier:c.tier});
    }
    others.sort(cmp);
    let combo=[lead];
    if(mode==='balanced'){
      const buildBalanced=pool=>{
        let budget=rem;
        const cand=[lead];
        const rolesUsed=new Set([lead.role]);
        const picked=new Set([lead.u.uid]);
        for(const role of ['Guardião','Combatente','Mágico','Suporte']){
          if(rolesUsed.has(role))continue;
          const match=pool.find(x=>x.role===role&&!picked.has(x.u.uid)&&x.cost<=budget);
          if(match){cand.push(match);picked.add(match.u.uid);rolesUsed.add(role);budget-=match.cost;}
        }
        for(const x of pool){
          if(budget<=0)break;
          if(!picked.has(x.u.uid)&&x.cost<=budget){cand.push(x);picked.add(x.u.uid);budget-=x.cost;}
        }
        return {cand,roles:rolesUsed.size,score:cand.reduce((s,x)=>s+x.score,0)};
      };
      const withAny=buildBalanced(others);
      const singlesOnly=buildBalanced(others.filter(x=>x.cost===1));
      combo=singlesOnly.roles>withAny.roles||(singlesOnly.roles===withAny.roles&&singlesOnly.score>withAny.score+1e-9)?singlesOnly.cand:withAny.cand;
    }else{
      const singles=others.filter(x=>x.cost===1).slice(0,rem);
      const doubles=others.filter(x=>x.cost===2).slice(0,Math.floor(rem/2));
      let bestSub=-1;
      for(let d=0;d<=doubles.length;d++){
        const candidate=[lead,...doubles.slice(0,d),...singles.slice(0,rem-d*2)];
        const total=candidate.reduce((s,x)=>s+x.score,0);
        if(total>bestSub){bestSub=total;combo=candidate;}
      }
    }
    const score=combo.reduce((s,x)=>s+x.score,0);
    const roles=mode==='balanced'?new Set(combo.map(x=>x.role)).size:0;
    if(!best||roles>best.roles||(roles===best.roles&&score>best.score+1e-9)){
      best={combo,lead:lead.u,score,roles};
    }
  }
  if(!best)return false;
  best.combo.sort((a,b)=>(ROLE_ORDER[a.role]??9)-(ROLE_ORDER[b.role]??9)||b.score-a.score);
  const units=best.combo.map(x=>x.u);
  const wasEmpty=!state.team.length;
  const slots=Array.from({length:4},(_,i)=>units[i]?.uid??null);
  state.slots=slots;
  state.team=slots.filter(Boolean);
  state.leader=best.lead.uid;
  applyFormationPreset(state,'padrao');
  if(wasEmpty&&!state.pending)state.nextAt=now;
  return true;
}

function canSellUnit(state, uid){
  if(!uid||state.collection.length<=1||state.team.includes(uid))return false;
  return state.collection.some(u=>u.uid===uid);
}
function sellUnit(state, uid){
  if(!canSellUnit(state,uid))return false;
  hydrateAwayRecruits(state);
  const index=state.collection.findIndex(u=>u.uid===uid);
  const [unit]=state.collection.splice(index,1);
  const gold=SALE_PRICES[CHARACTERS[unit.id].tier-1]??0;
  state.gold+=gold;
  delete state.positions?.[uid];
  if(state.recovery)delete state.recovery[uid];
  if(state.awayWindow&&index<state.awayWindow.firstRecruit)state.awayWindow.firstRecruit--;
  if(Array.isArray(state.awayReports)){
    for(const r of state.awayReports){
      if(index<r.firstRecruit)r.firstRecruit--;
      if(index<r.lastRecruit)r.lastRecruit--;
    }
  }
  return gold;
}

function applyGameAction(state,action,now){
  switch(action?.type){
    case 'nen': {
      const u=state.collection.find(c=>c.uid===action.uid);
      if(u?.trait!=='Voto de Nen'||typeof action.enabled!=='boolean')return false;
      if(action.enabled&&!u.nen&&state.team.includes(u.uid)&&formationCost(state)>=4)return false;
      u.nen=action.enabled;return true;
    }
    case 'saleTrait': {
      const {tier,name,below,checked}=action;
      if(!Number.isInteger(tier)||tier<1||tier>TIERS.length)return false;
      const named=name!==undefined;
      if(named&&(!TRAITS.some(t=>t.name===name)||typeof checked!=='boolean'))return false;
      if(!named&&(!Number.isInteger(below)||below<0||below>1000000))return false;
      const settings=state.autoSell=saleSettings(state.autoSell);
      const rules=settings.traitRules??={};
      const rule=rules[tier]??={below:0,names:[]};
      if(!named)rule.below=below;
      else if(checked){if(!rule.names.includes(name))rule.names.push(name);}
      else rule.names=rule.names.filter(n=>n!==name);
      return true;
    }
    case 'saleSetting': {
      const {group,value,checked}=action;
      if(typeof checked!=='boolean'||!['enabled','tiers','characters'].includes(group))return false;
      if(group==='tiers'&&(!Number.isInteger(value)||value<1||value>TIERS.length))return false;
      if(group==='characters'&&!Object.hasOwn(CHARACTERS,value))return false;
      const settings=state.autoSell=saleSettings(state.autoSell);
      if(group==='enabled')settings.enabled=checked;
      else settings[group]=checked?[...new Set([...settings[group],value])]:settings[group].filter(v=>v!==value);
      return true;
    }
    case 'dismissAway': {
      if(!state.awayReports?.length||state.awayReports[0].end!==action.end)return false;
      state.awayReports.shift();return true;
    }
    case 'pause':
      state.running=false;state.paused=true;return true;
    case 'resume': {
      const wasPaused=Boolean(state.paused);
      state.paused=false;
      return startExploration(state,now)||wasPaused;
    }
    case 'autoRoutes':
      state.autoRoutes=action.enabled===true;return true;
    case 'world':
      if(!Number.isInteger(action.index)||action.index<0||action.index>state.unlocked)return false;
      state.autoRoutes=false;
      if(state.pending)state.destination=action.index;else travel(state,action.index);
      return true;
    case 'area': {
      const area=Number.isInteger(action.area)&&worldOf(state).areas[action.area];
      if(!area||maxLevel(state)<area.unlock||(!state.autoRoutes&&state.area===action.area))return false;
      state.autoRoutes=false;state.area=action.area;state.streak=0;return true;
    }
    case 'leader':
      if(!state.team.includes(action.uid)||state.leader===action.uid)return false;
      state.leader=action.uid;return true;
    case 'remove': return removeMember(state,action.uid);
    case 'equip': {
      const empty=!state.team.length;
      const changed=equip(state,action.uid,action.replaced,action.slot);
      if(changed&&empty&&!state.pending)state.nextAt=now;
      return changed;
    }
    case 'boss': return challenge(state,now);
    case 'upgrade': return buyUpgrade(state,action.id);
    case 'position': {
      if(!state.team.includes(action.uid))return false;
      const coords=action.coords;
      if(!Array.isArray(coords)||coords.length!==2||!coords.every(Number.isFinite))return false;
      state.positions[action.uid]=coords.map(value=>Math.max(8,Math.min(92,Math.round(value))));
      return true;
    }
    case 'autoFormation': return autoFormation(state,action.mode??'power',now);
    case 'formationPreset': return applyFormationPreset(state,action.preset);
    case 'sell': return sellUnit(state,action.uid)!==false;
    default: return false;
  }
}

return {AREAS,BOSS,WORLDS,worldOf,levelCap,COLORS,TIERS,spriteFor,CHARACTERS,SKILL_EFFECTS,TRAITS,UPGRADES,xpFor,levelAt,xpProgress,maxLevel,readyForBoss,upgradeLevel,waitFor,buyUpgrade,fresh,fighter,rollRecruit,SALE_PRICES,RECOVERY_MS,readyAt,makeBattle,saleSettings,advance,AWAY_THRESHOLD,advanceWithPresence,startExploration,challenge,formationSlots,formationCost,equip,unitPower,projectedPower,leaderApplies,applyFormationPreset,autoFormation,canSellUnit,sellUnit,applyGameAction};
})();
const communityRules=(()=>{

// A daily period is keyed by the local calendar date on which its noon began.
const DAILY_ZONE='America/Sao_Paulo';
const GIFT_GOLD=10;
const PROFILE_OPTIONS={
  background:{namek:'Namek · Dragon Ball',arlong:'Arlong Park · One Piece',konoha:'Konoha · Naruto',
    seireitei:'Seireitei · Bleach',shibuya:'Shibuya · Jujutsu Kaisen',clover:'Reino Clover · Black Clover',
    britannia:'Britannia · Nanatsu no Taizai',morioh:'Morioh · JoJo',heavens:'Heavens Arena · Hunter × Hunter',
    cidadez:'Cidade Z · One Punch Man',noite:'Noite violeta',aurora:'Aurora turquesa'},
  icon:{estrela:'Estrela',cometa:'Cometa',escudo:'Escudo'},
  border:{menta:'Menta',violeta:'Violeta',ouro:'Ouro'},
};
const DEFAULT_PROFILE={background:'namek',icon:'estrela',border:'menta'};
const PROFILE_WORLDS={namek:0,arlong:1,konoha:2,seireitei:3,shibuya:4,clover:5,britannia:6,morioh:7,heavens:8,cidadez:9};
const AVATAR_SIZE=128;
const PROFILE_BODY_LIMIT=100*1024;

// The browser sends only its square canvas export, never a remote image URL.
function validAvatar(value){
  const prefix='data:image/png;base64,';
  if(typeof value!=='string'||value.length>98000||!value.startsWith(prefix))return false;
  const encoded=value.slice(prefix.length);
  if(encoded.length%4!==0||!/^[A-Za-z0-9+/]+={0,2}$/.test(encoded))return false;
  const bytes=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0));
  const signature=[137,80,78,71,13,10,26,10];
  if(bytes.length<57||!signature.every((b,i)=>bytes[i]===b))return false;
  const view=new DataView(bytes.buffer);
  let hasData=false;
  for(let pos=8;pos+12<=bytes.length;){
    const length=view.getUint32(pos);
    const kind=String.fromCharCode(...bytes.subarray(pos+4,pos+8));
    const end=pos+12+length;
    if(end>bytes.length)return false;
    if(pos===8){
      if(kind!=='IHDR'||length!==13||view.getUint32(16)!==AVATAR_SIZE||view.getUint32(20)!==AVATAR_SIZE||
          bytes[24]!==8||![2,6].includes(bytes[25])||bytes[26]||bytes[27]||bytes[28])return false;
    }else if(kind==='IDAT')hasData ||= length>0;
    else if(kind==='IEND')return hasData&&length===0&&end===bytes.length;
    else if(!['sRGB','pHYs','cHRM','gAMA','iCCP','sBIT','cICP'].includes(kind))return false;
    pos=end;
  }
  return false;
}
function appearancePatch(input){
  const patch={};
  for(const key of Object.keys(DEFAULT_PROFILE)){
    if(typeof input?.[key]!=='string'||!Object.hasOwn(PROFILE_OPTIONS[key],input[key]))throw Error('Escolha as opções de aparência do perfil.');
    patch[key]=input[key];
  }
  if(Object.hasOwn(input,'avatar')){
    if(input.avatar!==null&&!validAvatar(input.avatar))throw Error('A foto precisa ser uma imagem válida. Escolha o arquivo novamente.');
    patch.avatar=input.avatar;
  }
  return patch;
}
const localParts=new Intl.DateTimeFormat('en-GB',{
  timeZone:DAILY_ZONE,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',
  minute:'2-digit',second:'2-digit',hourCycle:'h23',
});
function localFields(time){
  return Object.fromEntries(localParts.formatToParts(time).filter(p=>p.type!=='literal').map(p=>[p.type,Number(p.value)]));
}
function localNoon(plainDate){
  const desired=plainDate+12*3600000;
  let time=desired;
  for(let attempt=0;attempt<3;attempt++){
    const f=localFields(time);
    const actual=Date.UTC(f.year,f.month-1,f.day,f.hour,f.minute,f.second);
    if(actual===desired)return time;
    time+=desired-actual;
  }
  return time;
}
function dailyCycle(now=Date.now()){
  const f=localFields(now);
  const today=Date.UTC(f.year,f.month-1,f.day);
  const startDate=today-(f.hour<12?86400000:0);
  return {day:new Date(startDate).toISOString().slice(0,10),nextAt:localNoon(startDate+86400000)};
}

function rarityLabel(odds){
  const format=new Intl.NumberFormat('pt-BR',{maximumFractionDigits:2});
  for(const [divisor,suffix] of [[1e9,'B'],[1e6,'M'],[1e3,' mil']]){
    if(odds>=divisor)return '1/'+format.format(odds/divisor)+suffix;
  }
  return '1/'+format.format(odds);
}

return {DAILY_ZONE,GIFT_GOLD,PROFILE_OPTIONS,DEFAULT_PROFILE,PROFILE_WORLDS,AVATAR_SIZE,PROFILE_BODY_LIMIT,appearancePatch,dailyCycle,rarityLabel};
})();
const {serialSchema,issueSerials} =serials;
const {advance,advanceWithPresence,applyGameAction,fighter,fresh,CHARACTERS} =game;
const {dailyCycle,DEFAULT_PROFILE,appearancePatch,PROFILE_BODY_LIMIT,GIFT_GOLD} =communityRules;

class ApiError extends Error {
  constructor(status,message){super(message);this.status=status;}
}
function reject(status,message){throw new ApiError(status,message);}
const schemas=[
  `CREATE TABLE IF NOT EXISTS nexus_players(
    id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, token_hash TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL, game TEXT NOT NULL, appearance TEXT NOT NULL,
    revision INTEGER NOT NULL DEFAULT 0, play_ms INTEGER NOT NULL DEFAULT 0, last_seen INTEGER,
    reg_key TEXT NOT NULL, power INTEGER NOT NULL, top_units TEXT NOT NULL, rare_units TEXT NOT NULL)`,
  'CREATE INDEX IF NOT EXISTS nexus_registration ON nexus_players(reg_key)',
  'CREATE INDEX IF NOT EXISTS nexus_power ON nexus_players(power DESC,name,id)',
  `CREATE TABLE IF NOT EXISTS nexus_friends(
    a TEXT NOT NULL REFERENCES nexus_players(id), b TEXT NOT NULL REFERENCES nexus_players(id),
    requested_by TEXT NOT NULL REFERENCES nexus_players(id), accepted INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(a,b),CHECK(a<b))`,
  'CREATE INDEX IF NOT EXISTS nexus_friends_b ON nexus_friends(b)',
  `CREATE TABLE IF NOT EXISTS nexus_gifts(
    sender TEXT NOT NULL REFERENCES nexus_players(id), recipient TEXT NOT NULL REFERENCES nexus_players(id),
    day TEXT NOT NULL, gold INTEGER NOT NULL, sent_at INTEGER NOT NULL,PRIMARY KEY(sender,recipient,day))`,
  'CREATE INDEX IF NOT EXISTS nexus_inbox ON nexus_gifts(recipient,sent_at DESC)',
  `CREATE TRIGGER IF NOT EXISTS nexus_gift_credit AFTER INSERT ON nexus_gifts BEGIN
    UPDATE nexus_players SET game=json_set(game,'$.gold',json_extract(game,'$.gold')+NEW.gold),
      revision=revision+1 WHERE id=NEW.recipient;
  END`
];
const initialized=new WeakSet();
async function initialize(db){
  if(initialized.has(db))return;
  await db.batch([...schemas,...serialSchema('nexus_players',true)].map(sql=>db.prepare(sql)));
  initialized.add(db);
}
const hex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
const random=count=>crypto.getRandomValues(new Uint8Array(count));
const hash=async value=>hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))));
const publicPlayer=({id,name,code})=>({id,name,code});
function summarize(unit){
  const stats=fighter(unit);
  const power=['hp','attack','magic','defense','resistance','speed'].reduce((sum,k)=>sum+stats[k],0);
  return {id:unit.id,xp:unit.xp,name:CHARACTERS[unit.id].name,level:stats.level,shiny:unit.shiny,
    trait:unit.trait,nen:unit.nen===true,serial:unit.serial,odds:unit.odds,power};
}
function rankedUnits(collection){
  const units=collection.map(summarize);
  const rarity=(a,b)=>(b.odds??0)-(a.odds??0)||a.name.localeCompare(b.name)||a.serial-b.serial;
  const rare=units.filter(u=>u.odds>0).sort(rarity).slice(0,30);
  const top=units.sort((a,b)=>b.power-a.power||rarity(a,b)).slice(0,4);
  return [top.reduce((sum,u)=>sum+u.power,0),JSON.stringify(top),JSON.stringify(rare)];
}
async function register(db,input,request){
  const name=typeof input.name==='string'?input.name.normalize('NFC').trim().replace(/\s+/gu,' '):'';
  if(!/^[\p{L}\p{N} _.-]{2,24}$/u.test(name))reject(400,'Use de 2 a 24 letras ou números no nome.');
  const now=Date.now();
  const regKey=await hash(Math.floor(now/3600000)+'/'+(request.headers.get('CF-Connecting-IP')??'local'));
  const token=btoa(String.fromCharCode(...random(24))).replaceAll('+','-').replaceAll('/','_');
  const state=fresh(now,crypto.getRandomValues(new Uint32Array(1))[0]);
  const tokenHash=await hash(token);
  const id=crypto.randomUUID();
  for(let attempt=0;attempt<3;attempt++){
    const counter=await db.prepare('SELECT * FROM nexus_serials WHERE id=1').first();
    issueSerials(state,state.collection,counter);
    const ranks=rankedUnits(state.collection);
    const code=hex(random(5)).toUpperCase();
    const inserted=await db.prepare(`INSERT INTO nexus_players(id,code,token_hash,name,game,appearance,reg_key,power,top_units,rare_units)
      SELECT ?,?,?,?,?,?,?,?,?,? WHERE (SELECT revision FROM nexus_serials WHERE id=1)=? AND (SELECT count(*) FROM nexus_players WHERE reg_key=?)<20
      ON CONFLICT(code) DO NOTHING RETURNING id`).bind(id,code,tokenHash,name,JSON.stringify(state),JSON.stringify(DEFAULT_PROFILE),regKey,...ranks,counter.revision,regKey).first();
    if(inserted)return {token,player:{id,name,code}};
    const count=await db.prepare('SELECT count(*) AS n FROM nexus_players WHERE reg_key=?').bind(regKey).first();
    if(count.n>=20)reject(429,'Limite temporário de criação de contas atingido.');
  }
  reject(503,'Tente criar o perfil novamente.');
}
async function authenticate(db,request){
  const token=/^Bearer ([A-Za-z0-9_-]{32})$/.exec(request.headers.get('Authorization')??'')?.[1];
  if(!token)reject(401,'Entre na sua conta da comunidade.');
  const row=await db.prepare('SELECT id FROM nexus_players WHERE token_hash=?').bind(await hash(token)).first();
  if(!row)reject(401,'Código de acesso inválido.');
  return row.id;
}
async function sync(db,id,body){
  // A concurrent sync or gift changes the revision. Recalculate from the newest checkpoint.
  for(let attempt=0;attempt<4;attempt++){
    const row=await db.prepare('SELECT id,name,code,game,revision,last_seen FROM nexus_players WHERE id=?').bind(id).first();
    const state=JSON.parse(row.game),now=Date.now(),previous=state.pending;
    const age=body.observationAge===undefined&&body.visible===true?0:body.observationAge;
    const seen=Number.isFinite(age)&&age>=0?now-age:null;
    const entries=advanceWithPresence(state,now,seen);
    const last=entries.at(-1);
    const finished=previous&&last?.end===previous.end?{battle:previous,entry:last}:null;
    const changed=applyGameAction(state,body.action,now);
    if(changed)entries.push(...advance(state,now));
    const units=entries.map(e=>e.recruit||e.sold).filter(Boolean);
    const counter=units.length?await db.prepare('SELECT * FROM nexus_serials WHERE id=1').first():null;
    issueSerials(state,units,counter);
    const delta=now-(row.last_seen??now);
    const played=delta>0&&delta<=20000?delta:0;
    const ranks=rankedUnits(state.collection);
    const result=await db.prepare(`UPDATE nexus_players SET game=?,play_ms=play_ms+?,last_seen=?,
      power=?,top_units=?,rare_units=?,revision=revision+1 WHERE id=? AND revision=? AND (? IS NULL OR (SELECT revision FROM nexus_serials WHERE id=1)=?)`)
      .bind(JSON.stringify(state),played,body.visible===true?now:null,...ranks,id,row.revision,counter?.revision??null,counter?.revision??null).run();
    if(!result.meta.changes)continue;
    delete state.seed;
    return {state,changed,finished,now,player:publicPlayer(row),entries:entries.slice(-25),
      offline:{total:entries.length,wins:entries.filter(e=>e.won).length,gold:entries.reduce((sum,e)=>sum+e.gold,0),recruits:entries.filter(e=>e.recruit).length}};
  }
  reject(409,'A campanha está sendo atualizada. Tente novamente.');
}
async function profile(db,id){
  const row=await db.prepare('SELECT id,name,code,game,appearance,play_ms,rare_units FROM nexus_players WHERE id=?').bind(id).first();
  if(!row)reject(404,'Jogador não encontrado.');
  const state=JSON.parse(row.game);
  return {...publicPlayer(row),appearance:JSON.parse(row.appearance),playMs:row.play_ms,encounters:state.wins+state.losses,
    leaderId:state.collection.find(u=>u.uid===state.leader)?.id,team:state.team.map(uid=>summarize(state.collection.find(u=>u.uid===uid))),
    showcase:JSON.parse(row.rare_units).slice(0,5)};
}
async function rankings(db){
  const [power,rarity]=await db.batch([
    db.prepare('SELECT id,name,power,top_units FROM nexus_players ORDER BY power DESC,name,id LIMIT 30'),
    db.prepare(`SELECT p.id,p.name,u.value AS unit FROM nexus_players p,json_each(p.rare_units) u
      ORDER BY json_extract(u.value,'$.odds') DESC,json_extract(u.value,'$.name'),json_extract(u.value,'$.serial'),p.id LIMIT 30`)
  ]);
  return {power:power.results.map(({id,name,power,top_units})=>({player:{id,name},power,units:JSON.parse(top_units)})),
    rarity:rarity.results.map(({id,name,unit})=>({...JSON.parse(unit),player:{id,name}}))};
}
const pair=(a,b)=>a<b?[a,b]:[b,a];
async function friends(db,id){
  const now=Date.now(),cycle=dailyCycle(now);
  const [connections,inbox]=await db.batch([
    db.prepare(`SELECT p.id,p.name,p.code,f.accepted,f.requested_by,
      EXISTS(SELECT 1 FROM nexus_gifts g WHERE g.sender=? AND g.recipient=p.id AND g.day=?) AS sent
      FROM nexus_friends f JOIN nexus_players p ON p.id=CASE WHEN f.a=? THEN f.b ELSE f.a END
      WHERE f.a=? OR f.b=? ORDER BY p.name,p.id`).bind(id,cycle.day,id,id,id),
    db.prepare(`SELECT p.id,p.name,g.gold,g.sent_at AS sentAt FROM nexus_gifts g JOIN nexus_players p ON p.id=g.sender
      WHERE g.recipient=? ORDER BY g.sent_at DESC LIMIT 20`).bind(id)
  ]);
  return {friends:connections.results.filter(r=>r.accepted),requests:connections.results.filter(r=>!r.accepted),inbox:inbox.results,cycle,now,giftGold:GIFT_GOLD};
}
async function invite(db,id,code){
  if(typeof code!=='string'||!/^[a-f0-9]{10}$/i.test(code.trim()))reject(400,'Informe o código de amigo com 10 caracteres.');
  const other=await db.prepare('SELECT id FROM nexus_players WHERE code=?').bind(code.trim().toUpperCase()).first();
  if(!other)reject(404,'Código de amigo não encontrado.');
  if(other.id===id)reject(400,'Esse é o seu próprio código.');
  const result=await db.prepare(`INSERT OR IGNORE INTO nexus_friends(a,b,requested_by) SELECT ?,?,?
    WHERE (SELECT count(*) FROM nexus_friends WHERE a=? OR b=?)<40 AND (SELECT count(*) FROM nexus_friends WHERE a=? OR b=?)<40`)
    .bind(...pair(id,other.id),id,id,id,other.id,other.id).run();
  if(!result.meta.changes)reject(409,'Já existe um convite ou o limite de amigos foi atingido.');
}
async function reply(db,id,body){
  if(typeof body.id!=='string'||!['accept','remove'].includes(body.decision))reject(400,'Resposta inválida.');
  const ids=pair(id,body.id);
  const statement=body.decision==='remove'
    ?db.prepare('DELETE FROM nexus_friends WHERE a=? AND b=?').bind(...ids)
    :db.prepare('UPDATE nexus_friends SET accepted=1 WHERE a=? AND b=? AND requested_by<>? AND accepted=0').bind(...ids,id);
  if(!(await statement.run()).meta.changes)reject(409,'A amizade ou o convite já mudou.');
}
async function gift(db,id,recipient){
  if(typeof recipient!=='string')reject(400,'Escolha um amigo.');
  const now=Date.now(),ids=pair(id,recipient);
  const result=await db.prepare(`INSERT OR IGNORE INTO nexus_gifts(sender,recipient,day,gold,sent_at)
    SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM nexus_friends WHERE a=? AND b=? AND accepted=1)`)
    .bind(id,recipient,dailyCycle(now).day,GIFT_GOLD,now,...ids).run();
  if(!result.meta.changes){
    if(!await db.prepare('SELECT 1 FROM nexus_friends WHERE a=? AND b=? AND accepted=1').bind(...ids).first())reject(403,'Presentes são exclusivos para amigos confirmados.');
    reject(409,'Você já enviou um presente a esse amigo neste ciclo.');
  }
  return {gold:GIFT_GOLD};
}
async function readBody(request,limit=8192){
  if(!request.headers.get('Content-Type')?.startsWith('application/json'))reject(415,'Envie JSON.');
  const reader=request.body?.getReader();
  if(!reader)reject(400,'Pedido inválido.');
  const decoder=new TextDecoder();let raw='',bytes=0;
  for(;;){
    const chunk=await reader.read();if(chunk.done)break;
    bytes+=chunk.value.byteLength;
    if(bytes>limit){await reader.cancel();reject(413,'Pedido muito grande.');}
    raw+=decoder.decode(chunk.value,{stream:true});
  }
  let body;
  try{body=JSON.parse(raw+decoder.decode());}catch{reject(400,'Pedido inválido.');}
  if(!body||Array.isArray(body)||typeof body!=='object')reject(400,'Pedido inválido.');
  return body;
}
function json(value,status=200){
  return Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
}
export default {
  async fetch(request,env){
    const path=new URL(request.url).pathname;
    if(!path.startsWith('/api/'))return env.ASSETS.fetch(request);
    try{
      const db=env.NEXUS_DB;
      if(!db)reject(503,'Vincule o banco D1 como NEXUS_DB neste ambiente do Pages e publique a versão novamente.');
      await initialize(db);
      const post=request.method==='POST';
      
      if(post&&path==='/api/community/account')return json(await register(db,await readBody(request),request),201);
      const id=await authenticate(db,request);
      const body=post?await readBody(request,path==='/api/community/profile'?PROFILE_BODY_LIMIT:8192):null;
      if(request.method==='GET'){
        if(path==='/api/community/profile')return json(await profile(db,id));
        const other=/^\/api\/community\/profile\/([a-f0-9-]{36})$/.exec(path)?.[1];
        if(other)return json(await profile(db,other));
        if(path==='/api/community/friends')return json(await friends(db,id));
        if(path==='/api/community/rankings')return json(await rankings(db));
      }
      if(post){
        if(path==='/api/game')return json(await sync(db,id,body));
        if(path==='/api/community/profile'){
          let patch;
          try{patch=appearancePatch(body);}catch(error){reject(400,error.message);}
          await db.prepare('UPDATE nexus_players SET appearance=json_patch(appearance,?) WHERE id=?').bind(JSON.stringify(patch),id).run();
          return json(await profile(db,id));
        }
        if(path==='/api/community/friend-request'){await invite(db,id,body.code);return json({});}
        if(path==='/api/community/friend-reply'){await reply(db,id,body);return json({});}
        if(path==='/api/community/gift')return json(await gift(db,id,body.id));
      }
      reject(404,'Rota não encontrada.');
    }catch(error){
      if(error instanceof ApiError)return json({error:error.message},error.status);
      console.error('Nexus API:',error.message);
      return json({error:'Falha ao acessar a Comunidade. Confira o banco D1 nos registros do Pages.'},500);
    }
  }
};
