const sheets={};
const names=["barba_fratura", "barba_onda", "barba_tremor", "beerus_basico", "beerus_dissipacao", "beerus_hakai", "cero_flight", "cero_impact", "contato_azul", "dot_chamas_azuis", "dot_chamas_negras", "dot_fogo", "dot_sangramento", "giorno_acao", "giorno_impacto", "giorno_punho", "giorno_selo", "giorno_zero", "gojo_basico", "gojo_carga", "gojo_ilimitado", "gojo_vazio", "goku_contra", "goku_postura", "kaguya_basico", "kaguya_fenda", "kaguya_fragmentos", "kaguya_marca", "lucius_marca", "lucius_reversao", "madoka_purifica", "madoka_retorno", "madoka_selo", "meliodas_contato", "meliodas_corte", "meliodas_escudo", "meliodas_reserva", "meruem_carapaca", "meruem_esfera", "meruem_impacto", "meruem_lamina", "roger_dash", "roger_hit", "sailor_barreira", "sailor_cura", "sailor_onda", "saitama_impacto", "saitama_onda", "saitama_soco", "shinra_cura", "shinra_fratura", "shinra_golpe", "shinra_ignicao", "simon_broca", "simon_espiral", "simon_impacto", "sukuna_basico", "sukuna_corte", "sukuna_santuario", "yhwach_futuro", "yhwach_visao"];
let loaded=false;
function loadSheets(){
  if(loaded)return;
  loaded=true;
  for(const name of names){
    const image=new Image();
    image.onload=()=>{sheets[name]=image;};
    image.src='art/transcendentes/'+name+'.png';
  }
}
export function paintTranscendentes(canvas,match,motion){
 const ctx=canvas.getContext('2d');
 if(!ctx)return;
 loadSheets();
 const R=4,batchImages=sheets,rogerArt={investida:sheets.roger_dash,contato:sheets.roger_hit},ceroImages={flight:sheets.cero_flight,impact:sheets.cero_impact};
 const quakeRadius=age=>[3,8,14,18][Math.min(3,Math.floor(Math.max(0,age)/.06))];
 const ceroLength=(age,speed)=>Math.min(26,Math.max(.6,age*speed));
function shape(x,y,r,fill,stroke,line=.28){
 ctx.beginPath();ctx.arc(x,y,Math.max(0,r),0,2*Math.PI);
 if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=line;ctx.stroke()}
}
function artAt(im,x,y,w,h,frames=1,index=0,angle=0){
 if(!motion)index=0;
 const sw=im.width/frames,ratio=Math.min(w/sw,h/im.height),dw=sw*ratio,dh=im.height*ratio;
 ctx.save();ctx.translate(x,y);ctx.rotate(angle);ctx.drawImage(im,index*sw,0,sw,im.height,-dw/2,-dh/2,dw,dh);ctx.restore();
}
function batchArt(key,x,y,size,age,angle=0){const im=batchImages[key];if(im)artAt(im,x,y,size,size,4,Math.floor(Math.max(0,age)*25)%4,angle)}

 ctx.setTransform(canvas.width/100,0,0,canvas.height/50,0,0);ctx.clearRect(0,0,100,50);ctx.imageSmoothingEnabled=false;
 if(match.result)return;

 for(const e of match.flashes){
   if(e.art==='sailor_onda'){const t=match.t-e.time;if(t>=0&&t<.16)batchArt(e.art,e.x,e.y,14+t*155,t)}
 }
 const zones=false;
 for(const s of match.shots){
   const zone=['room','zone'].includes(s.kind),age=match.t-s.born,r=s.radius*(zone?Math.min(1,age/.3):1);
   if(s.kind==='tremor'){
     if(!s.support && age<.48){
       ctx.save();ctx.globalAlpha=age<.24?1:Math.max(0,1-(age-.24)/.24);
       if(age<.24)shape(s.x,s.y,quakeRadius(age),'#52e5b80d','#8be4cb70',.13);
       const im=batchImages.barba_tremor;
       if(im)artAt(im,s.x,s.y,37,37,4,Math.min(3,Math.floor(age/.06)),s.angle);
       ctx.restore();
     }
     if(age>=.24){
       const distance=(s.support?0:18)+84*(age-.24),ux=Math.cos(s.angle),uy=Math.sin(s.angle);
       const im=batchImages.barba_onda;
       if(im)artAt(im,s.x+ux*(distance-9),s.y+uy*(distance-9),22,22,4,Math.floor((age-.24)/.06)%4,s.angle);
     }
     continue;
   }
   if(s.kind==='muda'){
     const im=batchImages.giorno_punho;
     if(im)artAt(im,s.x-3.8*Math.cos(s.angle),s.y-3.8*Math.sin(s.angle),12,12,4,Math.min(3,Math.floor(age/.045)),s.angle);
     continue;
   }
   const tint=s.side?'#ffb4ae':'#91ebf7',fill=s.side?'#f48b7a24':'#5fdaef28';
   if(s.kind==='dominio'||s.kind==='santuario'){
     const charge=s.kind==='dominio'&&!s.open;
     const pos=charge?match.sides[s.side]:s;
     const art=charge?'gojo_carga':s.kind==='dominio'?'gojo_vazio':'sukuna_santuario';
     batchArt(art,pos.x,pos.y,charge?13:s.radius*2*64/62,age);
     continue;
   }
   if(s.kind==='batch'){
     if(s.art==='teste'){shape(s.x,s.y,1,'#efad86');continue}
     if(s.art==='saitama_soco'){
       batchArt(s.art,s.x-8*Math.cos(s.angle),s.y-8*Math.sin(s.angle),30,age,s.angle);
       if(zones)shape(s.x,s.y,s.radius,null,'#effffcad',.13);
     }else if(s.art==='simon_broca'){batchArt(s.art,s.x-.32*s.size*Math.cos(s.angle),s.y-.32*s.size*Math.sin(s.angle),s.size,age,s.angle)}else batchArt(s.art,s.x,s.y,({meliodas_corte:22,meruem_esfera:15,meruem_lamina:19,beerus_hakai:14,beerus_basico:11,kaguya_basico:12,shinra_golpe:16})[s.art]??9,age,s.angle);
     continue;
   }
   if(s.kind==='cero'){
     const length=ceroLength(age,s.speed);
     const fx=null;
     const image=fx?.image||ceroImages.flight;
     const cx=s.x-Math.cos(s.angle)*length*.47,cy=s.y-Math.sin(s.angle)*length*.47;
     if(image)artAt(image,cx,cy,length,length,fx?.frames||4,Math.floor(age*(fx?.fps||25))%(fx?.frames||4),s.angle);

     continue;
   }
   const custom=false;
   if(!custom)shape(s.x,s.y,r,fill,tint,zone?.2:.26);
   if(zones){
     ctx.setLineDash([.35,.5]);
     shape(s.x,s.y,s.radius,null,'#effffcad',.13);
     ctx.setLineDash([]);
   }
 }
 match.sides.forEach((s,i)=>{
   const f=s.team[s.slot];if(!f)return;
   if(f.cleanSeal?.size)batchArt('madoka_selo',s.x,s.y,14,match.t);
   if((f.kind==='yhwach'&&!f.almightySpent)||f.futureUntil>match.combat.time)batchArt('yhwach_visao',s.x,s.y,15,match.t);
   if((f.kind==='giorno'||f.zeroGuard)&&!match.combat.zeroUsed?.[i])batchArt('giorno_selo',s.x,s.y,R*80/25,match.t);
   if(f.demonCharge>0)batchArt('meliodas_reserva',s.x,s.y,15,match.t);
   if(f.crackedShield)batchArt('meliodas_escudo',s.x+R,s.y-R,6,match.t);
   if(f.moonGuard||f.moonShield>0)batchArt('sailor_barreira',s.x,s.y,12.8,match.t);
   for(const state of f.dots?.values()??[]){
     const elapsed=match.t-state.start,frame=Math.floor((elapsed+1e-6)/.10)%4;
     const art=batchImages[state.key];
     if(art){ctx.save();ctx.globalAlpha=state.lastTick!==null&&match.t-state.lastTick<.14?1:.80;
       artAt(art,s.x,s.y,15.8,15.8,4,frame);ctx.restore()}
   }
   if(f.adaptiveUntil>match.combat.time)batchArt('meruem_carapaca',s.x,s.y,13,match.t);
   if(f.timeMark?.until>match.combat.time)batchArt('lucius_marca',s.x,s.y,15,match.t);
   if(f.portalDodge)batchArt('kaguya_marca',s.x,s.y,13,match.t);
   if(f.powerUntil>match.combat.time||f.weakenUntil>match.combat.time&&match.sides[1-i].team.some(u=>u.kind==='kaguya')){
     batchArt('kaguya_marca',s.x,s.y,13,match.t);
   }
   if(f.stanceUntil>match.t*1000)batchArt('goku_postura',s.x,s.y-.36,17.5,match.t-(f.stanceUntil-2000)/1000);
   if(s.ignition){
     const age=match.t-s.ignition.born,im=batchImages.shinra_ignicao;
     if(im)artAt(im,s.x,s.y,22,22,4,Math.min(3,Math.floor(age*20)),0);
   }
   if(s.dash?.art){
     const a=s.dash.angle;batchArt(s.dash.art,s.x-8*Math.cos(a),s.y-8*Math.sin(a),26,match.t-s.dash.born,a);
   }else if(s.dash && rogerArt.investida){
     const a=s.dash.angle;
     artAt(rogerArt.investida,s.x+Math.cos(a)*1.5,s.y+Math.sin(a)*1.5,20,20,4,Math.floor((match.t-s.dash.born)*25)%4,a);
   }
 });
 for(const e of match.flashes){
   const elapsed=match.t-e.time+(match.finishFxAt===undefined?0:(performance.now()-match.finishFxAt)/1000);
   if(e.art==='giorno_selo'||e.art==='sailor_onda')continue;
   if(e.art==='sailor_barreira'||e.art==='sailor_cura'){
     if(elapsed>=0&&elapsed<.16){
       const pos=match.sides[e.follow],size=e.art==='sailor_barreira'?12.8:14;
       ctx.save();ctx.beginPath();ctx.rect(-100,-100,300,250);ctx.arc(pos.x,pos.y,R,0,Math.PI*2);ctx.clip('evenodd');
       batchArt(e.art,pos.x,pos.y,size,elapsed);ctx.restore();
     }
     continue;
   }
   if(e.art==='shinra_fratura'){
     const im=batchImages.shinra_fratura;
     if(im&&elapsed>=0&&elapsed<.28)artAt(im,e.x,e.y,28,28,4,Math.floor(elapsed/.07),e.angle);
     continue;
   }
   if(e.art==='saitama_onda'){
     if(elapsed>=0&&elapsed<.32&&batchImages.saitama_onda){
       const travel=elapsed*45;
       artAt(batchImages.saitama_onda,e.x+Math.cos(e.angle)*travel,e.y+Math.sin(e.angle)*travel,26,26,4,Math.floor(elapsed/.08),e.angle);
     }
     continue;
   }
   if(e.art){
     if(elapsed>=.16)continue;
     const p=e.follow===undefined?e:match.sides[e.follow];
     batchArt(e.art==='contato_dourado'?'saitama_impacto':e.art,p.x,p.y,e.art==='sailor_onda'?14+elapsed*155:e.art==='lucius_reversao'?25:e.art==='barba_fratura'?17:e.art==='kaguya_fenda'?31:e.art==='shinra_cura'?22:e.art==='beerus_dissipacao'?17:e.art==='saitama_impacto'?21:e.follow===undefined?11:15,elapsed);continue;
   }
   if(e.kind==='rei'){
     if(rogerArt.contato)artAt(rogerArt.contato,e.x,e.y,16,16,4,Math.min(3,Math.floor((match.t-e.time)*25)),e.angle);
     continue;
   }
   const angle=Math.atan2(e.y-e.fromY,e.x-e.fromX);
   if(e.kind==='cero'){
     const fx=null,im=ceroImages.impact;
     const frames=fx?.frames||4;
     if(im)artAt(im,e.x,e.y,7,7,frames,Math.min(frames-1,Math.floor((match.t-e.time)*(fx?.fps||25))),0);
     continue;
   }
   if(e.kind==='room'){ctx.beginPath();ctx.moveTo(e.fromX,e.fromY);ctx.quadraticCurveTo((e.x+e.fromX)/2,e.y-3,e.x,e.y);ctx.lineWidth=.45;ctx.strokeStyle=e.side?'#ffbfcc':'#c5ffff';ctx.stroke()}
   shape(e.x,e.y,1.7,null,'#fff',.4);
 }
}
